"""Vendored cross-repository conformance vectors."""
