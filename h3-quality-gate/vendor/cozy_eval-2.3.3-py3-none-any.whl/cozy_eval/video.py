"""Video mode: the same six dimensions, scored over clips.

STABILITY: locked core (v0.x) for :func:`run_video`'s call shape and the modes
it stamps (``video-paired`` / ``video-reference-free``); the report it returns
is the same :class:`cozy_eval.suite.SuiteReport` schema.

What changes for video, and what deliberately does not:

* **similarity** stays per-frame — ``lpips`` and ``psnr`` are per-frame MEANS
  under their usual names, plus the worst-frame tail (``lpips_frame_worst``).
  ``ssim``/``ms_ssim`` are NOT computed over clips (@10 cut: they are declared
  modality ``image``, because a windowed structural similarity pooled over
  frames rewards the over-smoothing this suite exists to catch, and it reads
  -0.96 against lpips anyway). The Δ-frame PSNR family is gone with them: it was
  a reference distance taken of a reference distance, doubly confounded by a
  re-rolled take, and ``warp_error``/``luma_flicker`` measure the flicker it
  claimed reference-free. **All of these are refused outright when the declared
  protocol puts the comparison on the population lane.**
* **adherence** uses the same authored-checklist discipline with the
  motion/hold duality (:class:`cozy_eval.metrics.adherence.VideoChecklist`):
  a clip can fail by not moving or by not holding still. The judge sees an
  ORDERED strip of uniformly sampled frames — the same Judge protocol as
  images; a judge with native video input is just a faster implementation of
  the same contract. OCR items are read on every sampled frame and must PERSIST
  (majority of frames), because text that is legible in one lucky frame has not
  survived motion. **The strip is split into THREE temporal windows and the
  checklist is asked of each (@9), with the gate on the WORST window**: one
  whole-strip call mean-pools a mid-clip drop-out into invisibility, which is
  how a 15 s arm that dropped the cargo bike and the parcel it was asked for
  passed everything we had. ``element_recall_drop`` (first window minus last)
  reports the direction.
* **quality** composes ``cozy_eval.metrics.signal`` for single-arm temporal
  signal statistics (``luma_flicker``, ``jerk_ratio``), and adds the
  track-stability family (:mod:`cozy_eval.tracks`): the OBJECT axis. Every
  number above is a statistic of FRAMES — per-frame detail, whole-frame flow,
  frame-mean luma — and an object can warble and reshape itself under camera
  motion while every one of them stays clean. Feature tracks are the only thing
  here that follows a point on an object through time. Reference-free numbers on
  every clip; the gate is the paired ``track_stability_ratio``.
* **preference** is UNMEASURED in video mode for now, and the report says so.
  A commercially-clean video preference model exists (UnifiedReward-2.0,
  MIT weights on an Apache-2.0 Qwen3-VL base) and its integration is tracked;
  a frame-mean image preference score is NOT used as a stand-in — an image
  model cannot see motion, and a number that ignores the axis under test is
  worse than an honest gap.

* **audio** is scored when ``audio=`` is passed, through the single verdict
  function :func:`cozy_eval.audio.audio_verdict` — signal statistics and the
  dual-mono/silence/clipping guards, paired fidelity to the reference arm,
  AV-sync, and the transcribe-then-judge semantic tier. The report's MODE gains
  ``+audio``, and a run WITHOUT it carries an explicit UNMEASURED note, because
  every video model we serve now emits audio and a green video report says
  nothing about the soundtrack.

Clips are ``(T, H, W, 3)`` RGB arrays (uint8 or float [0, 1]) or lists of PIL
frames — the pre-encode arrays a producer already holds. No ffmpeg dependency;
decoding video FILES is the caller's job.
"""

from __future__ import annotations

import time
from collections.abc import Iterable
from datetime import UTC, datetime
from typing import Any

import msgspec

from . import accumulate, integrity, registry, suite
from . import protocol as protocol_mod
from .device import AUTO, resolve_device
from .errors import BackendError, ConfigError
from .judge import Judge
from .metrics import adherence, ocr, similarity, temporal
from .metrics.adherence import (
    KIND_OCR,
    KIND_VQA,
    OCR_FUZZY_PASS,
    AdherenceScore,
    ChecklistItem,
    ItemVerdict,
    VideoChecklist,
    ask_judge,
    judged_items,
    text_match,
    unmeasured_note,
)

#: Frames shown to the judge (and read by OCR / CLIP) per clip. Uniform over
#: the clip, always including first and last frame.
DEFAULT_JUDGE_FRAMES = 8

#: Temporal windows the adherence checklist is asked over, per clip (@9). The
#: strip is split in three and the GATE is the worst window, because a clip that
#: loses a prompted object halfway through is a failure a whole-strip mean-pool
#: cannot see. ``1`` restores the pre-@9 single whole-strip call.
DEFAULT_RECALL_WINDOWS = 3


class VideoSample(msgspec.Struct, kw_only=True):
    """One video eval row. ``checklist_id`` selects the authored t2v checklist;
    empty means the row is not scored for adherence."""

    prompt: str
    seed: int = 0
    checklist_id: str = ""


# ---------------------------------------------------------------------------
# judge orchestration — ONE structured call per clip
# ---------------------------------------------------------------------------

_VIDEO_PREAMBLE = (
    "You are grading whether a video generator followed its instructions. "
    "You are shown {n} frames sampled in temporal order from a single "
    "generated video: the first image is the first frame, the last image is "
    "the last frame. Judge motion and change ACROSS the frames, not any one "
    "frame alone. Answer each numbered question with yes or no; if the asked "
    "motion never happens, or something that should stay fixed changes, "
    "answer no. Reply with ONLY a JSON array like "
    '[{{"n": 1, "answer": "yes"}}, {{"n": 2, "answer": "no"}}] — one object '
    "per question, no other text."
)


def build_video_judge_prompt(items: tuple[ChecklistItem, ...], *, frame_count: int) -> str:
    lines = [_VIDEO_PREAMBLE.format(n=frame_count), "Questions:"]
    lines += [f"{i}. {item.question}" for i, item in enumerate(items, start=1)]
    return "\n".join(lines)


def score_video_ocr_items(
    items: tuple[ChecklistItem, ...], page_texts: list[str],
) -> list[ItemVerdict]:
    """OCR items over a sampled frame strip: PERSISTENCE, not best-frame.

    An item is present when it passes on a MAJORITY of the sampled frames —
    text that flickers into legibility once has not survived motion. ``score``
    is the mean fuzzy similarity across frames (inverted for ``absent`` items),
    so a near-miss still reads as a near-miss.
    """
    out = []
    for item in items:
        passes, fuzzies = 0, []
        for page in page_texts:
            exact, fuzzy = text_match(item.text, page)
            fuzzies.append(fuzzy)
            if exact or fuzzy >= OCR_FUZZY_PASS:
                passes += 1
        present = passes * 2 > len(page_texts)
        verified = (not present) if item.absent else present
        mean_fuzzy = sum(fuzzies) / len(fuzzies) if fuzzies else 0.0
        out.append(ItemVerdict(
            id=item.id, kind=KIND_OCR, verified=verified,
            score=(1.0 - mean_fuzzy) if item.absent else mean_fuzzy,
            detail=(
                f"{'absent-required ' if item.absent else ''}"
                f"passed {passes}/{len(page_texts)} frames, mean fuzzy {mean_fuzzy:.2f}"
            ),
        ))
    return out


def score_video(
    checklist: VideoChecklist, strip: list[Any], *,
    judge: Judge | None = None, page_texts: list[str] | None = None,
) -> AdherenceScore:
    """Motion compliance + static preservation for one clip's sampled strip.

    ONE judge call covers both groups' questions; OCR items are read from
    every frame of the strip (persistence rule). ``compliance`` carries the
    motion group, ``preservation`` the hold group — the same duality fields
    edit mode uses, because it is the same failure geometry over time.
    """
    groups = (("motion", checklist.motion), ("hold", checklist.hold))
    all_items = checklist.motion + checklist.hold
    vqa_items = tuple(i for i in all_items if i.kind == KIND_VQA)
    verdicts: list[ItemVerdict] = []
    missing = []

    for name, items in groups:
        ocr_items = tuple(i for i in items if i.kind == KIND_OCR)
        if ocr_items:
            if page_texts is None:
                missing.append(f"{len(ocr_items)} {name} ocr items (no OCR reader)")
            else:
                verdicts += score_video_ocr_items(ocr_items, page_texts)
    if vqa_items:
        if judge is None:
            missing.append(f"{len(vqa_items)} vqa items (no judge)")
        else:
            prompt = build_video_judge_prompt(vqa_items, frame_count=len(strip))
            answers, reason = ask_judge(judge, strip, prompt, len(vqa_items))
            answered, unanswered = judged_items(vqa_items, answers)
            verdicts += answered
            if reason or unanswered:
                missing.append(
                    unmeasured_note(len(vqa_items), "vqa items", reason, unanswered)
                )
    if not verdicts:
        return AdherenceScore(measured=False, note="; ".join(missing) or "empty checklist")

    def _group_recall(items: tuple[ChecklistItem, ...]) -> float:
        scored = tuple(i for i in items if any(v.id == i.id for v in verdicts))
        return adherence._recall(scored, verdicts) if scored else 0.0

    scored_all = tuple(i for i in all_items if any(v.id == i.id for v in verdicts))
    exact, fuzzy = adherence._text_rates(scored_all, verdicts)
    return AdherenceScore(
        measured=True,
        element_recall=adherence._recall(scored_all, verdicts),
        compliance=_group_recall(checklist.motion),
        preservation=_group_recall(checklist.hold),
        text_exact=exact, text_fuzzy=fuzzy, items=verdicts,
        note=("partial: " + "; ".join(missing)) if missing else "",
    )


def _group_measured(
    score: AdherenceScore, items: tuple[ChecklistItem, ...],
) -> bool:
    """Was ANY item of this group actually scored? A group nobody looked at
    must not report 0.0 — 'unmeasured' and 'failed everything' are different
    facts."""
    ids = {i.id for i in items}
    return any(v.id in ids for v in score.items)


# ---------------------------------------------------------------------------
# the runner
# ---------------------------------------------------------------------------

def _aligned(cand: Any, ref: Any, index: int) -> Any:
    """Candidate frames resized to the reference's HxW. Frame-count mismatch is
    an error, not a silent trim — a paired video verdict needs frame alignment."""
    if cand.shape[0] != ref.shape[0]:
        raise ConfigError(
            f"sample {index}: candidate has {cand.shape[0]} frames but the "
            f"reference has {ref.shape[0]} — paired video metrics are "
            "frame-aligned; render both arms at the same frame count"
        )
    if cand.shape[1:3] == ref.shape[1:3]:
        return cand
    from PIL import Image

    size = (ref.shape[2], ref.shape[1])  # PIL takes (W, H)
    return temporal.as_frames(
        [img.resize(size, Image.Resampling.LANCZOS) for img in temporal.frame_images(cand)]
    )


def _adherence_pass(
    sample: VideoSample, checklists: Any, strip: list[Any],
    *, judge: Judge | None, use_ocr: bool, ocr_seconds: list[float],
) -> AdherenceScore | None:
    if checklists is None or not sample.checklist_id:
        return None
    entry = checklists.t2v.get(sample.checklist_id)
    if entry is None:
        return None
    page_texts: list[str] | None = None
    if use_ocr:
        _t = time.monotonic()
        pages = [ocr.read(img) for img in strip]
        ocr_seconds.append(time.monotonic() - _t)
        if any(p.measured for p in pages):
            page_texts = [p.text if p.measured else "" for p in pages]
    return score_video(entry, strip, judge=judge, page_texts=page_texts)


def strip_windows(strip: list[Any], windows: int) -> list[list[Any]]:
    """Split a frame strip into contiguous temporal windows, earliest first.

    Extra frames go to the EARLIER windows (8 frames, 3 windows -> 3/3/2), so
    the last window is never the largest and a late drop-out is never diluted
    by frames from the middle of the clip.
    """
    n = len(strip)
    if windows <= 1 or n <= 1:
        return [list(strip)]
    k = min(windows, n)
    base, extra = divmod(n, k)
    out, a = [], 0
    for i in range(k):
        b = a + base + (1 if i < extra else 0)
        out.append(strip[a:b])
        a = b
    return out


def _windowed_adherence_pass(
    sample: VideoSample, checklists: Any, strip: list[Any],
    *, judge: Judge | None, use_ocr: bool, ocr_seconds: list[float], windows: int,
) -> tuple[AdherenceScore | None, list[float]]:
    """The checklist asked ONCE PER TEMPORAL WINDOW; the gate is the worst one.

    Returns ``(worst_window_score, per_window_recalls)``. A whole-strip pass
    mean-pools a mid-clip drop-out into invisibility: MEASURED on the 15 s
    courier cell, where the arm holds the cargo bike and the parcel at t=7.5 s
    and has dropped both by t=14.5 s while DISTS 0.140 passes it. The cheap
    alternatives were measured dead first — min-pooled and trend-pooled
    per-frame CLIP are inside CLIP's own noise and the trend runs the WRONG way
    (ce#14 §1b-iii) — so a judge call per window is the cheapest thing that can
    work. Costs ``windows`` judge calls per clip instead of one; OCR reads the
    same frames either way.
    """
    parts = strip_windows(strip, windows)
    scores = [
        _adherence_pass(sample, checklists, part, judge=judge, use_ocr=use_ocr,
                        ocr_seconds=ocr_seconds)
        for part in parts
    ]
    measured = [s for s in scores if s is not None and s.measured]
    if not measured:
        return (scores[0] if scores else None), []
    recalls = [s.element_recall for s in measured]
    worst = min(measured, key=lambda s: s.element_recall)
    return worst, recalls


def run_video(
    samples: list[VideoSample],
    candidates: list[Any],
    *,
    references: list[Any] | None = None,
    checklists: Any = None,
    judge: Judge | None = None,
    use_ocr: bool = True,
    use_signal: bool = True,
    use_detail: bool = True,
    detail_judge: Judge | None = None,
    use_temporal_fidelity: bool = True,
    use_tracks: bool = True,
    track_windows: int = 0,
    judge_frames: int = DEFAULT_JUDGE_FRAMES,
    recall_windows: int = DEFAULT_RECALL_WINDOWS,
    device: str = AUTO,
    render_seconds: float = 0.0,
    audio: list[Any] | None = None,
    reference_audio: list[Any] | None = None,
    sample_rate: int = 0,
    fps: float = 0.0,
    audio_checklists: dict[str, Any] | None = None,
    transcriber: Any = None,
    audio_judge: Any = None,
    audio_fidelity_budget: tuple[Any, ...] = (),
    protocol: Any = None,
) -> suite.SuiteReport:
    """Score a batch of clips. ``references`` present => video-paired mode.

    ``candidates`` / ``references`` are clips in any form
    :func:`cozy_eval.metrics.temporal.as_frames` accepts.

    ``audio`` attaches the soundtrack, one entry per sample (an
    :class:`~cozy_eval.metrics.audio.Audio`, an array with ``sample_rate``, or a
    media path). The report's MODE then says ``+audio``, and when it is omitted
    the report carries an explicit UNMEASURED note — because every video model we
    serve now emits audio, and a run that silently scored none of it must never
    read as a clean pass.

    ``protocol`` is a :class:`cozy_eval.protocol.Protocol` declaring what changed
    between the arms. Pass it and the runner enforces the lane: on a
    trajectory-perturbing change every reference metric is REFUSED — dropped
    into ``report.unmeasured`` with the reason, never computed and never printed.
    v1 printed them, and a quotable confounded number is worse than a gap,
    because a gap cannot be pasted into a release note. Omit it and the report
    carries a note saying the lane was never declared: the numbers are then
    unvalidated by construction, and the report says so.
    """
    if len(samples) != len(candidates):
        raise ConfigError(
            f"got {len(samples)} samples but {len(candidates)} candidate clips; "
            "each sample is scored against its own render, so the lists must match"
        )
    paired = references is not None
    if references is None:
        references = []
    elif len(references) != len(samples):
        raise ConfigError(
            f"got {len(samples)} samples but {len(references)} reference clips; "
            "a paired run needs one reference per sample"
        )
    if audio is not None and len(audio) != len(samples):
        raise ConfigError(
            f"got {len(samples)} samples but {len(audio)} audio tracks; a clip's "
            "soundtrack is scored against its own sample, so the lists must match"
        )
    device = resolve_device(device)
    ocr_seconds: list[float] = []

    base_mode = "video-paired" if paired else "video-reference-free"
    report = suite.SuiteReport(
        mode=f"{base_mode}+audio" if audio is not None else base_mode,
        samples=len(samples),
        created_at=datetime.now(UTC).isoformat(timespec="seconds"),
    )

    # --- lane enforcement, before a single reference number is computed -------
    _refused: tuple[str, ...] = ()
    if paired:
        if protocol is None:
            report.notes.append(
                "LANE UNDECLARED: no protocol was passed, so the runner could not "
                "check whether the reference metrics below are admissible. If the "
                "candidate arm changed anything that moves the sampling trajectory "
                "(quantization, compile, attention backend, scheduler, step count, "
                "LoRA, seed), the reference render is a DIFFERENT TAKE and every "
                "reference number here measures divergence, not damage. Pass "
                "protocol= to have them refused instead of reported."
            )
        else:
            _, _refused = protocol_mod.admissible(
                protocol.lane, [m.name for m in registry.REGISTRY if m.reference_only]
            )
            for name in _refused:
                report.unmeasured[name] = (
                    f"REFUSED: reference metric on the {protocol.lane} lane "
                    f"({', '.join(str(c) for c in protocol.changes)} moves the sampling "
                    "trajectory, so the reference render is a different take of the "
                    "prompt). Not computed, deliberately."
                )
            if _refused:
                report.notes.append(
                    f"{len(_refused)} reference metrics refused on the "
                    f"{protocol.lane} lane; see report.unmeasured. The valid question "
                    "here is the population one (distributional dimension, n>=8 paired "
                    "prompts) plus the metrics that score each arm on its own "
                    "trajectory (track_stability_ratio, element_recall, pref_delta)."
                )
    rows = [
        suite.SampleRow(
            index=i, checklist_id=s.checklist_id, prompt=s.prompt[:200], seed=s.seed,
        )
        for i, s in enumerate(samples)
    ]

    cand_frames = [temporal.as_frames(c) for c in candidates]
    ref_frames = [temporal.as_frames(r) for r in references] if paired else []
    if paired:
        cand_frames = [
            _aligned(c, r, i)
            for i, (c, r) in enumerate(zip(cand_frames, ref_frames, strict=True))
        ]

    # --- similarity: per-frame aggregate (paired, same-trajectory lane only) --
    #
    # @10 CUT, three ways:
    #   * SSIM/MS-SSIM are gone from video mode. They are declared modality
    #     "image" in the registry now, because a windowed structural similarity
    #     pooled over frames rewards exactly the over-smoothing the suite exists
    #     to catch, and it correlates -0.96 with lpips anyway (one number wearing
    #     two hats, and the wrong hat).
    #   * The whole Δ-frame PSNR family (dframe_psnr / _worst / dframe_ssim) is
    #     gone. It was pitched as the flicker channel; warp_error and
    #     luma_flicker measure flicker directly and reference-free, and the
    #     Δ-frame numbers are a reference distance on top of a reference
    #     distance — doubly confounded by a re-rolled take.
    #   * Every remaining reference metric is REFUSED, not reported, when the
    #     declared protocol puts this comparison on the population lane.
    if paired and not _refused:
        t0 = time.monotonic()
        try:
            lp = similarity.lpips_model(device)
        except (ImportError, BackendError) as exc:
            lp = None
            suite.unavailable(report, ("lpips",), "LPIPS", exc)
        report.seconds["lpips_load"] = round(time.monotonic() - t0, 2)
        lpips_s = pixel_s = 0.0
        for row, ref, cand in zip(rows, ref_frames, cand_frames, strict=True):
            ref_imgs = temporal.frame_images(ref)
            cand_imgs = temporal.frame_images(cand)
            t1 = time.monotonic()
            if lp is not None:
                per_frame = [
                    similarity.lpips_pair(lp, a, b, device)
                    for a, b in zip(ref_imgs, cand_imgs, strict=True)
                ]
                row.lpips = accumulate.pool("mean", per_frame)
                row.values["lpips_frame_worst"] = max(per_frame)
            lpips_s += time.monotonic() - t1
            t1 = time.monotonic()
            pairs = list(zip(ref_imgs, cand_imgs, strict=True))
            row.psnr = _mean(similarity.psnr(a, b) for a, b in pairs)
            pixel_s += time.monotonic() - t1
        report.seconds["lpips"] = round(lpips_s, 2)
        report.seconds["pixel_metrics"] = round(pixel_s, 2)
        if lp is not None:
            report.models["lpips"] = "torchmetrics:lpips-alex"

    # --- adherence: clip continuity + the checklist pass --------------------
    def _strip(frames: Any) -> list[Any]:
        images = temporal.frame_images(frames)
        return [images[i] for i in temporal.sample_indices(frames.shape[0], judge_frames)]

    strips = [_strip(c) for c in cand_frames]
    ref_strips = [_strip(r) for r in ref_frames] if paired else []
    t0 = time.monotonic()
    try:
        clip, proc = similarity.clip_model(device)
    except (ImportError, BackendError) as exc:
        suite.unavailable(report, ("clip_delta",), "CLIP", exc)
    else:
        for row, sample, strip in zip(rows, samples, strips, strict=True):
            row.clip_cand = _mean(
                similarity.clip_score(clip, proc, img, sample.prompt, device) for img in strip
            )
            if paired:
                row.clip_ref = _mean(
                    similarity.clip_score(clip, proc, img, sample.prompt, device)
                    for img in ref_strips[row.index]
                )
                row.clip_delta = row.clip_cand - row.clip_ref
        report.models["clip"] = similarity.CLIP_MODEL
    report.seconds["clip"] = round(time.monotonic() - t0, 2)

    t0 = time.monotonic()
    scored_any = False
    for row, sample, strip in zip(rows, samples, strips, strict=True):
        cand_score, cand_recalls = _windowed_adherence_pass(
            sample, checklists, strip, judge=judge, use_ocr=use_ocr,
            ocr_seconds=ocr_seconds, windows=recall_windows,
        )
        if cand_score is None or not cand_score.measured:
            continue
        scored_any = True
        entry = checklists.t2v[sample.checklist_id]
        row.element_recall_cand = cand_score.element_recall
        row.text_exact = cand_score.text_exact
        row.text_fuzzy = cand_score.text_fuzzy
        if len(cand_recalls) > 1:
            row.values["element_recall_mean"] = sum(cand_recalls) / len(cand_recalls)
            row.values["element_recall_drop"] = cand_recalls[0] - cand_recalls[-1]
        if _group_measured(cand_score, entry.motion):
            row.values["motion_compliance"] = cand_score.compliance
        if _group_measured(cand_score, entry.hold):
            row.values["static_preservation"] = cand_score.preservation
        row.failed_items = [v.id for v in cand_score.items if not v.verified]
        if paired:
            ref_score, _ = _windowed_adherence_pass(
                sample, checklists, ref_strips[row.index], judge=judge,
                use_ocr=use_ocr, ocr_seconds=ocr_seconds, windows=recall_windows,
            )
            if ref_score is not None and ref_score.measured:
                row.element_recall_ref = ref_score.element_recall
                row.element_recall_delta = (
                    cand_score.element_recall - ref_score.element_recall
                )
    adherence_s = time.monotonic() - t0
    ocr_s = sum(ocr_seconds)
    report.seconds["ocr"] = round(ocr_s, 2)
    if judge is not None:
        report.seconds["judge_load"] = round(getattr(judge, "load_seconds", 0.0), 2)
        report.seconds["judge_infer"] = round(getattr(judge, "infer_seconds", 0.0), 2)
        report.judge_calls = int(getattr(judge, "call_count", 0) or 0)
        report.judge_vram_bytes = int(getattr(judge, "vram_bytes", 0))
        if report.judge_calls:
            report.seconds["judge_per_call"] = round(
                getattr(judge, "infer_seconds", 0.0) / report.judge_calls, 2
            )
    report.seconds["adherence_other"] = round(
        max(0.0, adherence_s - ocr_s - getattr(judge, "infer_seconds", 0.0)), 2
    )
    if scored_any:
        if judge is not None:
            report.models["judge"] = getattr(judge, "model_ref", adherence.DEFAULT_JUDGE)
        if use_ocr:
            report.models["ocr"] = adherence.DEFAULT_OCR
    else:
        report.notes.append(
            "element fidelity UNMEASURED: no t2v checklist matched these samples, "
            "or neither a judge VLM nor an OCR reader was available"
        )

    # --- quality: composed single-arm temporal signal -----------------------
    if use_signal:
        t0 = time.monotonic()
        for row, cand in zip(rows, cand_frames, strict=True):
            row.values.update(temporal.signal_stats(cand))
        report.seconds["signal"] = round(time.monotonic() - t0, 2)
        report.models["signal"] = temporal.SIGNAL_LIBRARY

    # --- output integrity: is this a render at all, or noise? ----------------
    # DELIBERATELY has no opt-out flag. Production served VAE-decoded noise on
    # billed requests because nothing looked at pixels; a screen you can switch
    # off rebuilds that hole. numpy only, no reference, milliseconds — there is
    # no cost worth trading for the ability to skip it.
    t0 = time.monotonic()
    for row in rows:
        checked = integrity.output_integrity(cand_frames[row.index])
        if checked.adjacent_frame_corr is not None:
            row.values["adjacent_frame_corr"] = checked.adjacent_frame_corr
        if checked.frame_std_min is not None:
            row.values["frame_std_min"] = checked.frame_std_min
        if checked.grid_peak_ratio is not None:
            row.values["grid_peak_ratio"] = checked.grid_peak_ratio
        for defect in checked.defects:
            report.notes.append(f"sample {row.index:02d} OUTPUT INTEGRITY: {defect}")
        if checked.verdict == integrity.UNMEASURED:
            report.notes.append(
                f"sample {row.index:02d} OUTPUT INTEGRITY UNMEASURED: "
                + "; ".join(checked.notes)
            )
    report.seconds["integrity"] = round(time.monotonic() - t0, 2)
    report.models["integrity"] = temporal.INTEGRITY_LIBRARY

    # --- temporal fidelity: do the movements match (optical flow) ------------
    # The motion axis screenshots miss. Reference-free warp_error on every clip;
    # flow_divergence + warp_error_delta additionally when a same-seed control is
    # present. opencv is the `video` extra — a run without it is UNMEASURED, not
    # a silent pass.
    if use_temporal_fidelity:
        try:
            from .resources import opencv

            opencv()
        except ImportError:
            report.notes.append(
                "TEMPORAL FIDELITY UNMEASURED: opencv not installed "
                "(pip install 'cozy-eval[video]') — flow_divergence / warp_error skipped"
            )
        else:
            t0 = time.monotonic()
            for row in rows:
                cand = cand_frames[row.index]
                if paired and not _refused:
                    row.values.update(
                        temporal.temporal_fidelity(ref_frames[row.index], cand)
                    )
                else:
                    # warp_error is the reference-FREE half of this family and the
                    # one temporal number that survives a re-rolled take, so it
                    # still runs when the paired reads are refused.
                    row.values["warp_error"] = temporal.warp_error(cand)
            report.seconds["temporal_fidelity"] = round(time.monotonic() - t0, 2)
            report.models["temporal_fidelity"] = temporal.FLOW_LIBRARY

    # --- track stability: do OBJECTS hold together in 3D under motion? -------
    # The axis the owner's eye found and the three families above missed: every
    # frame correct, the object warbling between them. Reference-free numbers on
    # every clip; the GATE is the paired ratio, and an untrackable control is
    # UNMEASURED rather than a pass. Costs ~1 s per clip (see cozy_eval.tracks).
    if use_tracks:
        from . import tracks as track_mode
        from .metrics import tracks as track_metrics

        t0 = time.monotonic()
        track_kw: dict[str, Any] = (
            {"windows": track_windows} if track_windows > 0 else {}
        )
        track_unmeasured: dict[str, str] = {}
        for row in rows:
            tv = track_mode.track_verdict(
                cand_frames[row.index],
                ref_frames[row.index] if paired else None,
                **track_kw,
            )
            row.values.update(tv.measured)
            for defect in tv.defects:
                report.notes.append(f"sample {row.index:02d} TRACK STABILITY: {defect}")
            track_unmeasured.update(tv.unmeasured)
        report.seconds["track_stability"] = round(time.monotonic() - t0, 2)
        report.models["track_stability"] = track_metrics.TRACK_LIBRARY
        measured_tracks = {k for row in rows for k in row.values}
        for name, reason in sorted(track_unmeasured.items()):
            if name not in measured_tracks:
                report.notes.append(f"{name} UNMEASURED: {reason}")
        if not paired:
            report.notes.append(track_mode.CONTENT_NOTE)

    # --- audio: the axis a silent run must never be allowed to skip quietly ---
    if audio is None:
        report.notes.append(
            "AUDIO UNMEASURED: no soundtrack was passed to run_video. Every video "
            "model we serve emits audio (LTX-2.3 muxes AAC, MiniMax-H3 generates "
            "32 kHz stereo jointly), so a green report from this run says nothing "
            "about the soundtrack — pass audio=[...] to score it."
        )
    else:
        from . import audio as audio_mode
        from .metrics import audio as audio_metrics
        from .metrics import avsync

        t0 = time.monotonic()
        unmeasured_reasons: dict[str, str] = {}
        for row, sample, track in zip(rows, samples, audio, strict=True):
            av = audio_mode.audio_verdict(
                track,
                reference_audio[row.index] if reference_audio else None,
                sample_rate=sample_rate,
                frames=cand_frames[row.index] if fps > 0 else None,
                reference_frames=(
                    ref_frames[row.index] if (paired and fps > 0 and reference_audio)
                    else None
                ),
                fps=fps,
                checklist=(audio_checklists or {}).get(sample.checklist_id),
                transcriber=transcriber,
                audio_judge=audio_judge,
                fidelity_budget=audio_fidelity_budget,
            )
            row.values.update(av.measured)
            for defect in av.defects:
                report.notes.append(f"sample {row.index:02d} AUDIO DEFECT: {defect}")
            unmeasured_reasons.update(av.unmeasured)
        report.seconds["audio"] = round(time.monotonic() - t0, 2)
        report.models["audio"] = audio_metrics.AUDIO_LIBRARY
        if fps > 0:
            report.models["av_sync"] = avsync.AVSYNC_METHOD
            report.notes.append(avsync.LIPSYNC_GAP_NOTE)
        else:
            unmeasured_reasons.setdefault(
                "av_sync_offset_ms",
                "AV-sync needs the frame rate: pass fps= to run_video",
            )
        if transcriber is not None:
            report.models["transcriber"] = getattr(transcriber, "model_ref", "")
        if audio_judge is not None:
            report.models["audio_judge"] = getattr(audio_judge, "model_ref", "")
        measured_any = {k for row in rows for k in row.values}
        for name, reason in sorted(unmeasured_reasons.items()):
            if name not in measured_any:
                report.notes.append(f"{name} UNMEASURED: {reason}")

    # --- fine detail: melted faces, pseudo-glyphs, edge halos, texture mush ---
    if use_detail:
        from . import detail as detail_mode
        from .metrics import detail as detail_metrics

        t0 = time.monotonic()
        d_judge = detail_judge or judge
        detail_unmeasured: dict[str, str] = {}
        for row, strip in zip(rows, strips, strict=True):
            dv = detail_mode.detail_verdict(
                strip,
                reference_strip=ref_strips[row.index] if (paired and not _refused) else None,
                judge=d_judge, device=device,
            )
            row.values.update(dv.measured)
            for defect in dv.defects:
                report.notes.append(f"sample {row.index:02d} DETAIL DEFECT: {defect}")
            for flag in dv.flags:
                report.notes.append(f"sample {row.index:02d} DETAIL FLAG: {flag}")
            detail_unmeasured.update(dv.unmeasured)
        report.seconds["detail"] = round(time.monotonic() - t0, 2)
        report.models["detail"] = detail_metrics.DETAIL_LIBRARY
        if d_judge is not None:
            report.models["detail_judge"] = getattr(d_judge, "model_ref", "")
        measured_detail = {k for row in rows for k in row.values}
        for name, reason in sorted(detail_unmeasured.items()):
            if name not in measured_detail:
                report.notes.append(f"{name} UNMEASURED: {reason}")

    # --- preference: an honest gap, stated -----------------------------------
    report.notes.append(
        "video preference UNMEASURED: image preference models cannot see motion "
        "and are not used as a proxy; the tracked integration is "
        "UnifiedReward-2.0 (MIT weights, video pair+point scoring)"
    )

    report.rows = rows
    # ssim / ms_ssim are NOT here: @10 declares them modality "image", so video
    # mode has no path to them at all rather than a flag that could be flipped.
    reported: tuple[tuple[str, str], ...] = (
        ("lpips", "lpips"), ("psnr", "psnr"),
        ("clip_delta", "clip_delta"),
        ("element_recall", "element_recall_delta" if paired else "element_recall_cand"),
        ("text_exact", "text_exact"), ("text_fuzzy", "text_fuzzy"),
    )
    core = {name for name, _ in reported}
    for metric, field in reported:
        if metric in report.unmeasured:
            continue
        summary = suite.summarize(rows, metric, field=field)
        if summary.measured:
            report.dimensions.append(summary)
    for name in sorted({k for row in rows for k in row.values} - core):
        if name in registry.BY_NAME and name not in report.unmeasured:
            spec = registry.BY_NAME[name]
            if spec.modality == "image":
                # A metric declared image-only reaching a clip report is a bug in
                # whatever wrote the row, not a number to publish.
                report.unmeasured[name] = (
                    f"REFUSED: {name} is declared modality 'image' and this is a "
                    "clip report"
                )
                continue
            summary = suite.summarize(rows, name)
            if summary.measured:
                report.dimensions.append(summary)

    total = round(sum(
        v for k, v in report.seconds.items() if k not in suite._DERIVED_SECONDS
    ), 2)
    report.seconds["total"] = total
    report.render_seconds = round(float(render_seconds), 2)
    if render_seconds > 0:
        report.metric_overhead = round(total / float(render_seconds), 4)
    return report


def _mean(values: Iterable[float]) -> float:
    seq = list(values)
    return sum(seq) / len(seq)


__all__ = [
    "DEFAULT_JUDGE_FRAMES",
    "VideoSample",
    "build_video_judge_prompt",
    "run_video",
    "score_video",
    "score_video_ocr_items",
]
