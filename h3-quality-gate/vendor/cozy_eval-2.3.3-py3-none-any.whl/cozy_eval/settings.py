"""The ONE place cozy-eval reads the ambient environment.

Everything the library takes from the environment is a field here, read once
into an :class:`EvalSettings` at the entrypoints — :func:`cozy_eval.resources.
configure` (which runs as the package's first statement) and the CLI, where
``--threads`` is the user interface. Every other module asks :func:`active`;
none reads ``os.environ`` itself (``scripts/fence.py`` enforces it, with the
two documented propagation sites as the only exemptions).

``COZY_EVAL_THREADS`` is NOT a user interface: it is the internal parent->child
propagation channel (the CLI's execve re-exec, pool worker inheritance). Users
set ``--threads`` or call ``configure(threads=...)``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class EvalSettings:
    """Env-sourced configuration, resolved once per process."""

    #: Compute-thread budget, from the internal propagation channel only.
    threads: int | None = None

    #: The ffmpeg VMAF shells out to; points a box whose system ffmpeg lacks
    #: libvmaf at a static build.
    vmaf_ffmpeg: Path = Path("ffmpeg")

    #: Where downloaded checkpoints land; point an offline pod at a pre-baked
    #: directory.
    cache_dir: Path = Path.home() / ".cache" / "cozy-eval"


def _positive_or_none(value: str | None) -> int | None:
    """Ambient garbage degrades to the default and never breaks import."""
    try:
        number = int((value or "").strip())
    except ValueError:
        return None
    return number if number > 0 else None


def _path(name: str, fallback: Path) -> Path:
    value = os.environ.get(name, "").strip()
    return Path(value) if value else fallback


_active: EvalSettings | None = None


def load(*, force: bool = False) -> EvalSettings:
    """Read the environment into the process-wide settings. First call wins."""
    global _active                      # noqa: PLW0603 — process-wide by nature
    if _active is None or force:
        _active = EvalSettings(
            threads=_positive_or_none(os.environ.get("COZY_EVAL_THREADS")),
            vmaf_ffmpeg=_path("VMAF_FFMPEG", Path("ffmpeg")),
            cache_dir=_path("COZY_EVAL_CACHE", Path.home() / ".cache" / "cozy-eval"),
        )
    return _active


def active() -> EvalSettings:
    """The settings in force, loading them on first ask."""
    return _active or load()


__all__ = ["EvalSettings", "active", "load"]
