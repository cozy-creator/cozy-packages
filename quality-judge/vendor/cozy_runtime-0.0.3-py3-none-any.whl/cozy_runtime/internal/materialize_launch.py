"""Exact artifact intake and package-overlay document join.

Tensorhub owns the document schemas and delivery grants.  This module owns the one Runtime
join from their already-fetched exact bytes to :class:`overlay.Input`. Local paths are
deliberately function arguments: they never enter a canonical release document.

cr-048 RETIRED THE BOOT CLOSURE. ``tensorhub.rental_provision_spec/1`` and
``tensorhub.rental_provision_bundle/1`` named one package's whole closure at boot — eight
document roles, one artifact grant per wheel and weight, the whole materialization root
keyed by the bundle digest — which is the pre-#459 one-pod-one-package shape that rev-2's
``DesiredPlacementSet`` + ``ArtifactGrantUpdate`` replaced. The pod now boots to
ready-but-EMPTY: GPU inventory measured, listeners proven, receipt
published, zero placements. What survives here is the DISCIPLINE, not the vehicle:
``fetch_exact`` (one bounded exact-digest HTTPS grant) and ``materialize_objects`` (exact CAS
admission) are the primitives the dynamic grant lane fetches through, and
``package_overlay_input`` is the small source/custom-wheel join a placement converges to.
Only the boot-only bundling retired.
"""

from __future__ import annotations

import hashlib
import os
import stat
import time
import urllib.error
import urllib.parse
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from cozy_runtime.internal import canonical, fill, overlay, provisioned, pull
from cozy_runtime.internal.config import AdapterConfig

PACKAGE_BUNDLE_FORMAT = "tensorhub.package_bundle/2"
ENVIRONMENT_SPEC_FORMAT = "cozy.worker.v1.PackageEnvironmentSpec/2"
RESOLVED_WHEEL_SET_FORMAT = "ResolvedWheelSet/3"
MAX_RESOLUTION_LOCK_BYTES = 16 << 20
MAX_OVERLAY_BYTES = 4 << 30
# The base-worker-image bootstrap creates exactly this container-local Runtime data root.
# Every durable-for-this-pod child stays beneath it; /run/cozy remains restart-local control state.
LOCAL_DATA_ROOT = Path("/var/lib/cozy")
BOOT_ROOT = LOCAL_DATA_ROOT / "boot"
ENVIRONMENT_ROOT = LOCAL_DATA_ROOT / "environments"
LOCAL_ARTIFACT_STORE_ROOT = LOCAL_DATA_ROOT / "store"
ARTIFACT_CACHE_ROOT = LOCAL_DATA_ROOT / "artifacts"
PLANS_ROOT = Path("/run/cozy/binding-plans")
BINDING_DOCUMENTS_ROOT = Path("/run/cozy/binding-documents")
#: The canonical EMPTY ArtifactObjectSet. A pod that boots with no placement holds no
#: objects, and the worker's launch grammar requires the document to exist and be exact
#: rather than letting "absent" mean "anything".
EMPTY_ARTIFACT_OBJECT_SET = b'{"kind":"tensorhub.resolved_object_set/1","roots":[]}'
MAX_ARTIFACT_BYTES = 8 << 30
CHUNK_BYTES = 1 << 20


class LaunchRefusal(Exception):
    """A fail-closed release/grant join verdict with a stable code."""

    def __init__(self, code: str, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


@dataclass(frozen=True, slots=True)
class PreparedBoot:
    """What a pod knows about itself once it is ready and still empty."""

    artifact_store: Path
    artifact_object_set: Path
    artifact_cache: Path


@dataclass(frozen=True, slots=True)
class MaterializedObjects:
    store: Path
    sources: dict[str, dict[str, int]]
    network_cache_degradations: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CacheMount:
    """One attached provider network-cache volume, for :func:`materialize_objects`.

    The retired provision spec was this value's only carrier. Nothing supplies it at boot
    any more — an empty pod materializes nothing — so it arrives with the dynamic grant lane
    that will drive object materialization, or not at all.
    """

    mount_path: Path
    cache_volume_id: str
    provider_volume_id: str


def prepare_boot(
    config: AdapterConfig,
    *,
    boot_root: Path = BOOT_ROOT,
    artifact_store_root: Path = LOCAL_ARTIFACT_STORE_ROOT,
    artifact_cache_root: Path = ARTIFACT_CACHE_ROOT,
) -> PreparedBoot:
    """Bring the pod to READY-BUT-EMPTY: check the deadline, lay two roots, publish one
    empty document. Nothing is read, nothing is fetched, nothing is hashed.

    The deadline check converts a boot that is already too late into a NAMED refusal.
    Tensorhub stops polling at the same instant either way, so all it decides is whether
    the operator reads a reason or reads silence.

    THE POD MEASURES NOTHING ABOUT ITS OWN IMAGE. cr-048 measured the control-Runtime wheel
    baked into the base worker image and reported the digest so "the hub learns a value".
    But the hub pinned that image BY DIGEST — tensorhub registers a base worker image as
    `name@sha256:…` and refuses a tag — so the wheel inside it is a fact the hub CHOSE,
    not one the pod can teach it. Hashing image-resident bytes to echo them back proves
    something the OCI digest already proved before this process existed.

    THE EMPTY OBJECT SET STAYS. It is not a claim to anybody: it is the document the
    worker started three lines later demands by its launch grammar (`--artifact-object-set`
    is required), reads unconditionally the moment a placement carries plans, and compares
    against the model roots that placement uses. Empty is the TRUE answer for a pod holding
    no objects, and it is what lets a weightless placement converge with no grant lane at
    all; withholding it would turn that convergence into a BINDING_UNAVAILABLE fault.
    """

    if time.time() >= config.readiness_deadline_unix:
        raise LaunchRefusal("readiness_deadline_elapsed", str(config.readiness_deadline_unix))
    # Package executors read verified TensorFS objects but never publish them. Root owns
    # the store; execute/read bits admit the fixed executor uid without making any object
    # or directory writable to it.
    _directory(artifact_store_root, mode=0o755)
    _directory(artifact_cache_root)
    _directory(boot_root)
    object_set = boot_root / "artifact-object-set.json"
    _publish_exact(object_set, EMPTY_ARTIFACT_OBJECT_SET, boot_root)
    return PreparedBoot(
        artifact_store=artifact_store_root,
        artifact_object_set=object_set,
        artifact_cache=artifact_cache_root,
    )


def fetch_exact(
    grant: Mapping[str, Any], root: Path, *, deadline: int, allow_local: bool = False
) -> Path:
    """Fetch one bounded exact grant without proxy, redirect, transform, or alias."""

    digest = grant.get("digest")
    length = grant.get("length")
    url = grant.get("url")
    _require_digest(digest, "grant.digest")
    if (
        not isinstance(length, int)
        or isinstance(length, bool)
        or length <= 0
        or length > MAX_ARTIFACT_BYTES
    ):
        raise LaunchRefusal("grant_length_invalid", str(length))
    if not isinstance(url, str):
        raise LaunchRefusal("grant_url_invalid", "URL is not a string")
    parsed = urllib.parse.urlsplit(url)
    if (
        parsed.scheme != "https"
        or not parsed.netloc
        or parsed.username is not None
        or parsed.password is not None
        or parsed.fragment
        or len(url) > 4096
    ):
        raise LaunchRefusal("grant_url_invalid", "grant URL is not one bounded HTTPS authority")
    _directory(root)
    target = root / str(digest).removeprefix("sha256:")
    if target.exists():
        _verify_local(target, str(digest), length)
        return target
    temporary = root / f".fetch-{uuid.uuid4().hex}"
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    measured = hashlib.sha256()
    total = 0
    try:
        timeout = max(float(deadline) - time.time(), 0.001)
        try:
            response = pull.open_guarded(
                url,
                pull.Deadline.after(timeout),
                headers={
                    "Accept-Encoding": "identity",
                    "User-Agent": "cozy-materialize-launch/1",
                },
                allow_local=allow_local,
                no_proxy=True,
            )
        except (OSError, urllib.error.URLError, pull.PullRefusal) as exc:
            raise LaunchRefusal(
                "grant_fetch_failed", f"HTTPS grant fetch failed: {type(exc).__name__}"
            ) from exc
        with response, os.fdopen(descriptor, "wb") as handle:
            descriptor = -1
            encoding = response.headers.get("Content-Encoding", "identity")
            if response.status != 200 or encoding not in {"", "identity"}:
                raise LaunchRefusal("grant_response_invalid", f"status={response.status}")
            stated = response.headers.get("Content-Length")
            if stated is not None and stated != str(length):
                raise LaunchRefusal("grant_length_mismatch", f"header {stated}, expected {length}")
            while True:
                if time.time() >= deadline:
                    raise LaunchRefusal("readiness_deadline_elapsed", str(deadline))
                chunk = response.read(min(CHUNK_BYTES, length + 1 - total))
                if not chunk:
                    break
                total += len(chunk)
                if total > length:
                    raise LaunchRefusal("grant_length_mismatch", f"more than {length} bytes")
                measured.update(chunk)
                handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())
        got = "sha256:" + measured.hexdigest()
        if total != length or got != digest:
            raise LaunchRefusal(
                "grant_identity_mismatch",
                f"measured digest={got} length={total}, expected digest={digest} length={length}",
            )
        os.replace(temporary, target)
        os.chmod(target, 0o400)
        _fsync(root)
        return target
    finally:
        if descriptor >= 0:
            os.close(descriptor)
        temporary.unlink(missing_ok=True)


def materialize_objects(
    grants: Mapping[str, str],
    object_set: provisioned.ArtifactObjectSet,
    *,
    cache: CacheMount | None,
    deadline: int | None,
    store_root: Path,
    allow_local: bool = False,
) -> MaterializedObjects:
    """Admit each exact model closure into the required worker-local TensorFS CAS.

    `grants` is a per-object-id location map — the shape rev-2's `ArtifactGrantUpdate`
    carries. It used to be spelled as `bundle["artifact_grants"]`; the closure vehicle
    retired, the exact-digest admission it drove did not.
    """

    refs = object_set.refs
    required = set(refs)
    missing = sorted(required - set(grants))
    if missing:
        raise LaunchRefusal("object_grant_missing", missing[0])
    cache_root: Path | None = None
    if cache is not None:
        cache_root = cache.mount_path / "tensorfs"
        _require_separate_store_roots(store_root, cache.mount_path, cache_root)
    degradations: set[str] = set()
    source_by_object: dict[str, str] = {}
    try:
        if not object_set.roots:
            _directory(store_root)
            return MaterializedObjects(
                store=store_root,
                sources=_source_usage(source_by_object, refs),
                network_cache_degradations=(),
            )
        tensorfs = fill.tensorfs_module()
        store = pull.open_store(tensorfs, store_root)
        cache_store = None
        if cache is not None:
            assert cache_root is not None
            cache_store = _open_cache_store(tensorfs, cache.mount_path, cache_root, degradations)
        for group in object_set.roots:
            closure = (group.root, *group.objects)
            rows = sorted(
                (
                    pull.Read(
                        object_id=ref.digest,
                        length=ref.length,
                        url=grants[ref.digest],
                    )
                    for ref in closure
                ),
                key=lambda row: row.object_id,
            )
            timeout = None if deadline is None else float(deadline) - time.time()
            if timeout is not None and timeout <= 0:
                raise LaunchRefusal("readiness_deadline_elapsed", str(deadline))
            outcome = pull.pull_granted_snapshot(
                tensorfs,
                store,
                group.root.digest,
                group.root.length,
                rows,
                timeout=timeout,
                session="provision-" + group.root.digest.removeprefix("sha256:")[:12],
                cache_store=cache_store,
                allow_local=allow_local,
            )
            for object_id, source in outcome.sources.items():
                source_by_object.setdefault(object_id, source)
            degradations.update(outcome.cache_degradations)
        if set(source_by_object) != required:
            raise LaunchRefusal(
                "object_materialization_refused", "source evidence does not cover the object set"
            )
    except LaunchRefusal:
        raise
    except pull.PullRefusal as exc:
        raise LaunchRefusal("object_materialization_refused", f"{exc.code}: {exc.message}") from exc
    except Exception as exc:
        raise LaunchRefusal(
            "object_materialization_refused", f"TensorFS unavailable: {type(exc).__name__}"
        ) from exc
    return MaterializedObjects(
        store=store_root,
        sources=_source_usage(source_by_object, refs),
        network_cache_degradations=tuple(sorted(degradations)),
    )


def _open_cache_store(
    tensorfs: Any, cache_mount: Path, cache_root: Path, degradations: set[str]
) -> Any | None:
    try:
        if not stat.S_ISDIR(cache_mount.stat().st_mode):
            raise NotADirectoryError(cache_mount)
        return pull.open_store(tensorfs, cache_root)
    except (OSError, pull.PullRefusal):
        degradations.add("unavailable")
        return None


def _source_usage(
    source_by_object: Mapping[str, str], refs: Mapping[str, int]
) -> dict[str, dict[str, int]]:
    usage = {source: {"bytes": 0, "objects": 0} for source in ("cloud", "local", "network_cache")}
    for object_id, source in source_by_object.items():
        row = usage.get(source)
        if row is None or object_id not in refs:
            raise LaunchRefusal("object_materialization_refused", "invalid source evidence")
        row["bytes"] += refs[object_id]
        row["objects"] += 1
    return usage


def _require_separate_store_roots(local_store: Path, cache_mount: Path, cache_root: Path) -> None:
    """Refuse lexical, symlink, and bind-mount aliases before either store can be touched."""

    def overlaps(left: Path, right: Path) -> bool:
        return left == right or left in right.parents or right in left.parents

    lexical_local = Path(os.path.abspath(local_store))
    lexical_mount = Path(os.path.abspath(cache_mount))
    lexical_cache = Path(os.path.abspath(cache_root))
    if overlaps(lexical_local, lexical_mount) or overlaps(lexical_local, lexical_cache):
        raise LaunchRefusal("artifact_store_alias", "local CAS and network cache paths overlap")
    try:
        resolved_local = local_store.resolve(strict=False)
        resolved_mount = cache_mount.resolve(strict=False)
        resolved_cache = cache_root.resolve(strict=False)
    except OSError:
        resolved_local, resolved_mount, resolved_cache = (
            lexical_local,
            lexical_mount,
            lexical_cache,
        )
    if overlaps(resolved_local, resolved_mount) or overlaps(resolved_local, resolved_cache):
        raise LaunchRefusal("artifact_store_alias", "local CAS and network cache paths alias")

    local_lineage = (local_store, *local_store.parents[:-1])
    cache_lineage = (cache_mount, *cache_mount.parents[:-1])
    try:
        if any(
            candidate.exists() and os.path.samefile(candidate, cache_mount)
            for candidate in local_lineage
        ) or any(
            candidate.exists() and os.path.samefile(candidate, local_store)
            for candidate in cache_lineage
        ):
            raise LaunchRefusal("artifact_store_alias", "local CAS and network cache paths alias")
        if (
            cache_root.exists()
            and local_store.exists()
            and os.path.samefile(local_store, cache_root)
        ):
            raise LaunchRefusal("artifact_store_alias", "local CAS and network cache paths alias")
    except OSError:
        # An unavailable cache is allowed; lexical and resolvable aliases have already refused.
        return


def _ref(value: object, name: str, *, allow_extra: bool = False) -> dict[str, Any]:
    if (
        not isinstance(value, dict)
        or not {"digest", "length"}.issubset(value)
        or (not allow_extra and set(value) != {"digest", "length"})
    ):
        raise LaunchRefusal(f"{name}_ref_invalid", "reference is not {digest,length}")
    digest = value.get("digest")
    length = value.get("length")
    _require_digest(digest, f"{name}.digest")
    if (
        not isinstance(length, int)
        or isinstance(length, bool)
        or length <= 0
        or length > MAX_ARTIFACT_BYTES
    ):
        raise LaunchRefusal(f"{name}_ref_invalid", "length is not positive and bounded")
    return {"digest": digest, "length": length}


def _verify_local(path: Path, digest: str, length: int) -> None:
    _require_digest(digest, "local.digest")
    try:
        info = path.lstat()
    except OSError as exc:
        raise LaunchRefusal("local_artifact_unreadable", f"{path}: {exc}") from exc
    if (
        not path.is_absolute()
        or not stat.S_ISREG(info.st_mode)
        or info.st_size != length
        or length > MAX_ARTIFACT_BYTES
    ):
        raise LaunchRefusal("local_artifact_invalid", str(path))
    measured = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(CHUNK_BYTES):
            measured.update(chunk)
    got = "sha256:" + measured.hexdigest()
    if got != digest:
        raise LaunchRefusal("local_artifact_digest_mismatch", f"measured {got}, expected {digest}")


def _publish_exact(target: Path, payload: bytes, root: Path) -> None:
    """Write one exact document once; an exact replay converges, different bytes refuse."""

    if target.exists():
        if target.read_bytes() != payload:
            raise LaunchRefusal("boot_document_conflict", str(target))
        return
    temporary = root / f".boot-{uuid.uuid4().hex}"
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o400)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temporary, target)
        except FileExistsError:
            if target.read_bytes() != payload:
                raise LaunchRefusal("boot_document_conflict", str(target)) from None
            return
        _fsync(root)
    finally:
        temporary.unlink(missing_ok=True)


def _directory(path: Path, *, mode: int = 0o700) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    info = path.lstat()
    if not path.is_absolute() or not stat.S_ISDIR(info.st_mode):
        raise LaunchRefusal("provision_store_invalid", str(path))
    path.chmod(mode)


def _fsync(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def baked_base_manifest(
    manifest_path: Path = overlay.DEFAULT_BASE_MANIFEST,
) -> overlay.BaseManifest:
    """Read the trusted image-owned base profile before any hardware probe."""

    try:
        raw = manifest_path.read_bytes()
    except OSError as exc:
        raise LaunchRefusal("control_runtime_manifest_unreadable", str(exc)) from exc
    manifest_digest = "sha256:" + hashlib.sha256(raw).hexdigest()
    try:
        return overlay.parse_base_manifest(raw, manifest_digest)
    except overlay.OverlayRefusal as exc:
        raise LaunchRefusal(exc.code, exc.detail) from exc


def control_runtime_digest(
    manifest_path: Path = overlay.DEFAULT_BASE_MANIFEST,
    *,
    manifest: overlay.BaseManifest | None = None,
) -> str:
    """Read the exact image-owned control Runtime wheel identity.

    This is not the OCI manifest digest and it is not accepted from provider environment.
    The registered base worker image bakes the complete wheelhouse manifest; Runtime
    validates those exact canonical bytes and reports its one ``cozy-runtime`` wheel fact
    so the hub can compare it with the selected image record.
    """

    if manifest is None:
        manifest = baked_base_manifest(manifest_path)
    matches = [wheel.digest for wheel in manifest.wheels if wheel.distribution == "cozy-runtime"]
    if len(matches) != 1:
        raise LaunchRefusal(
            "control_runtime_identity_invalid",
            f"base manifest names {len(matches)} cozy-runtime wheels",
        )
    return matches[0]


def package_overlay_input(
    *,
    environment_spec_bytes: bytes,
    package_bundle_bytes: bytes,
    resolved_wheel_set_bytes: bytes,
    wheelhouse_manifest_bytes: bytes,
    wheel_paths: Mapping[str, Path],
    verified_wheels: Mapping[str, overlay.VerifiedFile] | None = None,
) -> overlay.Input:
    """Join exact publication documents and package-only wheel grants."""

    spec = _document(environment_spec_bytes, "environment_spec")
    bundle = _document(package_bundle_bytes, "package_bundle")
    resolved = _document(resolved_wheel_set_bytes, "resolved_wheel_set")
    _closed(
        spec,
        {
            "compatibility_profile",
            "package_bundle_digest",
            "format",
            "platform_target",
            "project_wheel_digest",
            "wheelhouse_manifest_digest",
        },
        "environment_spec",
    )
    if spec["format"] != ENVIRONMENT_SPEC_FORMAT:
        raise LaunchRefusal("environment_spec_format", str(spec["format"]))
    _closed(
        bundle,
        {
            "package_descriptor",
            "package_release_id",
            "format",
            "project_wheel",
            "resolved_wheel_set",
            "source_archive",
            "source_lock",
            "wheelhouse_manifest",
        },
        "package_bundle",
    )
    if bundle["format"] != PACKAGE_BUNDLE_FORMAT:
        raise LaunchRefusal("package_bundle_format", str(bundle["format"]))
    _ref(bundle["source_archive"], "source_archive")
    _ref(bundle["source_lock"], "source_lock")
    _closed(
        resolved,
        {
            "compatibility_profile",
            "format",
            "overlay_bytes",
            "platform_target",
            "resolution_lock_digest",
            "resolution_lock_length",
            "wheelhouse_manifest_digest",
            "wheels",
        },
        "resolved_wheel_set",
    )
    if resolved["format"] != RESOLVED_WHEEL_SET_FORMAT:
        raise LaunchRefusal("resolved_wheel_set_format", str(resolved["format"]))
    _require_digest(resolved["resolution_lock_digest"], "resolved_wheel_set.resolution_lock_digest")
    resolution_lock_length = resolved["resolution_lock_length"]
    if (
        not isinstance(resolution_lock_length, int)
        or isinstance(resolution_lock_length, bool)
        or not 0 < resolution_lock_length <= MAX_RESOLUTION_LOCK_BYTES
    ):
        raise LaunchRefusal(
            "resolved_wheel_set_invalid", "resolution_lock_length is not positive and bounded"
        )
    _require_digest(spec["package_bundle_digest"], "environment_spec.package_bundle_digest")
    _require_digest(spec["project_wheel_digest"], "environment_spec.project_wheel_digest")
    _require_digest(
        spec["wheelhouse_manifest_digest"], "environment_spec.wheelhouse_manifest_digest"
    )
    _matches(package_bundle_bytes, str(spec["package_bundle_digest"]), "package_bundle")
    _matches(
        wheelhouse_manifest_bytes,
        str(spec["wheelhouse_manifest_digest"]),
        "wheelhouse_manifest",
    )
    try:
        base_manifest = overlay.parse_base_manifest(
            wheelhouse_manifest_bytes, str(spec["wheelhouse_manifest_digest"])
        )
    except overlay.OverlayRefusal as exc:
        raise LaunchRefusal(exc.code, exc.detail) from exc
    _ref_matches(bundle["resolved_wheel_set"], resolved_wheel_set_bytes, "resolved_wheel_set")
    _ref_matches(bundle["wheelhouse_manifest"], wheelhouse_manifest_bytes, "wheelhouse_manifest")
    if bundle["wheelhouse_manifest"] != {
        "digest": spec["wheelhouse_manifest_digest"],
        "length": len(wheelhouse_manifest_bytes),
    }:
        raise LaunchRefusal(
            "wheelhouse_manifest_ref_mismatch", "bundle and environment spec disagree"
        )
    if resolved["wheelhouse_manifest_digest"] != spec["wheelhouse_manifest_digest"]:
        raise LaunchRefusal(
            "wheelhouse_manifest_ref_mismatch", "resolved set and environment spec disagree"
        )
    if not isinstance(spec["platform_target"], dict) or not (
        spec["platform_target"]
        == resolved["platform_target"]
        == dict(base_manifest.platform_target)
    ):
        raise LaunchRefusal("platform_target_mismatch", "release documents disagree")
    if not isinstance(spec["compatibility_profile"], dict) or not (
        spec["compatibility_profile"]
        == resolved["compatibility_profile"]
        == dict(base_manifest.compatibility_profile)
    ):
        raise LaunchRefusal("compatibility_profile_mismatch", "release documents disagree")

    project = _wheel(bundle["project_wheel"], "project", import_roots=True)
    if project.tags != ("py3-none-any",) or not project.filename.endswith("-py3-none-any.whl"):
        raise LaunchRefusal("project_wheel_not_pure", "project wheel must be exactly py3-none-any")
    if project.digest != spec["project_wheel_digest"]:
        raise LaunchRefusal("project_wheel_mismatch", project.digest)
    wheels = [project]
    custom_wheels = _wheels(resolved["wheels"], "bundle", import_roots=True)
    overlay_bytes = resolved["overlay_bytes"]
    measured_custom_bytes = sum(wheel.length for wheel in custom_wheels)
    if (
        not isinstance(overlay_bytes, int)
        or isinstance(overlay_bytes, bool)
        or overlay_bytes != measured_custom_bytes
        or overlay_bytes > MAX_OVERLAY_BYTES
    ):
        raise LaunchRefusal(
            "resolved_wheel_set_overlay_bytes_mismatch",
            f"declared={overlay_bytes!r} measured_custom={measured_custom_bytes}",
        )
    if project.length > MAX_OVERLAY_BYTES - measured_custom_bytes:
        raise LaunchRefusal(
            "overlay_byte_budget_exceeded",
            f"project_plus_custom={project.length + measured_custom_bytes} "
            f"budget={MAX_OVERLAY_BYTES}",
        )
    wheels.extend(custom_wheels)
    digests = [wheel.digest for wheel in wheels]
    distributions = [wheel.distribution for wheel in wheels]
    if len(digests) != len(set(digests)):
        raise LaunchRefusal("wheel_digest_duplicate", "one digest has multiple owners")
    if len(distributions) != len(set(distributions)):
        raise LaunchRefusal("wheel_distribution_duplicate", "one distribution has multiple owners")
    granted_digests = {wheel.digest for wheel in wheels}
    if set(wheel_paths) != granted_digests:
        missing = sorted(granted_digests - set(wheel_paths))
        extra = sorted(set(wheel_paths) - granted_digests)
        raise LaunchRefusal("wheel_grant_set_mismatch", f"missing={missing[:1]} extra={extra[:1]}")
    return overlay.Input(
        environment_spec_digest=_digest(environment_spec_bytes),
        base_family_digest=_digest(wheelhouse_manifest_bytes),
        project_wheel_digest=project.digest,
        wheels=tuple(wheels),
        grants=tuple(
            overlay.BlobGrant(
                wheel.digest,
                wheel.length,
                wheel_paths[wheel.digest],
                (verified_wheels or {}).get(wheel.digest),
            )
            for wheel in wheels
        ),
    )


def _document(raw: bytes, name: str) -> dict[str, Any]:
    try:
        value = canonical.parse_canonical(raw)
    except canonical.CanonicalError as exc:
        raise LaunchRefusal(f"{name}_invalid", str(exc)) from exc
    if not isinstance(value, dict):
        raise LaunchRefusal(f"{name}_invalid", "document is not an object")
    return value


def _closed(value: object, keys: set[str], name: str) -> None:
    if not isinstance(value, dict) or set(value) != keys:
        fields = sorted(value) if isinstance(value, dict) else type(value).__name__
        raise LaunchRefusal(f"{name}_invalid", f"fields={fields} expected={sorted(keys)}")


def _ref_matches(value: object, raw: bytes, name: str, *, allow_extra: bool = False) -> None:
    if (
        not isinstance(value, dict)
        or not {"digest", "length"}.issubset(value)
        or (not allow_extra and set(value) != {"digest", "length"})
    ):
        raise LaunchRefusal(f"{name}_ref_invalid", "reference is not {digest,length}")
    digest = value.get("digest")
    length = value.get("length")
    _require_digest(digest, f"{name}.digest")
    if not isinstance(length, int) or isinstance(length, bool) or length <= 0:
        raise LaunchRefusal(f"{name}_ref_invalid", "length is not positive")
    if length != len(raw):
        raise LaunchRefusal(f"{name}_length_mismatch", f"measured {len(raw)}, expected {length}")
    _matches(raw, str(digest), name)


def _matches(raw: bytes, digest: str, name: str) -> None:
    if _digest(raw) != digest:
        raise LaunchRefusal(
            f"{name}_digest_mismatch", f"measured {_digest(raw)}, expected {digest}"
        )


def _wheels(value: object, owner: str, *, import_roots: bool = False) -> list[overlay.Wheel]:
    if not isinstance(value, list):
        raise LaunchRefusal(f"{owner}_wheel_inventory_invalid", "wheels is not a list")
    wheels = [_wheel(row, owner, import_roots=import_roots) for row in value]
    names = [wheel.distribution for wheel in wheels]
    if names != sorted(names) or len(names) != len(set(names)):
        raise LaunchRefusal(
            f"{owner}_wheel_inventory_invalid", "distributions are not sorted unique"
        )
    return wheels


def _wheel(value: object, owner: str, *, import_roots: bool = False) -> overlay.Wheel:
    keys = {"digest", "distribution", "filename", "length", "tags", "version"}
    if import_roots:
        keys.add("import_roots")
    if not isinstance(value, dict) or set(value) != keys:
        raise LaunchRefusal(f"{owner}_wheel_invalid", "wheel row has the wrong fields")
    digest = value["digest"]
    _require_digest(digest, f"{owner}_wheel.digest")
    distribution = value["distribution"]
    filename = value["filename"]
    version = value["version"]
    strings = (distribution, filename, version)
    if (
        not all(isinstance(item, str) and item for item in strings)
        or not overlay.normalized_distribution(str(distribution))
        or not overlay.valid_wheel_filename(str(filename))
        or not overlay.valid_wheel_version(str(version))
    ):
        raise LaunchRefusal(f"{owner}_wheel_invalid", "wheel strings are empty or invalid")
    length = value["length"]
    tags = value["tags"]
    if (
        not isinstance(length, int)
        or isinstance(length, bool)
        or length <= 0
        or length > overlay.MAX_WHEEL_BYTES
    ):
        raise LaunchRefusal(f"{owner}_wheel_invalid", "length is not positive and bounded")
    if (
        not isinstance(tags, list)
        or not tags
        or not all(isinstance(tag, str) and overlay.valid_wheel_tag(tag) for tag in tags)
        or tags != sorted(set(tags))
    ):
        raise LaunchRefusal(f"{owner}_wheel_invalid", "tags are not non-empty sorted unique")
    roots = value.get("import_roots", [])
    if (
        not isinstance(roots, list)
        or not all(isinstance(root, str) and overlay.valid_import_root(root) for root in roots)
        or roots != sorted(set(roots))
    ):
        raise LaunchRefusal(
            f"{owner}_wheel_invalid", "import_roots are not sorted unique identifiers"
        )
    return overlay.Wheel(
        distribution=value["distribution"],
        version=value["version"],
        filename=value["filename"],
        digest=str(digest),
        length=length,
        tags=tuple(tags),
        owner={"project": "project", "bundle": "custom"}[owner],
        import_roots=tuple(roots),
    )


def _require_digest(value: object, name: str) -> None:
    if not isinstance(value, str) or canonical.DIGEST_RE.fullmatch(value) is None:
        raise LaunchRefusal(f"{name}_invalid", "not sha256:<64 lowercase hex>")


def _digest(raw: bytes) -> str:
    return "sha256:" + hashlib.sha256(raw).hexdigest()
