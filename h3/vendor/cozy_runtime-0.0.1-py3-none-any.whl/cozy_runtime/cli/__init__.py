"""The cozy-runtime CLI: a tiny local-coordinator adapter over the runtime core (§8)."""
