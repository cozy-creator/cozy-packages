"""The accumulator API: ``update()`` per unit, ``compute()`` at the end.

STABILITY: locked core (v0.x).

torchmetrics' dual API is the right shape and this is our torch-free reading of
it. Some things do not fit one call: a 15-second clip's frames, a held-out set
scored at every training checkpoint, a corpus streamed off disk one render at a
time. Those want state that survives between calls.

What is deliberately NOT here: ``nn.Module`` inheritance, device placement,
distributed reduction, ``dist_sync_on_step``. A library whose base install is
numpy + msgspec cannot inherit from torch, and the state a pooling accumulator
needs is a handful of floats and at most one plain array. So:

* state is plain Python floats and numpy arrays, readable through :meth:`state`
  and restorable through :meth:`load_state` — checkpoint it, ship it between
  processes, sum it across shards;
* the accumulated and one-shot paths call the SAME pooling function, chosen by
  the metric's ``pool`` field in the registry. They cannot drift into
  disagreement, because there is only one implementation of each pooling rule
  and neither path owns it.

That last point is the pin. ``pool("mean", values)`` and a running
``total/n`` over the same values in the same order are the same floating-point
operation sequence, so the two paths agree BIT FOR BIT rather than to a
tolerance. ``median``/``harmonic_mean`` retain the values (documented O(n)
state) for the same reason: an approximate streaming quantile would be a
different number wearing the same name, which is exactly what
:mod:`cozy_eval.identity` exists to prevent.

Example::

    from cozy_eval import MetricAccumulator

    acc = MetricAccumulator("adjacent_frame_corr")
    for clip in stream:                       # never all in memory at once
        acc.update(adjacent_frame_corr(clip), unit=clip.name)
    summary = acc.compute()                   # a DimensionSummary, as the suite emits
"""

from __future__ import annotations

import math
from collections.abc import Iterable, Sequence
from typing import Any

from . import registry
from .errors import ConfigError


def pool(kind: str, values: Sequence[float]) -> float:
    """Reduce per-unit values to the reported number. The ONE implementation.

    Both the functional path and :class:`MetricAccumulator` call this, so
    "accumulated equals one-shot" is structural rather than a coincidence two
    code paths have to keep re-earning.
    """
    if not values:
        raise ConfigError(f"cannot pool an empty sequence with {kind!r}")
    if kind == "mean":
        total = 0.0
        for v in values:
            total += v
        return total / len(values)
    if kind == "min":
        return float(min(values))
    if kind == "max":
        return float(max(values))
    if kind == "median":
        ordered = sorted(values)
        mid = len(ordered) // 2
        if len(ordered) % 2:
            return float(ordered[mid])
        return (float(ordered[mid - 1]) + float(ordered[mid])) / 2.0
    if kind == "harmonic_mean":
        # VMAF pooling: a clip that falls apart for 10% of its frames must not
        # read ~90. A single zero makes the whole pool zero, which is correct.
        total = 0.0
        for v in values:
            if v <= 0.0:
                return 0.0
            total += 1.0 / v
        return len(values) / total
    raise ConfigError(f"unknown pooling {kind!r}; known: {list(registry.POOLS)}")


def pool_for(metric: str) -> str:
    """The pooling rule the registry declares for one metric."""
    return registry.spec(metric).pool


class MetricAccumulator:
    """Streaming ``update()``/``compute()`` for one metric.

    Reads its direction and its pooling rule from the registry, so an
    accumulator over a third-party registered metric behaves exactly like one
    over a builtin. ``compute()`` returns the same
    :class:`~cozy_eval.suite.DimensionSummary` the one-shot path emits — mean or
    declared pool, the worst unit, and which unit that was.
    """

    __slots__ = (
        "_index",
        "_metric",
        "_n",
        "_retained",
        "_spec",
        "_total",
        "_units",
        "_worst",
        "_worst_index",
        "_worst_unit",
    )

    def __init__(self, metric: str) -> None:
        self._metric = metric
        self._spec = registry.spec(metric)
        self.reset()

    def reset(self) -> None:
        """Drop all state. The accumulator is reusable across checkpoints."""
        self._n = 0
        self._total = 0.0
        self._worst: float | None = None
        self._worst_index = -1
        self._worst_unit = ""
        self._index = 0
        self._retained: list[float] = []
        self._units: list[str] = []

    @property
    def metric(self) -> str:
        return self._metric

    @property
    def n(self) -> int:
        """How many units have been folded in."""
        return self._n

    def _is_worse(self, value: float) -> bool:
        if self._worst is None:
            return True
        # Same tie-break as the one-shot path's min()/max(): the FIRST extreme
        # wins, so both paths name the same worst unit.
        return value < self._worst if self._spec.higher_is_better else value > self._worst

    def update(self, value: float | None, *, unit: str = "", index: int | None = None) -> None:
        """Fold in one unit's value. ``None`` is skipped — an unmeasured unit is
        not a zero, and counting it as one is how an unscored row becomes a
        confident bad number."""
        if value is None:
            self._index += 1
            return
        value = float(value)
        if math.isnan(value):
            raise ConfigError(
                f"{self._metric}: refusing to accumulate NaN. A metric that could not "
                "be computed reports None (unmeasured), never a NaN that pools into "
                "a number nobody can trace back."
            )
        idx = self._index if index is None else index
        self._index = idx + 1
        self._n += 1
        self._total += value
        # Retained only where the pooling genuinely needs every value. mean/min/
        # max stay O(1); an approximate streaming median would be a different
        # number under the same name.
        if self._spec.pool in ("median", "harmonic_mean"):
            self._retained.append(value)
        if self._is_worse(value):
            self._worst = value
            self._worst_index = idx
            self._worst_unit = unit

    def update_many(
        self, values: Iterable[float | None], *, units: Sequence[str] | None = None
    ) -> None:
        """Fold in a batch, in order."""
        for i, value in enumerate(values):
            self.update(value, unit=units[i] if units and i < len(units) else "")

    def compute(self) -> Any:
        """The pooled result, as the same struct the one-shot suite emits."""
        from .suite import DimensionSummary

        summary = DimensionSummary(
            dimension=self._spec.dimension,
            metric=self._metric,
            measured=self._n > 0,
            gated=self._spec.gated,
            higher_is_better=self._spec.higher_is_better,
        )
        if self._n == 0 or self._worst is None:
            summary.note = "unmeasured: no unit produced a value"
            return summary
        if self._spec.pool == "mean":
            summary.mean = self._total / self._n
        else:
            summary.mean = pool(self._spec.pool, self._retained)
        summary.worst = float(self._worst)
        summary.worst_index = self._worst_index
        summary.worst_row = self._worst_unit or f"sample {self._worst_index:02d}"
        return summary

    def state(self) -> dict[str, Any]:
        """The accumulator's whole state as plain numbers and one plain list.

        Nothing here is a tensor, a device handle, or a closure — so it pickles,
        it serializes, and it can be carried from a worker back to a driver.
        """
        return {
            "metric": self._metric,
            "impl": self._spec.impl,
            "n": self._n,
            "total": self._total,
            "worst": self._worst,
            "worst_index": self._worst_index,
            "worst_unit": self._worst_unit,
            "index": self._index,
            "retained": list(self._retained),
        }

    def load_state(self, state: dict[str, Any]) -> None:
        """Restore state produced by :meth:`state`, refusing a foreign impl."""
        from .errors import MetricIdentityError

        if state.get("metric") != self._metric:
            raise ConfigError(
                f"state is for metric {state.get('metric')!r}, not {self._metric!r}"
            )
        if state.get("impl") != self._spec.impl:
            raise MetricIdentityError(
                f"accumulator state for {self._metric!r} was produced at impl "
                f"{state.get('impl')!r} but this build is at {self._spec.impl!r}: "
                "resuming would pool two different quantities into one number"
            )
        self._n = int(state["n"])
        self._total = float(state["total"])
        self._worst = None if state["worst"] is None else float(state["worst"])
        self._worst_index = int(state["worst_index"])
        self._worst_unit = str(state["worst_unit"])
        self._index = int(state["index"])
        self._retained = list(state["retained"])

    def merge(self, other: MetricAccumulator) -> None:
        """Fold another accumulator's state in — shard-and-reduce.

        HONEST LIMIT, measured: a merge REASSOCIATES the running sum, so a
        mean-pooled metric agrees with a single-process run to floating-point
        reassociation and NOT bit for bit. Observed over 480 real per-frame
        values split in half: 0.5068767735566444 merged against
        0.5068767735566442 single-process — one unit in the last place.

        That is stated rather than papered over, because the bit-identity this
        module does promise is a different and stronger claim: the ONE-SHOT and
        STREAMED paths over the same values in the same order are the same
        floating-point operation sequence, and those agree exactly. Sharding
        changes the order; nothing can make a reassociated float sum identical.
        If you need a digest-stable pooled number, pool once or pool the shards'
        retained values, and do not shard a mean.
        """
        if other._metric != self._metric:
            raise ConfigError(
                f"cannot merge {other._metric!r} state into {self._metric!r}"
            )
        self._n += other._n
        self._total += other._total
        self._retained.extend(other._retained)
        if other._worst is not None and self._is_worse(other._worst):
            self._worst = other._worst
            self._worst_index = other._worst_index
            self._worst_unit = other._worst_unit
        self._index += other._index


class SuiteAccumulator:
    """Many metrics at once, fed one row at a time.

    The corpus-sized shape: a scoring loop hands each finished sample over and
    never holds the corpus in memory. ``compute()`` returns the dimension
    summaries a report carries.
    """

    def __init__(self, metrics: Iterable[str]) -> None:
        self._accs = {name: MetricAccumulator(name) for name in metrics}
        if not self._accs:
            raise ConfigError("a SuiteAccumulator needs at least one metric")

    @property
    def metrics(self) -> tuple[str, ...]:
        return tuple(self._accs)

    def update(self, values: dict[str, float | None], *, unit: str = "") -> None:
        """Fold in one sample's values, keyed by metric name.

        A metric absent from ``values`` is unmeasured for this sample, which is
        not the same fact as a zero and is not recorded as one.
        """
        unknown = set(values) - set(self._accs)
        if unknown:
            raise ConfigError(
                f"values for metrics this accumulator does not carry: {sorted(unknown)}; "
                f"it carries {sorted(self._accs)}"
            )
        for name, acc in self._accs.items():
            acc.update(values.get(name), unit=unit)

    def accumulator(self, metric: str) -> MetricAccumulator:
        return self._accs[metric]

    def compute(self) -> list[Any]:
        """Dimension summaries for every metric that measured something."""
        out = [acc.compute() for acc in self._accs.values()]
        return [s for s in out if s.measured]

    def state(self) -> dict[str, Any]:
        return {name: acc.state() for name, acc in self._accs.items()}

    def impls(self) -> dict[str, str]:
        """``{metric: impl}`` for everything this run accumulated — what the
        report stamps so a later reader can tell whether the numbers compare."""
        return {name: registry.spec(name).impl for name in self._accs}


__all__ = ["MetricAccumulator", "SuiteAccumulator", "pool", "pool_for"]
