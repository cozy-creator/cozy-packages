"""Metric identity: a name does not identify a number, ``(name, impl)`` does.

STABILITY: locked core (v0.x).

clean-fid is the governing evidence. Same-named FID disagrees by whole points
across implementations purely on resize filter and image quantization — not a
bug in either implementation, just two defensible readings of one published
method. Every quoted FID comparison across papers that did not control for it
was comparing two different quantities under one name. That is the same incident
class as our two-implementations nibble-order defect, and the same fix applies:
version the implementation, carry the version with the value, and refuse to
subtract two values that do not agree on it.

So:

* ``METRIC_SET_VERSION`` identifies the TABLE — which metrics exist, what they
  mean, which ones gate.
* ``MetricSpec.impl`` identifies the MATH of one metric. Bump it whenever the
  number produced on unchanged input can change.
* A :class:`ScoreRow` carries both, so a banked number stays interpretable by a
  version that did not write it.
* :func:`delta` and :func:`require_same_impl` REFUSE across differing impls.

The refusal is the point. A silent delta between ``lpips@1.0`` and ``lpips@1.1``
looks exactly like a quality regression and is indistinguishable from one at
read time, which is how a resize-filter change becomes a rejected checkpoint.
"""

from __future__ import annotations

from collections.abc import Iterable

import msgspec

from . import registry
from .errors import MetricIdentityError


class ScoreRow(msgspec.Struct, frozen=True, kw_only=True):
    """One measured number, with the identity needed to compare it to another.

    ``metric_set`` is recorded beside ``impl`` rather than instead of it: the
    table version tells a reader which metrics existed, the impl version tells
    them whether this particular number is the same quantity as that one.
    """

    metric: str
    impl: str
    value: float
    #: The registry table this row was produced under.
    metric_set: str = registry.METRIC_SET_VERSION
    #: Free label for the thing scored — a sample id, an arm name, a clip path.
    unit: str = ""

    @property
    def key(self) -> tuple[str, str]:
        return (self.metric, self.impl)


def row(metric: str, value: float, *, unit: str = "") -> ScoreRow:
    """Build a :class:`ScoreRow`, taking the impl version from the registry.

    The ONLY constructor a scoring path should use: it makes the recorded impl
    the one that actually computed the number, rather than one a caller typed.
    """
    spec = registry.spec(metric)
    return ScoreRow(metric=metric, impl=spec.impl, value=float(value), unit=unit)


def require_same_impl(a: ScoreRow, b: ScoreRow) -> None:
    """Raise unless two rows are the same quantity. The typed refusal."""
    if a.metric != b.metric:
        raise MetricIdentityError(
            f"cannot compare {a.metric!r} to {b.metric!r}: different metrics"
        )
    if a.impl != b.impl:
        raise MetricIdentityError(
            f"cannot compare {a.metric!r} across implementation versions "
            f"{a.impl!r} and {b.impl!r}: a metric NAME does not identify a number. "
            "The two rows were produced by different math, so their difference is "
            "not a quality delta — clean-fid measured same-named FID disagreeing by "
            "whole points on resize filter alone. Re-score both arms under one impl, "
            "or report the two numbers separately and say so."
        )


def delta(candidate: ScoreRow, reference: ScoreRow) -> float:
    """``candidate - reference``, or a typed refusal if they are not comparable."""
    require_same_impl(candidate, reference)
    return candidate.value - reference.value


def impls(names: Iterable[str] | None = None) -> dict[str, str]:
    """The ``{metric: impl}`` map to stamp into a report.

    A report that records this stays interpretable later: a reader can tell
    whether today's ``lpips`` is the same quantity as the banked one, instead of
    assuming it.
    """
    if names is None:
        return {m.name: m.impl for m in registry.REGISTRY}
    return {n: registry.spec(n).impl for n in names}


def require_comparable(a: dict[str, str], b: dict[str, str]) -> None:
    """Raise if two reports' impl maps disagree on any metric they share.

    What a consumer calls before diffing two banked reports. Metrics present in
    only one report are not a conflict — that is a coverage difference, and it
    is visible; a silently changed impl is not.
    """
    clashes = sorted(
        (name, a[name], b[name]) for name in a.keys() & b.keys() if a[name] != b[name]
    )
    if clashes:
        detail = ", ".join(f"{n}: {x!r} vs {y!r}" for n, x, y in clashes)
        raise MetricIdentityError(
            f"these reports disagree on {len(clashes)} metric implementation "
            f"version(s) and cannot be diffed: {detail}. The shared metric names do "
            "not name shared quantities. Re-score one side under the other's impl."
        )


__all__ = [
    "ScoreRow",
    "delta",
    "impls",
    "require_comparable",
    "require_same_impl",
    "row",
]
