"""The one error hierarchy. Every exception this library raises is a
:class:`CozyEvalError`.

The distinction the classes draw is the one a caller can act on:

  ConfigError    you passed something wrong — an unknown set name, a bad
                 argument, mismatched input lengths. Fix the call.
  DataError      a checklist / prompt set / spec on disk is malformed or
                 internally inconsistent. Fix the data.
  RegistryError  a metric registration or lookup is invalid. Fix the metric.
  MetricIdentityError
                 two rows carrying one metric name were produced by different
                 implementation versions. A REFUSAL: re-score under one impl.
  BackendError   a scoring backend could not run (missing package, missing
                 weights, a model that answered nonsense). Fix the environment.
  DecodeError    frames could not be read out of a source. Fix the input.
  ProtocolError  the run's declared protocol is incomplete or inconsistent.
                 Fix the protocol.
  SampleSizeError
                 a population statistic was asked for below the sample size it
                 needs. Render more prompts.
  TrajectoryPerturbingError
                 reference metrics were asked for on a change that moves the
                 sampling trajectory. A REFUSAL, not a failure: the fix is a
                 different question, not a different argument.
  ContractError  the report contract was violated. Its four subclasses say at
                 which end: EncodeRefusal (this object has no canonical form),
                 SchemaRefusal (unknown schema id or non-contract struct),
                 DecodeRefusal (non-canonical bytes, or an unknown field), and
                 DigestMismatch (the bytes are not the ones promised).

Every class also subclasses the builtin a caller would reach for first, so
``except ValueError`` keeps working.
"""

from __future__ import annotations


class CozyEvalError(Exception):
    """Base class for everything this library raises."""


class ConfigError(CozyEvalError, ValueError):
    """A caller passed an invalid argument or named something unknown."""


class DataError(CozyEvalError, ValueError):
    """A checklist, prompt set, or spec is malformed or inconsistent."""


class RegistryError(CozyEvalError, ValueError):
    """A metric registration or lookup is invalid."""


class MetricIdentityError(CozyEvalError, ValueError):
    """Two numbers were compared that are not the same quantity.

    A REFUSAL, not a failure: the two rows carry one metric name but different
    implementation versions, so their difference is not a quality delta. The fix
    is to re-score under one impl, not to pass a different argument.
    """


class BackendError(CozyEvalError, RuntimeError):
    """A scoring backend was unavailable or returned something unusable."""


class DecodeError(CozyEvalError, RuntimeError):
    """A frame source could not be decoded."""


class ProtocolError(CozyEvalError, ValueError):
    """The protocol stamp is incomplete or internally inconsistent."""


class SampleSizeError(CozyEvalError, RuntimeError):
    """A population statistic was asked for below the sample size it needs."""


class TrajectoryPerturbingError(CozyEvalError, RuntimeError):
    """Reference metrics were requested for a trajectory-perturbing change."""


class ContractError(CozyEvalError, ValueError):
    """The report contract was violated. See :mod:`cozy_eval.contract`."""


class EncodeRefusal(ContractError):
    """This value has no canonical form, or the document is not fully stamped.

    A REFUSAL: writing it anyway would produce bytes whose digest identifies one
    spelling rather than one result, which is the whole property the contract
    exists to provide.
    """


class SchemaRefusal(ContractError):
    """An unknown schema id, or a struct that is not part of the contract."""


class DecodeRefusal(ContractError):
    """Bytes were not canonical, or carried a field this version does not know.

    Never a partial read. A field a decoder does not recognize is a semantic
    change whose schema id should have been bumped.
    """


class DigestMismatch(ContractError):
    """A report's bytes are not the ones the caller expected."""


__all__ = [
    "BackendError",
    "ConfigError",
    "ContractError",
    "CozyEvalError",
    "DataError",
    "DecodeError",
    "DecodeRefusal",
    "DigestMismatch",
    "EncodeRefusal",
    "MetricIdentityError",
    "ProtocolError",
    "RegistryError",
    "SampleSizeError",
    "SchemaRefusal",
    "TrajectoryPerturbingError",
]
