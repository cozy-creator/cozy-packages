"""What an evaluation is allowed to measure, and which numbers gate.

ONE table for the whole library — every metric, whatever module computes it and
whoever wrote that module.

STABILITY: locked core (v0.x). See the stability section of the README.

SIX DIMENSIONS. The design rule is that a suite needs a small number of
*mostly independent* numbers: if two metrics are almost perfectly correlated
they are one metric wearing two hats, and reporting both only adds chances to
fail a good model on the same underlying signal.

  similarity      — how far did the pixels/samples move from a reference.
  adherence       — did the render contain what the prompt specified.
  preference      — would a human prefer this render.
  quality         — does it look good on its own terms.  Reference-free.
  temporal        — did the frames stop agreeing with each other.
  distributional  — did the POPULATION of outputs shift.

AUDIO IS NOT A SEVENTH DIMENSION, deliberately. The dimensions are QUESTIONS,
not media: 'is it faithful to the reference', 'did it contain what was asked',
'would a human prefer it', 'is it well formed on its own'. Those questions are
the same for a soundtrack, so audio SNR is similarity, a sound-of-X checklist is
adherence, and clipping/silence/dual-mono are quality. The payoff is mechanical
rather than aesthetic: the tri-state parity verdict in ``cozy_eval.verdict``
reads FAITHFULNESS_DIMENSIONS and PARITY_DIMENSIONS, so a quant arm that wrecks
the audio reaches ``reject`` through the machinery that already existed, with no
audio-specific verdict path to keep in sync.

TEMPORAL and DISTRIBUTIONAL are separate questions and not media either.
'Did the frames stop agreeing' is not 'is this frame good' — a clip of
individually perfect frames that flickers fails one and passes the other, and
v1 filed those numbers under quality/similarity where a reader could not see
the difference. 'Did the population shift' is the only question that survives a
trajectory-perturbing change at all, so it cannot be a footnote on a budget
table: it is the lane the gate actually runs in.

Each dimension has exactly ONE headline number per MODALITY, plus its worst-case
tail. Everything else is report-only: computed because it is nearly free and
useful to a human reader, never able to fail a candidate on its own. The
headline is normally gated too; ``arniqa`` is the deliberate exception, held
report-only until the quality distributions that would give its budget a
provenance are banked (ev-005). A budget with no named known-good and known-bad
populations is exactly what this library refuses to ship.

NOT declared here, deliberately: the population gate's DERIVED INDICES
(``imaging_index``, ``jerk_excess``, ``flicker_ratio``). Those are declared as
data too — in :data:`cozy_eval.benchmarks.VIDEO_BUDGETS` — because they are
two-sided budgets on statistics computed ACROSS a prompt population, and
``MetricSpec`` has one direction and one row. The split is metric-vs-threshold,
not layer-vs-layer. ``significant_features`` and ``population_frechet`` ARE
declared here as of @10: they are the distributional dimension's identity, and a
dimension whose headline has no registry row cannot be looked up, stamped, or
carried in a score row.

Redundancy here was MEASURED, not assumed — see ``REDUNDANCY_EVIDENCE``.

**Every metric this package implements is declared in ``BUILTIN`` below, as
data.** A ``MetricSpec`` is pure metadata — no torch, no weights — so the table
is complete on ``import cozy_eval`` whether or not the module that computes a
given number was imported. That is deliberate: if metrics registered themselves
as an import side effect, ``REGISTRY``, ``GATED`` and ``headline()`` would
answer differently depending on what the caller happened to import, and a
report's ``metric_set`` would not identify the set that produced it.

:func:`register` is the extension point for metrics that live OUTSIDE this
package. Do not edit ``BUILTIN`` to add one, and do not call ``register()`` from
inside this package.

NAMING RULE, checked by ``scripts/fence.py``: a metric that
implements a *published, named* method keeps that name verbatim (``lpips``,
``niqe``, ``musiq``, ``arniqa``, ``clip_iqa``, ``ssim``, ``ms_ssim``, ``psnr``,
``vqascore``). Anything we derive ourselves is ``<subject>_<quantity>``
(``element_recall``, ``edit_compliance``, ``pref_delta``, ``composition_recall``,
``hpsv3_score``). Names are lowercase ``[a-z0-9_]`` and are part of the locked
API — budgets and banked reports key on them.
"""

from __future__ import annotations

import re
from typing import Any

import msgspec

from .errors import RegistryError

#: Identifies the METRIC SET a report was produced with. Same ``cozy-eval/<thing>@<n>``
#: convention as ``suite.REPORT_SCHEMA``. Bump when a metric's meaning changes.
METRIC_SET_VERSION = "cozy-eval/metrics@13"
# @5 was #9's spatial fine-detail set; @6 added the temporal-fidelity family;
# @7 adds the output-integrity floor; @8 adds track stability — the OBJECT
# axis, which the other three passed clips the owner's eye rejected on.
# @9 closes the two ways an arm could pass by doing LESS: track_stability_ratio
# is now two-sided (0.90, 1.40) so over-smoothing cannot walk through a floor,
# and element_recall is asked per temporal window and gated on the WORST, so a
# clip that drops prompt content halfway cannot mean-pool its way past. Also
# declares motion_mag_ratio (report-only, with its measured failure recorded)
# and cuts the population feature pass out of the per-clip signal path.
# @10 is the v2 metric core. TEMPORAL and DISTRIBUTIONAL become real dimensions
# (they were prose in the package docstring and budget rows in benchmarks while
# the table declared four); every row gains its cost class, its per-metric impl
# version, its modality and its lane admissibility as DATA; and the cut list
# lands — video-mode ssim/ms_ssim, the whole Δ-frame PSNR family and
# edge_overshoot leave the report surface.
# @13 adds grid_peak_ratio — the GRID/BLOCKINESS axis. It is here because the
# output-integrity screen PASSED four renders the owner rejected on sight for a
# visible lattice (adjacent_frame_corr 0.988/0.977): a periodic grid is
# perfectly self-similar frame to frame, so a correlation floor is structurally
# blind to it and the defect RAISES the number the screen reads. Every axis in
# this table catches something the others cannot; this is the first one an
# owner's eyes named before a statistic did.

# A metric name is an API key: budgets, banked reports and report rows all
# address metrics by it.
NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_]*$")

SIMILARITY = "similarity"
ADHERENCE = "adherence"
PREFERENCE = "preference"
QUALITY = "quality"
TEMPORAL = "temporal"
DISTRIBUTIONAL = "distributional"
DIMENSIONS: tuple[str, ...] = (
    SIMILARITY, ADHERENCE, PREFERENCE, QUALITY, TEMPORAL, DISTRIBUTIONAL,
)

#: What a metric COSTS to run, and therefore where it may run. Declared per
#: metric as data because it is the fact a consumer routes on: a training loop
#: takes the first two tiers in-process, an eval endpoint owns the third.
#:
#: cheap-deterministic  closed-form numpy/OpenCV, no weights, bit-identical
#:                      across thread counts. Usable anywhere, including the
#:                      serve path.
#: small-model          permissive torch/ONNX weights, CPU-capable, installed
#:                      as an extra. Usable in any job or endpoint that
#:                      installs the extra.
#: model-backed         a resident multi-GiB model per call. NEVER loaded by
#:                      this library: it is injected behind a structural
#:                      protocol named by the spec's ``seam``.
CHEAP_DETERMINISTIC = "cheap-deterministic"
SMALL_MODEL = "small-model"
MODEL_BACKED = "model-backed"
COST_CLASSES: tuple[str, ...] = (CHEAP_DETERMINISTIC, SMALL_MODEL, MODEL_BACKED)

#: The structural protocols in :mod:`cozy_eval.judge` a model-backed metric may
#: be injected through. A model-backed metric naming none of these is a
#: registration error: without an injection seam the library would have to load
#: the weights itself, which is the exact hole §2.4 of the design closes.
SEAMS: tuple[str, ...] = ("Judge", "SoftJudge", "Transcriber", "AudioJudge", "PreferenceScorer")

#: What KIND of output a metric can score. Registry data, not prose, because the
#: v1 cut list is a modality statement: SSIM/MS-SSIM over video frames rewarded
#: the wrong thing, so they are ``image`` and the video runner cannot reach them.
#: ``av`` means the metric needs picture AND sound in the same file.
MODALITIES: tuple[str, ...] = ("any", "image", "video", "audio", "av")

#: How per-unit values (frames, clips, samples) pool into the reported number.
#: Data rather than code so the streaming accumulator in
#: :mod:`cozy_eval.accumulate` and the one-shot functional path cannot disagree
#: about it — they read this field and call the same pooling function.
POOLS: tuple[str, ...] = ("mean", "median", "min", "max", "harmonic_mean")

# REDUNDANCY, MEASURED. 44 banked A/B pairs: 20 fp8-quantized renders of one
# model at 1328^2 on a hard prompt set, 8 more from a second model, 8 from a
# third, and 8 same-checkpoint/different-seed control rows. Pearson / Spearman
# WITHIN the single-model population (the cleanest read — one model, one prompt
# set, one recipe):
#
#     lpips vs ms_ssim   -0.960 / -0.961     <- the same number, inverted
#     lpips vs ssim      -0.873 / -0.829
#     lpips vs psnr      -0.826 / -0.814
#     ssim  vs psnr      +0.874 / +0.922
#     clip_delta vs ALL of the above:  |r| <= 0.14   <- genuinely orthogonal
#
# So the four pixel/perceptual metrics are ONE dimension wearing four hats.
# LPIPS keeps the gate (learned perceptual distance, best human agreement of
# the four); SSIM/MS-SSIM/PSNR are computed and REPORTED because they cost
# ~nothing beside LPIPS and a human reads 0.81 more easily than a perceptual
# distance. clip_delta survives on the evidence: uncorrelated with similarity,
# so it measures something else.
#
# The honest gaps, stated rather than hidden: DISTS (texture-oriented) is the
# one similarity metric that plausibly is NOT redundant with LPIPS and has not
# been measured here; and element_recall vs clip_delta has no measurement yet
# because the correlation study predates any judged row.
REDUNDANCY_EVIDENCE = "correlation study, 44 banked pairs, 2026-07-27"


class MetricSpec(msgspec.Struct, frozen=True, kw_only=True):
    """One metric's identity, as data.

    ``name`` alone does not identify a number — clean-fid measured same-named
    FID disagreeing by whole points across implementations on resize filter and
    quantization alone. ``(name, impl)`` identifies the math; the registry-wide
    ``METRIC_SET_VERSION`` identifies the table. Bump ``impl`` whenever the
    number this metric produces on unchanged input can change, and comparing two
    score rows that disagree on it is a refusal, not a delta (see
    :mod:`cozy_eval.identity`).
    """

    name: str
    dimension: str
    #: PER-METRIC implementation version. Part of every score row's identity.
    impl: str
    #: Where this metric may run: see :data:`COST_CLASSES`.
    cost_class: str
    model_ref: str = ""       # HF id / package of the scoring model; "" = closed form
    gated: bool = False       # False = computed and recorded, never fails a candidate
    headline: bool = False    # THE number for its dimension+modality
    higher_is_better: bool = True
    paired: bool = True       # needs a reference render; False = scores one image
    #: What this metric can score: see :data:`MODALITIES`.
    modality: str = "any"
    #: For ``model-backed`` metrics, the :mod:`cozy_eval.judge` protocol the
    #: caller injects an implementation of. Empty for every other cost class.
    seam: str = ""
    #: True when the number is a distance from the REFERENCE's own pixels or
    #: samples, so it is only admissible on the same-trajectory lane. A
    #: trajectory-perturbing change makes the reference a different take, and
    #: the distance then measures divergence rather than damage; the runner
    #: refuses these rather than printing a quotable confounded number.
    reference_only: bool = False
    #: How per-unit values pool into the reported number: see :data:`POOLS`.
    pool: str = "mean"
    note: str = ""


def validate(spec: MetricSpec) -> MetricSpec:
    """Every identity rule a metric must satisfy, in one place.

    Run over :data:`BUILTIN` at import AND by :func:`register`, so a metric this
    package ships and a metric a third party adds are held to the same bar.
    """
    if not NAME_PATTERN.match(spec.name):
        raise RegistryError(
            f"metric name {spec.name!r} is not a valid key: names are lowercase "
            f"[a-z][a-z0-9_]* because budgets and banked reports address metrics by name"
        )
    if spec.dimension not in DIMENSIONS:
        raise RegistryError(
            f"metric {spec.name!r} declares unknown dimension {spec.dimension!r}; "
            f"known: {list(DIMENSIONS)}"
        )
    if not spec.impl:
        raise RegistryError(
            f"metric {spec.name!r} must declare an impl version: a metric NAME does "
            "not identify a number, (name, impl) does"
        )
    if spec.cost_class not in COST_CLASSES:
        raise RegistryError(
            f"metric {spec.name!r} declares unknown cost class {spec.cost_class!r}; "
            f"known: {list(COST_CLASSES)}. The cost class is what a consumer routes "
            "on, so it is required, not inferred."
        )
    if spec.modality not in MODALITIES:
        raise RegistryError(
            f"metric {spec.name!r} declares unknown modality {spec.modality!r}; "
            f"known: {list(MODALITIES)}"
        )
    if spec.pool not in POOLS:
        raise RegistryError(
            f"metric {spec.name!r} declares unknown pool {spec.pool!r}; known: {list(POOLS)}"
        )
    if spec.cost_class == MODEL_BACKED and spec.seam not in SEAMS:
        raise RegistryError(
            f"model-backed metric {spec.name!r} declares no injection seam "
            f"({spec.seam!r}); it must name one of {list(SEAMS)}. A model-backed "
            "metric with no seam would make this library load multi-GiB weights "
            "itself, which is the unversioned-hidden-input hole the seam closes."
        )
    if spec.cost_class != MODEL_BACKED and spec.seam:
        raise RegistryError(
            f"metric {spec.name!r} is {spec.cost_class} but names seam {spec.seam!r}; "
            "only model-backed metrics are injected"
        )
    return spec


BUILTIN: tuple[MetricSpec, ...] = (
    # --- similarity (paired only) -----------------------------------------
    MetricSpec(
        name="lpips", dimension=SIMILARITY, impl="1.0",
        cost_class=SMALL_MODEL, reference_only=True,
        model_ref="torchmetrics:lpips-alex",
        gated=True, headline=True, higher_is_better=False,
        note="dimension headline: learned perceptual distance to the reference",
    ),
    MetricSpec(
        name="ssim", dimension=SIMILARITY, impl="2.0",
        cost_class=CHEAP_DETERMINISTIC, modality="image", note=(
            "report-only: r=-0.87 with lpips on banked pairs. Kept because a "
            "human reads 0.82 more easily than an LPIPS distance. IMAGE ONLY "
            "from @10 — pooled over video frames it rewards over-smoothing. "
            "impl 2.0: ONE numpy implementation (Wang 2004, gaussian 11x11, "
            "sigma 1.5), scale-normalized. v1 had three — skimage's when "
            "scikit-image happened to be installed (0.9207 on a measured pair), "
            "an 8x8 block fallback when it did not (0.8993), and torchmetrics' "
            "from another module. Which number you got was decided by your "
            "environment; that is the clean-fid defect at home."
        ),
    ),
    MetricSpec(
        name="ms_ssim", dimension=SIMILARITY, impl="2.0",
        cost_class=CHEAP_DETERMINISTIC, modality="image", note=(
            "report-only: r=-0.96 with lpips — effectively the same number. "
            "IMAGE ONLY from @10, and impl 2.0 for the same reason ssim is: one "
            "numpy implementation (Wang 2003 weights), no optional dependency "
            "able to change the math."
        ),
    ),
    MetricSpec(
        name="psnr", dimension=SIMILARITY, impl="2.0",
        cost_class=CHEAP_DETERMINISTIC, reference_only=True, higher_is_better=True,
        note=(
            "report-only. Pixel identity punishes same-seed trajectory "
            "divergence identically whether the candidate got worse or merely "
            "different. Kept so historical rows stay comparable. impl 2.0: ONE "
            "numpy implementation, scale-normalized on entry. v1 had two — a "
            "numpy one at data_range 1.0 and a torchmetrics one at 255.0 — and "
            "the numpy one on uint8 input read -17.88 dB where the correct "
            "answer was 28.02 dB, because the uint8 difference WRAPPED. A "
            "confidently wrong number under a locked API name."
        ),
    ),
    MetricSpec(
        name="vmaf", dimension=SIMILARITY, impl="1.0",
        cost_class=SMALL_MODEL, modality="video", reference_only=True,
        model_ref="libvmaf:vmaf_v0.6.1", note=(
            "reference lane only, whole video FILES through ffmpeg's libvmaf, "
            "candidate scaled+fps-matched to the reference first. THE single "
            "best perceptual video-fidelity score (fuses spatial + motion). "
            "HARMONIC-mean pooled so a clip that falls apart for 10% of frames "
            "does not read ~90. Report-only here because its budgets are "
            "per-content: a VMAF excellent for animation is mediocre for film grain."
        ),
    ),
    MetricSpec(
        name="vmaf_min", dimension=SIMILARITY, impl="1.0",
        cost_class=SMALL_MODEL, modality="video", reference_only=True,
        model_ref="libvmaf:vmaf_v0.6.1", note=(
            "the worst single-frame VMAF — the tail of vmaf, where one ruined "
            "transition hides under a healthy harmonic mean"
        ),
    ),
    # --- temporal fidelity: the motion axis screenshots miss (optical flow) ----
    MetricSpec(
        name="flow_divergence", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", reference_only=True,
        model_ref="cozy-eval:flow", higher_is_better=False, note=(
            "video: mean end-point error between the candidate's and reference's "
            "Farneback optical-flow fields, normalized by the reference's motion "
            "magnitude. 'Do the movements match' — catches trajectory damage a "
            "per-frame metric cannot, valid for same-seed pairs (fp8-vs-bf16, "
            "quant-vs-dense). 0 = identical motion; 1 = divergence the size of "
            "the reference's own motion. Paired to a same-seed control."
        ),
    ),
    MetricSpec(
        name="warp_error_delta", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", reference_only=True,
        model_ref="cozy-eval:flow", higher_is_better=False, note=(
            "video: candidate warp-error MINUS the reference's, at matched "
            "content — the temporal instability the candidate ADDED (shimmer / "
            "boiling / flicker). Subtracting the same-seed control cancels the "
            "shared scene, exactly as #9's ringing_excess does for spatial halos. "
            "Positive = the candidate boils where the reference was stable."
        ),
    ),
    MetricSpec(
        name="motion_mag_ratio", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", reference_only=True,
        model_ref="cozy-eval:flow", note=(
            "video: the candidate's mean optical-flow magnitude over the "
            "reference's. Computed free beside flow_divergence (the flow fields "
            "already exist) and declared @9 because it was landing in report rows "
            "undeclared. REPORT-ONLY, and the note is the point: this is the "
            "obvious over-smoothing companion and it was MEASURED NOT TO WORK. On "
            "the labeled 15 s over-smoothed rung it reads 0.920 whole-frame and "
            "1.006 with VBench-style top-5% pooling, while the owner-IDENTICAL fp8 "
            "band is 0.80-1.05 and the pure re-render floor is 0.91-1.09 — the "
            "arm it must catch sits INSIDE the band it must not fire on, at every "
            "pooling and every temporal window tried. Motion magnitude is set by "
            "the take, not by the damage. The instruments that DO separate that "
            "class are the two-sided track_stability_ratio and the windowed "
            "element_recall. See calibration/motion-magnitude.json."
        ),
    ),
    MetricSpec(
        name="warp_error", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video",
        model_ref="cozy-eval:flow", paired=False, higher_is_better=False, note=(
            "video, reference-free: warp frame t->t+1 by its optical flow, mean "
            "absolute residual vs the actual t+1 / frame contrast. Coherent "
            "motion warps cleanly; shimmer, boiling and per-frame noise cannot be "
            "flow-predicted and leave a large residual. The reference-free half "
            "of the temporal-fidelity family — the ONE temporal number valid with "
            "no control, and the sharpest separator of the production-noise class."
        ),
    ),
    # --- track stability: do OBJECTS hold together in 3D under motion? -------
    # The axis the owner's eye found and three metric families missed (@8). The
    # gate is the PAIRED RATIO; the reference-free numbers beside it are
    # content-set diagnostics. See cozy_eval.tracks for the scope statement.
    MetricSpec(
        name="track_stability_ratio", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", headline=True,
        model_ref="cozy-eval:tracks", gated=True, note=(
            "OBJECT-COHERENCE GATE, paired to a same-seed control: the fraction "
            "of the control's coherent feature tracks the candidate retains. "
            "Catches objects that WARBLE — a point on an object whose image-plane "
            "trajectory jitters, whose neighbours stop agreeing, or that stops "
            "being itself as the camera moves, while every single frame still "
            "looks right. VALID ACROSS A RE-ROLLED TAKE: both arms are scored on "
            "their OWN trajectories and never compared pixel to pixel, so a "
            "trajectory-perturbing lane (quant, sparse attention, distill) is "
            "measured on whether its objects hold, not on how far its take drifted. "
            "MEASURED separation, not a guess: 36 owner-rejected sparse-attention "
            "k16 pairs score 0.000-0.850 (median 0.319), 10 pairs the owner judged "
            "IDENTICAL score 0.931-1.247 (median 0.996), floor 0.90 in the empty "
            "middle. UNMEASURED when the control itself is untrackable. "
            "TWO-SIDED from @9: the band is (0.90, 1.40). Scoring far ABOVE the "
            "control is the OVER-SMOOTHING signature — a simpler, slower take is "
            "easier to track, not more coherent — and the floor-only gate PASSED "
            "the 15 s courier rung at 2.169 while it dropped the cargo bike. The "
            "ceiling sits in the second empty middle, taken across all three "
            "window budgets: identical pairs top out at 1.2514, bit-exact is "
            "exactly 1.0, the labeled over-smoothed arm reads 2.169 (1.512 at "
            "the undecimated budget). The ceiling is UNMEASURED when the control holds "
            "under 40% of its tracks — the upward tail is denominator-driven, and "
            "an owner-IDENTICAL dense-weave pair reads 2.766 there."
        ),
    ),
    MetricSpec(
        name="track_stability", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video",
        model_ref="cozy-eval:tracks", paired=False, note=(
            "video, reference-free: the fraction of seeded corner features that "
            "both survive a one-second window and move like a point on a real "
            "3D object while they do (smooth image-plane trajectory, neighbours "
            "keeping their relative geometry). REPORT-ONLY reference-free and "
            "deliberately so — the absolute level is set by CONTENT (steam and "
            "dense weave hold almost no tracks on a perfect render), so only "
            "track_stability_ratio gates."
        ),
    ),
    MetricSpec(
        name="track_survival", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video",
        model_ref="cozy-eval:tracks", paired=False, note=(
            "video, reference-free: fraction of seeded features still tracked, "
            "forward-backward validated, at the end of their window. The "
            "'objects stop being themselves' half of track_stability, and the "
            "number that decides whether the clip is TRACKABLE at all "
            "(below ~0.25 the family reports UNMEASURED rather than a verdict)."
        ),
    ),
    MetricSpec(
        name="track_jitter", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", pool="median",
        model_ref="cozy-eval:tracks", paired=False, higher_is_better=False, note=(
            "video, reference-free: median per-track image-plane ACCELERATION "
            "energy after the global camera motion is removed, normalized by the "
            "track's own speed so a fast pan is not penalized. Genuine 3D motion "
            "is smooth; warble is high-frequency. The smoothness half of "
            "track_stability, reported so a reader sees WHICH half moved."
        ),
    ),
    MetricSpec(
        name="track_rigidity_error", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", pool="median",
        model_ref="cozy-eval:tracks", paired=False, higher_is_better=False, note=(
            "video, reference-free: median second-difference energy of the "
            "distance between neighbouring tracks, scale-normalized (x100). "
            "Neighbours on one surface keep their geometry through parallax and "
            "perspective, which are SMOOTH; a surface that reshapes frame to "
            "frame does not. The 'objects reshape themselves' half."
        ),
    ),
    MetricSpec(
        name="cvvdp", dimension=SIMILARITY, impl="1.0",
        cost_class=SMALL_MODEL, modality="video", reference_only=True,
        model_ref="cvvdp:standard_4k", note=(
            "reference lane only. ColorVideoVDP JOD units — a perceptual "
            "difference predictor that models colour and motion, unlike the "
            "luma-only classics beside it. Report-only for the same reason."
        ),
    ),
    # --- adherence --------------------------------------------------------
    MetricSpec(
        name="element_recall", dimension=ADHERENCE, impl="1.2",
        cost_class=MODEL_BACKED, seam="Judge", gated=True,
        headline=True, paired=False, note=(
            "dimension headline: fraction of the prompt's authored checklist "
            "items verified present. Reference-free — scores any render. In a "
            "PAIRED comparison the candidate-minus-reference delta is what gates. "
            "VIDEO, @9: the checklist is asked once per TEMPORAL WINDOW (three by "
            "default) and this number is the WORST window, not the whole-strip "
            "mean. A clip that holds its content for 10 s and drops it for the "
            "last 5 is not 2/3 compliant, it is broken, and the mean-pooled "
            "version passed exactly that arm (15 s courier cell: cargo bike and "
            "parcel present at t=7.5 s, gone by t=14.5 s, DISTS 0.140). Image "
            "mode is one window and unchanged. @12 (ev-003): an item the judge "
            "did not ANSWER is UNMEASURED and leaves the weighted denominator "
            "entirely — it used to score as a verified-false element, so a judge "
            "that timed out or replied unparseably read as a render that was "
            "missing everything. The count and the reason ride the score's note."
        ),
    ),
    MetricSpec(
        name="element_recall_mean", dimension=ADHERENCE, impl="1.1",
        cost_class=MODEL_BACKED, seam="Judge", modality="video", paired=False,
        note=(
            "video: the checklist recall averaged over the temporal windows — the "
            "pre-@9 whole-strip number's closest equivalent, kept report-only so "
            "a reader can see how much the gated worst-window value diverges from "
            "the average. Reported only when more than one window was scored."
        ),
    ),
    MetricSpec(
        name="element_recall_drop", dimension=ADHERENCE, impl="1.1",
        cost_class=MODEL_BACKED, seam="Judge", modality="video", paired=False,
        higher_is_better=False, note=(
            "video: FIRST window's recall minus the LAST window's. Positive = the "
            "clip lost prompt content as it ran, the mid-clip drift signature that "
            "no per-frame or whole-strip number sees. Report-only: the gate is the "
            "worst window (element_recall), because content can also be missing "
            "from the start."
        ),
    ),
    MetricSpec(
        name="text_exact", dimension=ADHERENCE, impl="1.0",
        cost_class=SMALL_MODEL, paired=False,
        model_ref="rapidocr", note="OCR exact-match rate over the prompt's quoted strings",
    ),
    MetricSpec(
        name="text_fuzzy", dimension=ADHERENCE, impl="1.0",
        cost_class=SMALL_MODEL, paired=False,
        model_ref="rapidocr", note="OCR normalized-similarity mean over the same strings",
    ),
    MetricSpec(
        name="edit_compliance", dimension=ADHERENCE, impl="1.1",
        cost_class=MODEL_BACKED, seam="Judge", modality="image", paired=False,
        note="EDIT mode: did the instructed change happen (judged on before+after)",
    ),
    MetricSpec(
        name="edit_preservation", dimension=ADHERENCE, impl="1.1",
        cost_class=MODEL_BACKED, seam="Judge", modality="image", paired=False,
        note="EDIT mode: did everything the instruction did not mention stay put",
    ),
    MetricSpec(
        name="clip_delta", dimension=ADHERENCE, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="openai/clip-vit-base-patch32", gated=True, note=(
            "FALLBACK GATE: gates only when element_recall is UNMEASURED (no "
            "judge/OCR on this image), so an adherence-blind run is never an "
            "ungated run. Orthogonal to similarity (|r|<=0.14) so it is not "
            "redundant with that dimension, but it is a bag-of-concepts proxy "
            "for the question element_recall answers directly."
        ),
    ),
    # --- preference -------------------------------------------------------
    MetricSpec(
        name="pref_delta", dimension=PREFERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="PreferenceScorer",
        model_ref="yuvalkirstain/PickScore_v1", gated=True,
        headline=True, note=(
            "dimension headline: candidate-minus-reference human-preference "
            "score. The absolute scale is arbitrary and NOT comparable across "
            "prompts — only same-prompt deltas are meaningful. A continuous "
            "CLIP-H scalar resolves the small same-prompt deltas a generative "
            "1-10 judge would round to zero. NOTE: these weights carry no "
            "declared licence; see PROVENANCE.md before relying on them."
        ),
    ),
    MetricSpec(
        name="pref_score", dimension=PREFERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="PreferenceScorer",
        model_ref="yuvalkirstain/PickScore_v1", paired=False,
        note="the raw per-image preference score; what an absolute leaderboard reads",
    ),
    MetricSpec(
        name="hpsv3_score", dimension=PREFERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="PreferenceScorer",
        model_ref="MizzenAI/HPSv3", paired=False, note=(
            "HPSv3 mu (uncertainty-aware preference reward, Qwen2-VL-7B "
            "backbone); the HPDv3 accuracy leader, so it is the recommended "
            "reference-free/leaderboard scorer. Report-only in the paired "
            "gate: measured on 52 banked pairs, it buys no same-prompt delta "
            "resolution over PickScore at ~80x the load cost."
        ),
    ),
    # --- adherence, compositional (detector-scored) ------------------------
    MetricSpec(
        name="composition_correct", dimension=ADHERENCE, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="IDEA-Research/grounding-dino-tiny", paired=False, note=(
            "GenEval-style boolean per image (ALL include clauses AND no exclude); "
            "the mean over a prompt set is the published-GenEval-comparable number"
        ),
    ),
    MetricSpec(
        name="composition_recall", dimension=ADHERENCE, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="IDEA-Research/grounding-dino-tiny", paired=False, note=(
            "graded fraction of compositional terms satisfied; detector-scored "
            "sibling of element_recall for specs with structured object clauses"
        ),
    ),
    # --- adherence, soft (VLM p(yes) rather than a parsed yes/no) ----------
    MetricSpec(
        name="vqascore", dimension=ADHERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="SoftJudge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", paired=False, note=(
            "soft single-number alignment, p(yes) for 'does this figure show "
            "{prompt}'; no decomposition, so it survives prompts with no checklist"
        ),
    ),
    MetricSpec(
        name="atom_score", dimension=ADHERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="SoftJudge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", paired=False, note=(
            "Soft-TIFA arithmetic mean of per-atom p(yes) over the versioned "
            "template decomposition; soft sibling of element_recall with delta "
            "resolution a hard parse rounds away"
        ),
    ),
    # --- quality (reference-free, no prompt) -------------------------------
    MetricSpec(
        name="arniqa", dimension=QUALITY, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="torchmetrics:arniqa-koniq10k", paired=False, headline=True,
        note=(
            "dimension headline: learned no-reference quality, 0..1. Report-only "
            "for now — quality gating is a policy decision that waits for banked "
            "distributions."
        ),
    ),
    MetricSpec(
        name="clip_iqa", dimension=QUALITY, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="torchmetrics:clip-iqa", paired=False, note=(
            "CLIP prompt-pair quality probe, 0..1; OpenAI CLIP backbone (licence "
            "caveat in PROVENANCE.md)"
        ),
    ),
    MetricSpec(
        name="niqe", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC,
        paired=False, higher_is_better=False, note=(
            "closed-form natural-scene statistics distance, no weights; the only "
            "quality number that runs without torch"
        ),
    ),
    MetricSpec(
        name="musiq", dimension=QUALITY, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="google-research/musiq:koniq (Apache-2.0)", paired=False, note=(
            "multi-scale quality transformer at native resolution; our PyTorch "
            "port of the Apache reference + checkpoints (no permissive PyTorch "
            "path existed). koniq MOS scale, ~0-100"
        ),
    ),
    # --- video (report-only until video distributions are banked; a threshold
    # --- is only set where measured values exist to calibrate it) ------------
    MetricSpec(
        name="lpips_frame_worst", dimension=SIMILARITY, impl="1.0",
        cost_class=SMALL_MODEL, modality="video", reference_only=True, pool="max",
        model_ref="torchmetrics:lpips-alex", higher_is_better=False, note=(
            "video: the worst single-frame LPIPS within one clip pair. The "
            "per-frame MEAN travels under lpips itself; this is its tail — a "
            "clip that is faithful on average can still hold one ruined frame"
        ),
    ),
    MetricSpec(
        name="motion_compliance", dimension=ADHERENCE, impl="1.1",
        cost_class=MODEL_BACKED, seam="Judge", modality="video", paired=False,
        note=(
            "video checklists: did the asked-for dynamics HAPPEN (a static clip "
            "fails here). The motion half of the motion/hold duality; "
            "element_recall stays the weighted union"
        ),
    ),
    MetricSpec(
        name="static_preservation", dimension=ADHERENCE, impl="1.1",
        cost_class=MODEL_BACKED, seam="Judge", modality="video", paired=False,
        note=(
            "video checklists: did everything meant to stay constant STAY "
            "(identity drift and background reshuffling fail here). The hold "
            "half of the motion/hold duality"
        ),
    ),
    MetricSpec(
        name="luma_flicker", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video",
        model_ref="cozy-eval:signal", paired=False,
        higher_is_better=False, note=(
            "video, composed from cozy_eval's signal backend (its `flicker`): "
            "frame-mean luma wobble in percent, reference-free"
        ),
    ),
    MetricSpec(
        name="jerk_ratio", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video",
        model_ref="cozy-eval:signal", paired=False,
        higher_is_better=False, note=(
            "video, composed from cozy-eval's signal backend: second/first temporal "
            "difference of frame-mean luma; smooth motion sits low, flicker "
            "and judder push it up"
        ),
    ),
    # --- output integrity: is this a render at all, or noise? ----------------
    # The one gated floor here whose limit is BANKED against real arms, and the
    # cheapest number in the library. See cozy_eval.integrity for its scope.
    MetricSpec(
        name="adjacent_frame_corr", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", headline=True, pool="median",
        model_ref="cozy-eval:integrity", paired=False, gated=True, note=(
            "OUTPUT-INTEGRITY GATE, reference-free: MEDIAN Pearson correlation of "
            "adjacent grey frame pairs sampled across the clip. Real video is "
            "self-similar frame to frame; VAE-decoded noise is correlated with "
            "nothing. MEASURED separation, not a guess: production noise 0.29, "
            "real renders 0.92-0.99, floor 0.6 in the empty middle. The median "
            "is what makes a hard CUT safe. SCOPE: catches NOISE/BLANK only — a "
            "melted/over-smoothed render scores HIGHER than a clean one, so this "
            "is never a quality gate; that is what the detail detectors (@5) and "
            "the temporal-fidelity family (@6) are for."
        ),
    ),
    MetricSpec(
        name="frame_std_min", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", pool="min",
        model_ref="cozy-eval:integrity", paired=False, note=(
            "smallest per-frame grey standard deviation over the sampled frames; "
            "zero is BLANK output (constant fill), which correlates with nothing "
            "and so cannot be caught by adjacent_frame_corr alone. Report-only: "
            "the blank verdict is raised by cozy_eval.integrity, not a budget."
        ),
    ),
    MetricSpec(
        name="grid_peak_ratio", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="video", pool="max",
        model_ref="cozy-eval:integrity", paired=False, gated=True,
        higher_is_better=False, note=(
            "OUTPUT-INTEGRITY GATE, reference-free: the GRID/BLOCKINESS axis. "
            "Magnitude of the strongest periodic line in the pooled x/y gradient "
            "spectra of five sampled frames, over the MEDIAN of its local "
            "spectral neighbourhood; candidate periods 8-128 px; the worse axis "
            "reported. Content is broadband and moves, so it divides out of a "
            "local ratio and cancels under cross-frame pooling; a VAE tile seam "
            "or a DiT patch lattice is one bin at a fixed phase on every frame. "
            "MEASURED separation over one corpus in both directions: owner-"
            "accepted bank renders 1.975-3.804, the clean-picture RED arms up to "
            "3.896, the four owner-REJECTED oracle renders 7.320-14.179, "
            "RED-blocky 15.972, the reversed-sampler daf50552 arm 62.842. Limit "
            "6.0 sits in the empty 3.896-7.320 band. WHY IT IS A SEPARATE AXIS: "
            "adjacent_frame_corr read 0.963-0.988 on the four renders the owner "
            "rejected — a lattice is perfectly self-similar frame to frame, so "
            "the noise floor is not insensitive to this class, it is blind to "
            "it. SCOPE: sensitivity scales with how many repeats fit in the "
            "frame — the measured floor is a 4/255 luma ridge at 8-16 px, 8/255 "
            "at 32-64 px and 16/255 at 128 px; and the ratio only transfers to "
            "frames with an axis of 512 px or more, below which it is UNMEASURED."
        ),
    ),
    # --- audio, paired fidelity (SIMILARITY: the faithfulness question) ------
    MetricSpec(
        name="audio_si_sdr", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio", headline=True,
        model_ref="cozy-eval:audio", gated=True, note=(
            "AUDIO GATE. Scale-invariant signal-to-distortion ratio in dB "
            "against the reference arm (Le Roux et al., ICASSP 2019). Closed "
            "form, no weights. Scale-invariant deliberately: a lane that only "
            "changed output GAIN did not damage the audio, and plain SNR would "
            "punish it as if it had. This is the number a quant/cache/distill "
            "arm has to hold — a cache sweep once drove audio SNR 20.67 -> "
            "13.72 dB while the same arm's video SSIM still read 0.85."
        ),
    ),
    MetricSpec(
        name="audio_snr_db", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", note=(
            "report-only: plain SNR against the reference arm, no scale freedom. "
            "Kept beside audio_si_sdr because it is the number the H3/LTX lanes "
            "already quote, so historical rows stay comparable."
        ),
    ),
    MetricSpec(
        name="audio_lsd_db", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", higher_is_better=False, note=(
            "report-only: RMS log-spectral distance in dB (Gray & Markel, IEEE "
            "TASSP 1976). Survives a phase difference, so it separates 'the "
            "spectrum changed' from 'the waveform moved' — the audio analogue of "
            "the take-divergence problem protocol.py exists for."
        ),
    ),
    MetricSpec(
        name="audio_mel_l1", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", higher_is_better=False, note=(
            "report-only: mean absolute log-mel spectrogram difference. The "
            "perceptually-weighted sibling of audio_lsd_db, on the scale every "
            "neural vocoder is trained under."
        ),
    ),
    MetricSpec(
        name="audio_lufs_delta", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", higher_is_better=False, note=(
            "report-only, SIGNED: candidate-minus-reference integrated loudness in "
            "LU. SIMILARITY rather than QUALITY because it is a comparison to the "
            "reference arm, and QUALITY means reference-free here. It exists "
            "because audio_si_sdr is blind to gain BY CONSTRUCTION, so a pure "
            "level shift would otherwise leave no trace anywhere in the report. "
            "Signed, so its tail reads as the loudest drift, not the largest."
        ),
    ),
    MetricSpec(
        name="audio_align_lag_ms", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", higher_is_better=False, note=(
            "report-only DIAGNOSTIC, signed: the bounded encoder-delay lag "
            "compensated before the paired numbers were taken. A non-zero value "
            "means the two arms were not sample-aligned as delivered; a value at "
            "the search bound means the alignment did not converge and the "
            "paired numbers should be distrusted."
        ),
    ),
    MetricSpec(
        name="av_sync_drift_ms", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="av", headline=True,
        model_ref="cozy-eval:onset-correlation", gated=True,
        higher_is_better=False, note=(
            "AUDIO GATE. |candidate AV-sync offset - reference AV-sync offset|, "
            "in ms. THE paired sync number: absolute offset is confounded by "
            "content, drift is not, and any constant instrument bias cancels. "
            "Measured only where BOTH arms had alignable onsets; UNMEASURED "
            "otherwise, never 0."
        ),
    ),
    # --- audio, reference-free signal statistics (QUALITY) ------------------
    MetricSpec(
        name="audio_rms_dbfs", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, note=(
            "programme level in dBFS, matching ffmpeg volumedetect's "
            "mean_volume. TWO-SIDED (too quiet and too hot are both faults), so "
            "the direction flag is nominal and the real bounds live in "
            "cozy_eval.audio.AUDIO_DEFECTS as data — same metric-vs-threshold "
            "split the video population budgets use."
        ),
    ),
    MetricSpec(
        name="audio_peak_dbfs", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "sample peak in dBFS (volumedetect's max_volume). Report-only from "
            "@11: on 41 known-good clips the peak ceiling that fit the ambience "
            "half failed the transient half, because a loudness-normalized "
            "transient lands at full scale by construction (measured: a "
            "known-good domino chain peaks at +0.18 dBFS). audio_true_peak_dbtp "
            "paired with audio_clip_fraction is the gated form."
        ),
    ),
    MetricSpec(
        name="audio_lufs", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, note=(
            "integrated loudness, ITU-R BS.1770-4 with EBU R128 gating. A "
            "published standard with no trained weights, so it is implemented "
            "here rather than depended on; parity banked against pyloudnorm "
            "(MIT). Two-sided like audio_rms_dbfs."
        ),
    ),
    MetricSpec(
        name="audio_true_peak_dbtp", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "inter-sample peak, ITU-R BS.1770-4 Annex 2, 4x oversampled. @11: "
            "this is the GATED peak statistic and audio_peak_dbfs is not, "
            "because a sample peak cannot see the two faults that matter — a "
            "master clipped upstream of a lossy codec decodes UNDER full scale, "
            "and a loudness-normalized transient sits AT full scale while being "
            "perfectly clean. Budget in cozy_eval.audio.AUDIO_DEFECTS, paired "
            "with audio_clip_fraction, calibrated on n=41 known-good clips."
        ),
    ),
    MetricSpec(
        name="audio_clip_fraction", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "fraction of samples at or above 0.999 full scale"
        ),
    ),
    MetricSpec(
        name="audio_silence_fraction", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "fraction of 50 ms blocks below -60 dBFS. Report-only from @11: "
            "MEASURED on 41 known-good clips, this is a CONTENT statistic — a "
            "sparse blacksmith clip is 61% silent because it is three hammer "
            "strikes with gaps, and no limit that passes it can also catch a "
            "generator that stopped. audio_max_silence_run is the gated form."
        ),
    ),
    MetricSpec(
        name="audio_max_silence_run", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "the LONGEST CONSECUTIVE run of silent 50 ms blocks, as a fraction "
            "of the clip. The event-aware 'the generator stopped' detector: "
            "sparse transient content is many short gaps, a dead render is one "
            "long stretch, and only the run length tells them apart. Budget in "
            "cozy_eval.audio.AUDIO_DEFECTS."
        ),
    ),
    MetricSpec(
        name="audio_dc_offset", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "largest per-channel mean sample value; a broken decode or vocoder, "
            "never a creative choice"
        ),
    ),
    MetricSpec(
        name="audio_spectral_flatness", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "Wiener entropy of the power spectrum, ~0 for a tone and ~1 for "
            "white noise. TWO-SIDED — a soundtrack collapsing into hiss climbs "
            "and one collapsing into a drone falls — so the direction flag is "
            "nominal and this is report-only."
        ),
    ),
    MetricSpec(
        name="audio_side_dbfs", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, note=(
            "level of the side signal (L-R)/2 in dBFS. ABSENT for mono input "
            "rather than zero: a mono source has no stereo image to be wrong "
            "about, and that is a different fact from a stereo source that "
            "collapsed."
        ),
    ),
    MetricSpec(
        name="audio_stereo_separation_db", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "DUAL-MONO GUARD: programme RMS minus side RMS. A model that claims "
            "stereo and emits identical channels is a real regression and a "
            "trivial one to catch — the side signal falls to the level floor and "
            "this climbs to ~99 dB. fal's MiniMax-H3 output sits at 2.5-20 dB "
            "over 18 clips; the anchor clip reads 8.4 dB."
        ),
    ),
    MetricSpec(
        name="audio_channel_correlation", dimension=QUALITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="audio",
        model_ref="cozy-eval:audio", paired=False, higher_is_better=False, note=(
            "Pearson r between L and R. Two-sided (r=1 is dual mono, r=-1 is "
            "polarity-inverted); report-only beside audio_stereo_separation_db, "
            "which is the gated form of the same fault."
        ),
    ),
    # --- audio, AV-sync single-arm (QUALITY) --------------------------------
    MetricSpec(
        name="av_sync_offset_ms", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="av",
        model_ref="cozy-eval:onset-correlation", paired=False,
        higher_is_better=False, note=(
            "SIGNED audio-visual offset in ms by onset cross-correlation "
            "(Bello et al. 2005 for the audio envelope; Hershey & Movellan, "
            "NIPS 1999 for the audio-against-visual-change correlation). "
            "Positive = audio late. Closed form, NO trained weights. Report-only: "
            "the absolute offset is content-confounded, av_sync_drift_ms is the "
            "gated paired read. Does NOT score lip-sync — see PROVENANCE.md."
        ),
    ),
    MetricSpec(
        name="av_sync_confidence", dimension=TEMPORAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, modality="av",
        model_ref="cozy-eval:onset-correlation", paired=False, note=(
            "Pearson r at the winning lag. Reported so an offset always travels "
            "with the strength of the evidence for it; below the peak/prominence "
            "floor the offset is not reported at all."
        ),
    ),
    # --- audio, semantic adherence -----------------------------------------
    MetricSpec(
        name="audio_event_recall", dimension=ADHERENCE, impl="1.1",
        cost_class=MODEL_BACKED, seam="AudioJudge", modality="audio",
        paired=False, gated=True, note=(
            "AUDIO GATE, capability side: fraction of the prompt's authored "
            "SOUND-EVENT checklist items an audio-capable judge verified "
            "('is there a sound of rain'). Transcription cannot answer these, so "
            "it is deliberately a separate instrument from audio_speech_*."
        ),
    ),
    MetricSpec(
        name="audio_speech_exact", dimension=ADHERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="Transcriber", modality="audio",
        paired=False, model_ref="openai/whisper (MIT code AND weights)", note=(
            "transcribe-then-judge: exact-match rate over the prompt's required "
            "spoken strings. Reuses the OCR lane's fuzzy matcher, because "
            "reading a required string out of recognised text is the same "
            "operation whether it came from pixels or from samples."
        ),
    ),
    MetricSpec(
        name="audio_speech_fuzzy", dimension=ADHERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="Transcriber", modality="audio",
        paired=False, model_ref="openai/whisper (MIT code AND weights)", note=(
            "normalized-similarity mean over the same spoken strings"
        ),
    ),
    # --- fine-detail fidelity: the class flat-region/coherence/adjacent-frame
    # --- screens MISS (melted faces, pseudo-glyphs, edge halos, texture mush).
    # --- Folded into the standing dimensions, NOT a new one — same reason audio isn't:
    # --- texture distance is SIMILARITY, 'is this well formed' is QUALITY, and
    # --- 'which clip has better detail' is PREFERENCE. See cozy_eval.detail. ---
    MetricSpec(
        name="dists", dimension=SIMILARITY, impl="1.0",
        cost_class=SMALL_MODEL, reference_only=True,
        model_ref="torchmetrics:dists", higher_is_better=False, note=(
            "video/image FINE-DETAIL: DISTS texture-and-structure perceptual "
            "distance to a same-seed control. The registry's own noted "
            "non-redundant similarity gap — it reads 'real texture vs mush' where "
            "LPIPS reads global divergence. Report-only until budgets are banked, "
            "but VALIDATED to track step-reduction damage monotonically (busker "
            "s20->s50 0.146 vs s30->s50 0.118 against the s50 control, 2026-08-09)."
        ),
    ),
    MetricSpec(
        name="ringing_excess", dimension=SIMILARITY, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, reference_only=True,
        model_ref="cozy-eval:detail", higher_is_better=False, note=(
            "video/image FINE-DETAIL, PAIRED: candidate edge-overshoot minus the "
            "reference's, at matched content. The validated form of the ringing/"
            "halo read — subtracting a same-seed control cancels the scene the "
            "bare number confounds. Catches the fp8 SHARPENING halo (ie#634 crops "
            "+0.045 busker, +0.072 signage) that DISTS/LPIPS-mush does not; on "
            "step-reduction it goes the OTHER way (mush overshoots less), so the "
            "two are complementary. Report-only until budgets are banked."
        ),
    ),
    MetricSpec(
        name="text_legibility", dimension=QUALITY, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="rapidocr", paired=False, note=(
            "video/image FINE-DETAIL, reference-free PRE-SCREEN: mean OCR "
            "recognition confidence over detected text regions. A text detector "
            "that fires but a recognizer that cannot read it is the numeric "
            "signature of a pseudo-glyph. BLIND SPOT, stated: PP-OCR does not "
            "detect heavily stylized / non-Latin signage (the ie#634 neon-Japanese "
            "case), so the hardest pseudo-glyphs come back UNMEASURED here, never "
            "a pass — the VLM rubric is the only instrument that catches those."
        ),
    ),
    MetricSpec(
        name="text_legible_fraction", dimension=QUALITY, impl="1.0",
        cost_class=SMALL_MODEL,
        model_ref="rapidocr", paired=False, note=(
            "fraction of detected text regions at/above the legibility confidence "
            "floor; report-only sibling of text_legibility"
        ),
    ),
    MetricSpec(
        name="detail_score", dimension=QUALITY, impl="1.0",
        cost_class=MODEL_BACKED, seam="Judge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", paired=False, note=(
            "video/image FINE-DETAIL, the PRIMARY catch: mean of the four VLM "
            "rubric axes (text legible, face/hand coherent, edges clean, texture "
            "real), each a yes/no over the sampled frame strip. A VLM sees "
            "'melted face' and 'fake letters' the way a person does; the numeric "
            "detectors above are the cheap pre-screen. UNMEASURED without a Judge, "
            "like the audio semantic tier. Report-only (arniqa holds the QUALITY "
            "headline); recommended as the QUALITY HALF of the serve gate."
        ),
    ),
    MetricSpec(
        name="detail_text_legible", dimension=QUALITY, impl="1.0",
        cost_class=MODEL_BACKED, seam="Judge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", paired=False, note=(
            "VLM rubric axis: 1.0 if text/signage is real readable glyphs, 0.0 if "
            "pseudo-glyph scribble. The instrument for the non-Latin/stylized "
            "signage text_legibility is blind to."
        ),
    ),
    MetricSpec(
        name="detail_face_coherent", dimension=QUALITY, impl="1.0",
        cost_class=MODEL_BACKED, seam="Judge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", paired=False, note=(
            "VLM rubric axis: 1.0 if faces and hands are coherent, 0.0 if melted/"
            "smeared or malformed"
        ),
    ),
    MetricSpec(
        name="detail_edge_clean", dimension=QUALITY, impl="1.0",
        cost_class=MODEL_BACKED, seam="Judge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", paired=False, note=(
            "VLM rubric axis: 1.0 if high-contrast edges are free of halos/"
            "ringing, 0.0 otherwise. The perceptual sibling of ringing_excess."
        ),
    ),
    MetricSpec(
        name="detail_texture_real", dimension=QUALITY, impl="1.0",
        cost_class=MODEL_BACKED, seam="Judge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", paired=False, note=(
            "VLM rubric axis: 1.0 if fine texture reads as real material, 0.0 if "
            "mushy/wobbly/hand-drawn degradation. The perceptual sibling of dists."
        ),
    ),
    MetricSpec(
        name="detail_pref_delta", dimension=PREFERENCE, impl="1.0",
        cost_class=MODEL_BACKED, seam="Judge",
        model_ref="Qwen/Qwen3-VL-8B-Instruct", note=(
            "video/image FINE-DETAIL, PAIRWISE: +1 candidate wins, -1 reference "
            "wins, 0 tie — the VLM shown both strips and asked which has better "
            "fine detail. The capability-side read for the parity verdict when "
            "seeds can't match and pixel distance is meaningless (the fal-parity "
            "protocol). Report-only; UNMEASURED without a Judge."
        ),
    ),
    # --- distributional: did the POPULATION shift? ---------------------------
    # The valid lane when the trajectory moved. These two are the dimension's
    # metric identity; their two-sided budgets stay calibration data in
    # cozy_eval.benchmarks.VIDEO_BUDGETS, because a budget is a threshold and a
    # MetricSpec is a metric. v1 declared the dimension in prose and the budgets
    # in benchmarks, and declared neither here — so `headline("distributional")`
    # had no answer and a population number reached a report with no row to name
    # it. @10 closes that.
    MetricSpec(
        name="significant_features", dimension=DISTRIBUTIONAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, model_ref="cozy-eval:stats",
        gated=True, headline=True, higher_is_better=False, note=(
            "dimension headline, POPULATION lane: how many per-clip features "
            "moved significantly across the paired prompt set — paired t with "
            "Holm correction and a practical-effect floor, so a tiny but "
            "perfectly consistent shift does not read as damage. The number the "
            "trajectory-perturbing lane gates on, where reference distance is "
            "meaningless. Needs n>=8 paired prompts (benchmarks.MIN_PROMPTS); "
            "below that it is a SampleSizeError, never a confident zero."
        ),
    ),
    MetricSpec(
        name="population_frechet", dimension=DISTRIBUTIONAL, impl="1.0",
        cost_class=CHEAP_DETERMINISTIC, model_ref="cozy-eval:stats",
        modality="video", gated=True, higher_is_better=False, note=(
            "Frechet distance between the two arms' clip-feature populations over "
            "cozy-eval's own closed-form features (no NC backbone, no 700-clip "
            "floor — this is not FVD and must not be quoted as one). GATES ON "
            "VIDEO from @11, and the modality is the whole ruling: the second "
            "clean population it owed since v1 is banked (H3, n=9 owner-labelled "
            "identical, 0.0665) and AGREES with the first to 2% across a "
            "different family (LTX-2.3, n=8, 0.0680), while an owner-rejected "
            "sparse-attention arm reads 3.4191. On IMAGES it stays out of the "
            "budget table entirely — two zero-change image null controls measured "
            "0.4688 and 1.3275 against the same 0.20 limit. See "
            "cozy_eval.image.IMAGE_BUDGETS and calibration/populations.json."
        ),
    ),
)

# Live registry. Rebuilt in place by register() so that modules holding a
# reference to THIS MODULE (``from cozy_eval import registry``) always see the
# current set. Do not do ``from .registry import REGISTRY`` — that snapshots.
REGISTRY: tuple[MetricSpec, ...] = BUILTIN
BY_NAME: dict[str, MetricSpec] = {}
GATED: tuple[str, ...] = ()
REPORT_ONLY: tuple[str, ...] = ()


def _rebuild() -> None:
    # Rebinding at module level is the point: holders of `from . import
    # registry` must see the live set.
    global BY_NAME, GATED, REPORT_ONLY  # noqa: PLW0603
    BY_NAME = {m.name: m for m in REGISTRY}
    GATED = tuple(m.name for m in REGISTRY if m.gated)
    REPORT_ONLY = tuple(m.name for m in REGISTRY if not m.gated)


for _spec in BUILTIN:
    validate(_spec)
del _spec
_BUILTIN_NAMES = frozenset(m.name for m in BUILTIN)
_rebuild()


def _importing_module() -> str:
    """The module currently being executed by the import machinery, if any.

    A metric that appears because a package was IMPORTED is the hole the
    registry exists to close: ``REGISTRY``, ``GATED`` and ``headline()`` would
    answer differently depending on what the caller happened to import, and a
    report's ``metric_set`` would no longer identify the set that produced it.
    HuggingFace ``evaluate``'s hub-loaded metric modules are the anti-lesson.
    So registration is refused while an import is in progress, and this walks
    the stack to find out. Cheap: only called from :func:`register`.
    """
    import sys
    from types import FrameType

    frame: FrameType | None = sys._getframe(1)
    # Walking OUTWARD from register(): the module body being imported sits
    # BELOW the import machinery that is executing it, so remember the most
    # recent <module> frame and report it the moment a bootstrap frame proves an
    # import is in progress. Looking for the module frame after the bootstrap
    # frames instead finds the process entry point, which is not what registered.
    last_module = ""
    while frame is not None:
        name = frame.f_globals.get("__name__", "")
        if name in ("importlib._bootstrap", "importlib._bootstrap_external"):
            return last_module or "<unknown module>"
        if frame.f_code.co_name == "<module>":
            last_module = name
        frame = frame.f_back
    return ""


#: Anything that would make the registry fetch or execute code from elsewhere.
#: A ``model_ref`` is an IDENTIFIER a caller resolves, never a location this
#: library retrieves — resolution and download are the caller's job (design §4).
_REMOTE_PREFIXES = ("http://", "https://", "ftp://", "git+", "s3://", "hf://", "file://")


def register(spec: MetricSpec, *, replace: bool = False) -> MetricSpec:
    """Add a metric to the live registry. The extension point for metrics that
    live OUTSIDE this package.

    General purpose means an outside package's metric appears in reports under
    the SAME identity discipline as ours, so this holds a third-party spec to
    every rule :func:`validate` holds ``BUILTIN`` to — dimension, direction,
    cost class, impl version, injection seam — plus three of its own:

    * **Explicit only.** Registering from a module body during import is
      refused. Call ``register()`` from your own code, deliberately.
    * **No remote code.** A ``model_ref`` that names a fetchable location is
      refused; a model ref identifies weights, it does not retrieve them.
    * **Builtins are sealed.** ``replace=True`` cannot overwrite a metric this
      package ships: a banked report's numbers would silently change meaning
      under a name whose ``impl`` it already recorded.
    """
    global REGISTRY  # noqa: PLW0603 — see _rebuild
    importing = _importing_module()
    if importing:
        raise RegistryError(
            f"metric {spec.name!r} tried to register while {importing!r} was being "
            "imported. Registration is explicit only: an eval number appearing "
            "because a package was installed is the import-side-effect hole the "
            "registry exists to close. Call cozy_eval.register(spec) from your own "
            "code instead of from a module body."
        )
    if any(spec.model_ref.startswith(p) for p in _REMOTE_PREFIXES):
        raise RegistryError(
            f"metric {spec.name!r} declares model_ref {spec.model_ref!r}, which names a "
            "location to fetch. A model_ref is an identifier that lands in the report, "
            "never something this library retrieves — resolution and download are the "
            "caller's job. Give the identifier (e.g. 'org/model-name')."
        )
    validate(spec)
    existing = BY_NAME.get(spec.name)
    if existing is not None:
        if not replace:
            raise RegistryError(
                f"metric {spec.name!r} is already registered; pass replace=True to override"
            )
        if spec.name in _BUILTIN_NAMES:
            raise RegistryError(
                f"metric {spec.name!r} is a builtin of this package and cannot be "
                f"replaced (it is at impl {existing.impl!r}). A banked report already "
                "records that name against that impl; silently swapping the math under "
                "it is the identity defect the impl version exists to prevent. Register "
                "your metric under its own name."
            )
    clash = [
        m.name for m in REGISTRY
        if m.headline and m.name != spec.name
        and m.dimension == spec.dimension and m.modality == spec.modality
    ]
    if spec.headline and clash:
        raise RegistryError(
            f"dimension {spec.dimension!r} already has headline metric {clash[0]!r} for "
            f"modality {spec.modality!r}; {spec.name!r} cannot also be the headline"
        )
    REGISTRY = (*(m for m in REGISTRY if m.name != spec.name), spec)
    _rebuild()
    return spec


def unregister(name: str) -> None:
    """Remove a registered third-party metric. Builtins are sealed."""
    global REGISTRY  # noqa: PLW0603 — see _rebuild
    if name in _BUILTIN_NAMES:
        raise RegistryError(
            f"metric {name!r} is a builtin of this package and cannot be unregistered; "
            "the metric set a report names must be the set this package declares"
        )
    REGISTRY = tuple(m for m in REGISTRY if m.name != name)
    _rebuild()


def by_dimension(dimension: str) -> tuple[MetricSpec, ...]:
    return tuple(m for m in REGISTRY if m.dimension == dimension)


def headline(dimension: str, modality: str = "any") -> MetricSpec:
    """The one number that names a dimension, for one kind of output.

    A dimension has exactly one headline per modality: similarity's is ``lpips``
    for a still, ``track_stability_ratio`` for a clip and ``audio_si_sdr`` for a
    soundtrack — the same question asked of different material, not three
    competing headlines. A modality with no headline of its own falls back to
    the ``any`` row.
    """
    if modality not in MODALITIES:
        raise RegistryError(f"unknown modality {modality!r}; known: {list(MODALITIES)}")
    picks = [m for m in by_dimension(dimension) if m.headline]
    exact = [m for m in picks if m.modality == modality]
    generic = [m for m in picks if m.modality == "any"]
    chosen = exact or generic
    if len(chosen) != 1:
        raise RegistryError(
            f"dimension {dimension!r} must have exactly one headline metric for "
            f"modality {modality!r}, has {[m.name for m in chosen]} "
            f"(all headlines: {[(m.name, m.modality) for m in picks]})"
        )
    return chosen[0]


def by_cost_class(cost_class: str) -> tuple[MetricSpec, ...]:
    """Every metric in one cost tier — the fact a consumer routes on.

    A training loop takes ``cheap-deterministic`` (and ``small-model`` where the
    extra is installed) in-process; ``model-backed`` goes to an eval endpoint.
    """
    if cost_class not in COST_CLASSES:
        raise RegistryError(
            f"unknown cost class {cost_class!r}; known: {list(COST_CLASSES)}"
        )
    return tuple(m for m in REGISTRY if m.cost_class == cost_class)


def reference_only() -> tuple[str, ...]:
    """Metric names that are only admissible on the same-trajectory lane."""
    return tuple(m.name for m in REGISTRY if m.reference_only)


def spec(name: str) -> MetricSpec:
    """Look up one metric, with an error that lists what does exist."""
    found = BY_NAME.get(name)
    if found is None:
        raise RegistryError(
            f"unknown metric {name!r}; registered: {sorted(BY_NAME)}"
        )
    return found


def reference_free() -> tuple[MetricSpec, ...]:
    """Metrics that score a single render — the absolute-evaluation mode."""
    return tuple(m for m in REGISTRY if not m.paired)


def registry_json() -> list[dict[str, Any]]:
    return [msgspec.to_builtins(m) for m in REGISTRY]


__all__ = [
    "ADHERENCE",
    "BUILTIN",
    "BY_NAME",
    "CHEAP_DETERMINISTIC",
    "COST_CLASSES",
    "DIMENSIONS",
    "DISTRIBUTIONAL",
    "GATED",
    "METRIC_SET_VERSION",
    "MODALITIES",
    "MODEL_BACKED",
    "NAME_PATTERN",
    "POOLS",
    "PREFERENCE",
    "QUALITY",
    "REDUNDANCY_EVIDENCE",
    "REGISTRY",
    "REPORT_ONLY",
    "SEAMS",
    "SIMILARITY",
    "SMALL_MODEL",
    "TEMPORAL",
    "MetricSpec",
    "by_cost_class",
    "by_dimension",
    "headline",
    "reference_free",
    "reference_only",
    "register",
    "registry_json",
    "spec",
    "unregister",
    "validate",
]
