"""Output integrity: the NOISE / BLANK / GRID floor every render must clear.

STABILITY: locked core (v0.x) for :func:`output_integrity`'s call shape and the
:class:`OutputIntegrity` it returns.

WHY THIS EXISTS. Production minimax-h3 0.3.8 served pure VAE-decoded NOISE on
billed, settled requests (ie#634). Nothing caught it: the "proof" banked ffprobe
metadata and a billing row, and nobody looked at pixels. Metadata is not pixels.
This is the cheapest possible instrument that would have caught it — median
adjacent-frame grey correlation over a handful of pairs spread across the clip,
plus a per-frame contrast floor for blank output. numpy only, no reference, no
model. MEASURED cost on a 121-frame 1344x768 uint8 clip (0.37 GB of pixels):
**8.3 ms**, because only ~10 frames are touched and each is decimated before the
float conversion. It is meant to run on EVERY render, including the serve path
before upload — at that price there is no run it is not worth doing.

THE FLOOR IS MEASURED, not guessed: VAE-decoded noise sits at 0.29, real renders
at 0.92-0.99. ``NOISE_CORR_FLOOR`` = 0.6 sits in that empty middle. The MEDIAN
over a spread of pairs is what makes a hard CUT safe — a cut drives one pair's
correlation to ~0 while the rest stay high.

THE GRID AXIS (@13) EXISTS BECAUSE THIS SCREEN PASSED A REJECTED RENDER. Four
whole-seam oracle renders scored adjacent_frame_corr 0.988/0.977 — a comfortable
pass — and the owner rejected all four on sight: "divided into little boxes...
you need to upgrade your analyzer so that you can detect issues like this". A
periodic lattice is perfectly self-similar frame to frame, so a correlation
floor is not merely insensitive to it, it is structurally blind: the defect
RAISES the number this screen reads. ``grid_peak_ratio`` measures the one thing
a lattice is and content is not — energy concentrated in a single spatial
frequency, at a fixed phase, in the same place on every frame — and its limit
comes from the same corpus in both directions (see
:data:`~cozy_eval.metrics.temporal.GRID_PEAK_LIMIT`).

SCOPE HONESTY — READ THIS BEFORE QUOTING A PASS. This gate catches NOISE, BLANK
and GRID. It is NOT a quality gate, and it is specifically blind to the fp8-melt
class: smearing REMOVES high-frequency temporal variation, so a melted render
scores HIGHER than a clean one (measured: melted arm 0.956 vs clean 0.916; a
blurred control here reproduces the same inversion). Fine-detail damage belongs
to :mod:`cozy_eval.detail`'s detectors and the VLM rubric; motion damage belongs
to the temporal-fidelity family. Four axes, no one of them sufficient — and the
grid axis is on the list only because an owner's eyes got there first, which is
the standing law GATE.md §8 now states for every artifact class after it.

Tri-state, like every verdict here: ``pass`` / ``reject`` / ``unmeasured``, and
UNMEASURED is never silently a pass.
"""

from __future__ import annotations

import time
from typing import Any

import msgspec

from .metrics import temporal

PASS = "pass"
REJECT = "reject"
UNMEASURED = "unmeasured"

#: Appended to every PASS so a green integrity line can never be read as a
#: quality pass. The melt class scores HIGHER here than a clean render.
SCOPE_NOTE = (
    "SCOPE: the integrity floor catches NOISE, BLANK and GRID/BLOCKY output "
    "only. It is not a quality gate — a melted/over-smoothed render scores "
    "HIGHER on adjacent_frame_corr than a clean one, so fine-detail damage "
    "needs the detail detectors + VLM rubric and motion damage needs the "
    "temporal-fidelity family."
)


class OutputIntegrity(msgspec.Struct, kw_only=True, forbid_unknown_fields=True):
    """One clip's integrity answer, and the two numbers behind it."""

    verdict: str = UNMEASURED
    defects: list[str] = msgspec.field(default_factory=list)
    #: None until measured. NOT NaN: NaN has no canonical JSON form, so it
    #: cannot enter a digest-stable report, and it compares false against
    #: itself — a floor check on one silently passes.
    adjacent_frame_corr: float | None = None
    frame_std_min: float | None = None
    #: Strongest periodic spatial line over its local spectral neighbourhood.
    grid_peak_ratio: float | None = None
    #: DIAGNOSTICS, not metrics — where the lattice is, for the lane that has to
    #: go and find it. A period locates a defect; it does not score one, so
    #: neither of these is registry-declared or part of contract_metrics().
    grid_period_px: float | None = None
    grid_axis: str = ""
    corr_series: list[float] = msgspec.field(default_factory=list)
    notes: list[str] = msgspec.field(default_factory=list)
    seconds: float = 0.0

    def contract_metrics(self) -> set[str]:
        return {n for n in ("adjacent_frame_corr", "frame_std_min", "grid_peak_ratio")
                if getattr(self, n) is not None}

    @property
    def ok(self) -> bool:
        """True only on an explicit PASS — UNMEASURED is not a pass."""
        return self.verdict == PASS

    def summary(self) -> str:
        head = f"integrity {self.verdict.upper()}"
        if self.defects:
            head += " — " + "; ".join(self.defects)
        def _n(v: float | None, places: int) -> str:
            return "UNMEASURED" if v is None else f"{v:.{places}f}"
        grid = _n(self.grid_peak_ratio, 2)
        if self.grid_peak_ratio is not None and self.grid_period_px:
            grid += f" @ {self.grid_period_px:.0f} px {self.grid_axis}"
        return (f"{head} (adjacent_frame_corr {_n(self.adjacent_frame_corr, 3)}, "
                f"frame_std_min {_n(self.frame_std_min, 4)}, "
                f"grid_peak_ratio {grid})")


def output_integrity(
    frames: Any,
    *,
    corr_floor: float = temporal.NOISE_CORR_FLOOR,
    std_floor: float = temporal.BLANK_STD_FLOOR,
    grid_limit: float = temporal.GRID_PEAK_LIMIT,
    pairs: int = temporal.INTEGRITY_PAIRS,
) -> OutputIntegrity:
    """Reject a clip that is noise, blank, or a grid of blocks. No reference.

    ``frames`` is any clip form :func:`cozy_eval.metrics.temporal.as_frames`
    accepts, but only the ~``2 * pairs`` sampled frames are ever touched, so the
    cost does not grow with clip length. A clip too short to have an adjacent
    pair comes back UNMEASURED, never a pass.

    The three axes are measured INDEPENDENTLY and every one that trips is
    reported: a clip can be blank on one frame and gridded on another, and a
    screen that stopped at the first defect would hand the diagnosing lane one
    symptom out of two. Each axis can also be UNMEASURED on its own — a clip too
    short to have an adjacent pair still has frames wide enough to be gridded.
    """
    t0 = time.monotonic()
    result = OutputIntegrity()
    unmeasured = 0
    try:
        stats = temporal.integrity_stats(frames, pairs=pairs)
    except Exception as exc:  # an unscoreable clip is UNMEASURED, never a pass
        unmeasured += 1
        result.notes.append(f"NOISE/BLANK AXES UNMEASURED: {exc}")
    else:
        result.corr_series = [float(v) for v in stats["corr_series"]]
        result.adjacent_frame_corr = float(stats["adjacent_frame_corr"])
        result.frame_std_min = float(stats["frame_std_min"])

        if result.frame_std_min < std_floor:
            result.defects.append(
                f"BLANK: a sampled frame carries no spatial signal "
                f"(std {result.frame_std_min:.5f} < {std_floor})"
            )
        if result.adjacent_frame_corr < corr_floor:
            result.defects.append(
                f"NOISE: median adjacent-frame correlation "
                f"{result.adjacent_frame_corr:.3f} < floor {corr_floor} — consecutive "
                f"frames are unrelated, which is what VAE-decoded noise looks like"
            )

    try:
        grid = temporal.grid_stats(frames, frames=pairs)
    except Exception as exc:
        unmeasured += 1
        result.notes.append(f"GRID AXIS UNMEASURED: {exc}")
    else:
        result.grid_peak_ratio = float(grid["grid_peak_ratio"])
        result.grid_period_px = float(grid["grid_period_px"])
        result.grid_axis = str(grid["grid_axis"])
        if result.grid_peak_ratio > grid_limit:
            result.defects.append(
                f"GRID: periodic spatial energy {result.grid_peak_ratio:.2f}x its "
                f"local spectral neighbourhood at a {result.grid_period_px:.0f} px "
                f"period along {result.grid_axis} > limit {grid_limit} — the render "
                f"is divided into blocks. Look for a tiled/chunked VAE decode, a "
                f"block-quantized decode path, or a DiT patch lattice"
            )

    # A defect is decisive whatever else could not be read. Otherwise an axis
    # this screen could not measure LEAVES it UNMEASURED: the clip cleared the
    # floors that ran, which is not the same fact as clearing the screen, and
    # this library never spells the second as the first.
    if result.defects:
        result.verdict = REJECT
    elif unmeasured:
        result.seconds = round(time.monotonic() - t0, 4)
        return result
    else:
        result.verdict = PASS
    if result.verdict == PASS:
        result.notes.append(SCOPE_NOTE)
    result.seconds = round(time.monotonic() - t0, 4)
    return result


__all__ = [
    "PASS",
    "REJECT",
    "SCOPE_NOTE",
    "UNMEASURED",
    "OutputIntegrity",
    "output_integrity",
]
