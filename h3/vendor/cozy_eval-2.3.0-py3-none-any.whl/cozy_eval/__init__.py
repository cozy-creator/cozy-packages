"""cozy-eval — quality evaluation for generative image and video models, with
the validity rules built into the API.

Everything here is an evaluation; they differ in what they measure, not in kind.
Six dimensions, in :mod:`cozy_eval.metrics`:

  similarity      how far did the pixels move from a reference render
  adherence       did the render contain what the prompt asked for
  preference      would a human prefer it
  quality         does it look good on its own terms, no reference, no prompt
  temporal        did the frames stop agreeing with each other
  distributional  did the population of outputs shift

The measurements are ordinary. The opinion is not, and it governs all of them:

* **Two lanes, enforced.** Reference metrics (PSNR/SSIM/LPIPS/VMAF) are valid only
  when the compared change leaves the sampling trajectory intact. Ask for them on
  a quantization or compile comparison and the library raises.
* **Protocol stamping.** Every result carries resolution, frame count, steps,
  seeds, prompt set, execution lane and hardware. A number without those is not
  a result.
* **Population semantics.** Trajectory-perturbing comparisons are gated over
  n>=8 paired prompts, because a single prompt measures the take, not the recipe.
* **Thresholds with provenance.** Every budget names the known-good and
  known-bad populations that fixed it, and its separation margin.
* **Null controls.** A budget only holds where a zero-change arm (same weights,
  different seeds) sits inside it. ``measure_null_control`` measures that per
  family; budgets its control trips are disregarded, and a run with disregarded
  budgets cannot rise above INDETERMINATE.
* **No signal is not a failure.** An arm of constant frames returns DEGENERATE,
  never a confident FAIL with an imaging index of 0.0.
* **Registry as data.** ``import cozy_eval`` sees the complete metric table
  without importing a single scoring backend; external metrics join through
  :func:`register`.

Quick start — the gate::

    from cozy_eval import ChangeKind, Protocol, score_pairs, run_population_gate

    proto = Protocol(
        family="ltx-2.3-distilled",
        reference_arm="bf16 compiled", candidate_arm="w8a8-pcs compiled",
        changes=(ChangeKind.WEIGHT_QUANTIZATION, ChangeKind.ACTIVATION_QUANTIZATION),
        width=1280, height=704, frames=121, steps=8,
        seeds=(8,), prompts=("forge", "chef", "market", "portrait",
                             "fabric", "street", "water", "forest"),
        execution_lane="compiled", hardware="NVIDIA H100 80GB HBM3",
    )
    pairs = score_pairs(reference_clips, candidate_clips)
    print(run_population_gate(pairs, proto).summary())

Quick start — the prompt-adherence suite::

    from cozy_eval import promptset, suite

    report = suite.run(samples, candidates,
                       checklists=promptset.checklists_for("hard-eval-v1"))
    print(report.summary("element_recall"))

STABILITY (v0.x)
----------------

Locked core: everything re-exported here — the metric names, the registry, the
report schema, the checklist and prompt-set formats, the verdicts, the Judge
protocols, the protocol/lane rules. Experimental: the concrete scoring code
under :mod:`cozy_eval.metrics`. The metric NAMES those modules produce are
locked by the registry; their functions and internals may change in any 0.x
release.
"""

from importlib.metadata import PackageNotFoundError, version

from . import resources

# FIRST, before numpy/torch/OpenCV land: their thread pools are sized from the
# environment at first use and never resized. See cozy_eval.resources.
resources.configure()


def _installed_version() -> str:
    # Read from the installed distribution rather than a literal: v1 shipped
    # __version__ = "0.1.0" from a pyproject that said 0.2.0 for a whole release,
    # which is the same class of defect as an unversioned metric impl.
    try:
        return version("cozy-eval")
    except PackageNotFoundError:
        return "0+unknown"


__version__ = _installed_version()

from . import (  # noqa: E402
    accumulate,
    audio,
    catalog,
    detail,
    device,
    errors,
    identity,
    integrity,
    judge,
    metrics,
    promptset,
    registry,
    suite,
    tracks,
    verdict,
    video,
)
from .accumulate import MetricAccumulator, SuiteAccumulator, pool  # noqa: E402
from .audio import (  # noqa: E402
    AUDIO_DEFECTS,
    AudioChecklist,
    AudioSample,
    AudioVerdict,
    Defect,
    audio_verdict,
    probe_audio,
    read_audio,
    run_audio,
)
from .benchmarks import (  # noqa: E402
    MIN_PROMPTS,
    REFERENCE_BUDGETS,
    VIDEO_BUDGETS,
    BenchmarkResult,
    Budget,
    distributional,
    imaging,
    temporal,
)
from .catalog import add_checklist_set, checklist_set  # noqa: E402
from .contract import (  # noqa: E402
    SCHEMAS,
    canonical,
    digest_bytes,
    dump,
    load,
    load_verified,
    save,
)
from .control import NullControl, measure_null_control  # noqa: E402
from .detail import (  # noqa: E402
    DetailVerdict,
    detail_verdict,
    score_detail_vlm,
)
from .device import AUTO, resolve_device  # noqa: E402
from .errors import (  # noqa: E402
    BackendError,
    ConfigError,
    CozyEvalError,
    DataError,
    DecodeError,
    MetricIdentityError,
    ProtocolError,
    RegistryError,
    SampleSizeError,
    TrajectoryPerturbingError,
)
from .frames import iter_frames, probe  # noqa: E402
from .gate import GateReport, run_population_gate, run_reference_gate, score_pairs  # noqa: E402
from .identity import ScoreRow, require_comparable, require_same_impl  # noqa: E402
from .image import IMAGE_BUDGETS, run_image_population_gate, score_image  # noqa: E402
from .integrity import OutputIntegrity, output_integrity  # noqa: E402
from .judge import (  # noqa: E402
    AudioJudge,
    Judge,
    PreferenceScorer,
    SoftJudge,
    Transcriber,
)
from .metrics.adherence import (  # noqa: E402
    Checklist,
    ChecklistItem,
    ChecklistSet,
    EditChecklist,
    VideoChecklist,
    load_checklists,
)
from .metrics.audio import Audio, as_audio  # noqa: E402
from .metrics.avsync import SyncEstimate, sync_offset  # noqa: E402
from .metrics.signal import ClipScore  # noqa: E402
from .metrics.signal import score as score_clip  # noqa: E402
from .promptset import PromptSet, add_prompt_set, checklists_for  # noqa: E402
from .protocol import (  # noqa: E402
    ChangeKind,
    Lane,
    Protocol,
    Verdict,
    admissible,
    classify_change,
    require_admissible,
    require_reference_lane,
)
from .registry import (  # noqa: E402
    CHEAP_DETERMINISTIC,
    METRIC_SET_VERSION,
    MODEL_BACKED,
    SMALL_MODEL,
    MetricSpec,
    by_cost_class,
    headline,
    register,
)
from .resources import ComputeBudget  # noqa: E402
from .suite import DimensionSummary, Sample, SampleRow, SuiteReport  # noqa: E402
from .tracks import TrackVerdict, track_verdict  # noqa: E402
from .verdict import Measurement, ParityVerdict, Threshold, evaluate  # noqa: E402
from .video import VideoSample, run_video  # noqa: E402

__all__ = [
    "AUDIO_DEFECTS",
    "AUTO",
    "CHEAP_DETERMINISTIC",
    "IMAGE_BUDGETS",
    "METRIC_SET_VERSION",
    "MIN_PROMPTS",
    "MODEL_BACKED",
    "REFERENCE_BUDGETS",
    "SCHEMAS",
    "SMALL_MODEL",
    "VIDEO_BUDGETS",
    "Audio",
    "AudioChecklist",
    "AudioJudge",
    "AudioSample",
    "AudioVerdict",
    "BackendError",
    "BenchmarkResult",
    "Budget",
    "ChangeKind",
    "Checklist",
    "ChecklistItem",
    "ChecklistSet",
    "ClipScore",
    "ComputeBudget",
    "ConfigError",
    "CozyEvalError",
    "DataError",
    "DecodeError",
    "Defect",
    "DetailVerdict",
    "DimensionSummary",
    "EditChecklist",
    "GateReport",
    "Judge",
    "Lane",
    "Measurement",
    "MetricAccumulator",
    "MetricIdentityError",
    "MetricSpec",
    "NullControl",
    "OutputIntegrity",
    "ParityVerdict",
    "PreferenceScorer",
    "PromptSet",
    "Protocol",
    "ProtocolError",
    "RegistryError",
    "Sample",
    "SampleRow",
    "SampleSizeError",
    "ScoreRow",
    "SoftJudge",
    "SuiteAccumulator",
    "SuiteReport",
    "SyncEstimate",
    "Threshold",
    "TrackVerdict",
    "TrajectoryPerturbingError",
    "Transcriber",
    "Verdict",
    "VideoChecklist",
    "VideoSample",
    "__version__",
    "accumulate",
    "add_checklist_set",
    "add_prompt_set",
    "admissible",
    "as_audio",
    "audio",
    "audio_verdict",
    "by_cost_class",
    "canonical",
    "catalog",
    "checklist_set",
    "checklists_for",
    "classify_change",
    "contract",
    "detail",
    "detail_verdict",
    "device",
    "digest_bytes",
    "distributional",
    "dump",
    "errors",
    "evaluate",
    "headline",
    "identity",
    "imaging",
    "integrity",
    "iter_frames",
    "judge",
    "load",
    "load_checklists",
    "load_verified",
    "measure_null_control",
    "metrics",
    "output_integrity",
    "pool",
    "probe",
    "probe_audio",
    "promptset",
    "read_audio",
    "register",
    "registry",
    "require_admissible",
    "require_comparable",
    "require_reference_lane",
    "require_same_impl",
    "resolve_device",
    "resources",
    "run_audio",
    "run_image_population_gate",
    "run_population_gate",
    "run_reference_gate",
    "run_video",
    "save",
    "score_clip",
    "score_detail_vlm",
    "score_image",
    "score_pairs",
    "suite",
    "sync_offset",
    "temporal",
    "track_verdict",
    "tracks",
    "verdict",
    "video",
]
