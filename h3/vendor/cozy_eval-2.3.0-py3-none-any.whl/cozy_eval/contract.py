"""The report contract: canonical bytes, one schema registry, strict decode.

STABILITY: locked core (v0.x). This module IS the downstream API — a report is a
digest-verified typed input to jobs that never saw the run that produced it.

**Canonical bytes.** RFC 8785 (JCS) over the I-JSON subset: keys sorted by UTF-16
code unit, no insignificant whitespace, ES6 shortest-round-trip number formatting,
minimal string escapes, UTF-8 output. Equal reports are equal bytes, so
``sha256(bytes)`` identifies a result. NaN, Infinity and integers outside
+-(2^53-1) are REFUSED at encode: a document that cannot be read back
identically by every conforming reader is not canonical, and silently emitting
one is how a digest stops meaning anything.

cozy-eval implements its own writer rather than importing one. The library's base
install is numpy + msgspec and stays that way; the conventions are tensorfs
tfs-013's (sorted keys, lowercase ``sha256:``, stored bytes ARE the canonical
bytes, strict unknown-field refusal) so the two agree on the wire without either
depending on the other.

**Stored bytes are the canonical bytes.** :func:`load` re-canonicalizes what it
parsed and refuses if the input differs. That one rule subsumes key order,
whitespace, duplicate keys and number spelling: there is exactly one byte string
per document, so a digest is an identity and not a hash of one particular
spelling.

**Strict decode.** Every contract struct sets ``forbid_unknown_fields=True`` and
every schema id is looked up in :data:`SCHEMAS`. An unknown field or an unknown
schema version is a typed refusal (:class:`~cozy_eval.errors.DecodeRefusal` /
:class:`~cozy_eval.errors.SchemaRefusal`), never a best-effort partial read.
msgspec's tolerant default is deliberately dead on this path.

**Version policy.** Bump the ``@N`` in a body's schema id on ANY field or
semantic change, additive included. A downstream digest must not drift because a
field was added: a report written by a newer writer is a DIFFERENT document, and
the previous decoder must refuse it rather than read the subset it recognizes.
Bumping is cheap; a silently-widened contract is not.

**The stamp.** A document carries the schema id, the metric-set version, the
``{metric: impl}`` identity map (cozy_eval.identity) and the protocol stamp. A
report that cannot name its protocol must say WHY in ``protocol_absent``;
:func:`require_protocol` is the gate a consumer that needs a stamped one calls.
There is no third option — encoding with neither refuses.

The library VERSION is deliberately NOT stamped. It was, until the fixture bank
caught what that costs: a cosmetic release changes every report's digest while
changing no number, which contradicts the one property this module exists to
provide. What identifies a number is ``(metric_set, metric, impl)`` — the code
version is not part of it, and bumping ``impl`` is how a changed number is
announced.
"""

from __future__ import annotations

import decimal
import hashlib
import importlib
import json
from pathlib import Path
from typing import Any

import msgspec

from . import registry
from .errors import (
    ContractError,
    DecodeRefusal,
    DigestMismatch,
    EncodeRefusal,
    SchemaRefusal,
)

#: The envelope's own version. Bump when the envelope's FIELDS change; a body
#: schema id versions the body alone.
DOCUMENT_SCHEMA = "cozy-eval/document@1"

#: schema id -> "module:attribute" for every contract struct. Data, not
#: decorators: registration by import side effect is the hole
#: :mod:`cozy_eval.registry` exists to close, and the same argument applies here.
SCHEMAS: dict[str, str] = {
    "cozy-eval/suite-report@4": "cozy_eval.suite:SuiteReport",
    "cozy-eval/gate-report@1": "cozy_eval.gate:GateReport",
    "cozy-eval/audio-verdict@1": "cozy_eval.audio:AudioVerdict",
    "cozy-eval/track-verdict@1": "cozy_eval.tracks:TrackVerdict",
    "cozy-eval/detail-verdict@1": "cozy_eval.detail:DetailVerdict",
    # @2 adds the GRID/BLOCKINESS axis (grid_peak_ratio + its two locating
    # diagnostics). Additive, and bumped anyway: the version policy above is
    # that a report written by a newer writer is a DIFFERENT document.
    "cozy-eval/output-integrity@2": "cozy_eval.integrity:OutputIntegrity",
}

_MAX_SAFE_INT = 2**53 - 1


# ---------------------------------------------------------------------------
# canonical bytes (RFC 8785 over I-JSON)
# ---------------------------------------------------------------------------

def _number(value: float) -> str:
    """ES6 ``Number::toString`` — RFC 8785 section 3.2.2.3.

    Python's ``repr`` is already the shortest round-tripping decimal; the work
    here is spelling it the way ECMAScript does, so a canonicalizer in another
    language produces the same bytes.
    """
    if value != value or value in (float("inf"), float("-inf")):
        raise EncodeRefusal(
            f"{value!r} has no canonical JSON form. NaN and Infinity are not "
            "JSON numbers, so a document containing one cannot round-trip and "
            "its digest would identify nothing. If the quantity was not "
            "measured, encode null and say why — 'unmeasured' and 'zero' are "
            "different facts and this library never conflates them."
        )
    if value == 0.0:
        return "0"          # -0.0 spells as 0, like ECMAScript
    sign = "-" if value < 0 else ""
    dec = decimal.Decimal(repr(abs(value)))
    digits, exp = dec.as_tuple()[1], int(dec.as_tuple()[2])
    while len(digits) > 1 and digits[-1] == 0:      # strip trailing zeros
        digits, exp = digits[:-1], exp + 1
    s = "".join(str(d) for d in digits)
    k = len(s)
    n = exp + k                                     # value = 0.<s> x 10^n
    if k <= n <= 21:
        return f"{sign}{s}{'0' * (n - k)}"
    if 0 < n <= 21:
        return f"{sign}{s[:n]}.{s[n:]}"
    if -6 < n <= 0:
        return f"{sign}0.{'0' * -n}{s}"
    head = s[0] if k == 1 else f"{s[0]}.{s[1:]}"
    e = n - 1
    return f"{sign}{head}e{'+' if e >= 0 else '-'}{abs(e)}"


def _key(name: str) -> bytes:
    # RFC 8785 sorts by UTF-16 code unit; Python sorts str by code point. They
    # differ above the BMP, so sort on the actual UTF-16 bytes.
    return name.encode("utf-16-be", "surrogatepass")


def _write(value: Any, out: list[str], path: str) -> None:
    if value is None or value is True or value is False:
        out.append({None: "null", True: "true", False: "false"}[value])
    elif isinstance(value, str):
        out.append(json.dumps(value, ensure_ascii=False))
    elif isinstance(value, int):
        if abs(value) > _MAX_SAFE_INT:
            raise EncodeRefusal(
                f"{path}: {value} is outside the interoperable integer range "
                f"+-{_MAX_SAFE_INT}. A reader that parses JSON numbers as doubles "
                "would round it, so the bytes would not survive a round trip."
            )
        out.append(str(value))
    elif isinstance(value, float):
        out.append(_number(value))
    elif isinstance(value, (list, tuple)):
        out.append("[")
        for i, item in enumerate(value):
            if i:
                out.append(",")
            _write(item, out, f"{path}[{i}]")
        out.append("]")
    elif isinstance(value, dict):
        for name in value:
            if not isinstance(name, str):
                raise EncodeRefusal(
                    f"{path}: object key {name!r} is not a string; JSON has no "
                    "canonical ordering for anything else"
                )
        out.append("{")
        for i, name in enumerate(sorted(value, key=_key)):
            if i:
                out.append(",")
            out.append(json.dumps(name, ensure_ascii=False))
            out.append(":")
            _write(value[name], out, f"{path}.{name}")
        out.append("}")
    else:
        raise EncodeRefusal(
            f"{path}: {type(value).__name__} has no canonical JSON form. Give the "
            "field a JSON-native type (or a contract struct) rather than letting "
            "a serializer guess."
        )


def canonical(value: Any) -> bytes:
    """Canonical bytes for already-plain data. Structs go through :func:`dump`."""
    out: list[str] = []
    _write(value, out, "$")
    return "".join(out).encode("utf-8")


def digest_bytes(data: bytes) -> str:
    """``sha256:<hex>`` over exact bytes — tfs-013's spelling."""
    return "sha256:" + hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------------------
# the envelope
# ---------------------------------------------------------------------------

class Envelope(msgspec.Struct, frozen=True, kw_only=True, forbid_unknown_fields=True):
    """What every contract document is wrapped in. The body is left raw so an
    unknown schema id refuses BEFORE anything is decoded into a type."""

    document: str
    schema: str
    metric_set: str
    impls: dict[str, str]
    protocol: Any = None
    protocol_absent: str = ""
    body: msgspec.Raw = msgspec.Raw()


class Sealed(msgspec.Struct, frozen=True, kw_only=True):
    """A loaded document: the decoded body plus everything stamped around it."""

    schema: str
    metric_set: str
    impls: dict[str, str]
    body: Any
    protocol: Any = None
    protocol_absent: str = ""
    digest: str = ""

    def require_protocol(self) -> Any:
        """The protocol stamp, or a typed refusal naming why it is absent.

        What a consumer that gates on a comparison calls. A number without its
        protocol is not a result: the lane — and therefore which metrics were
        even admissible — follows from what changed and nothing else.
        """
        if self.protocol is None:
            raise ContractError(
                f"this {self.schema} document carries no protocol stamp: "
                f"{self.protocol_absent or 'no reason recorded'}. Its numbers are "
                "unvalidated by construction — nothing in them says whether the "
                "reference render was even the same take — so they cannot decide "
                "a gate. Re-run with protocol= declared."
            )
        return self.protocol


def schema_id(body: Any) -> str:
    """The registered schema id for a contract struct, or a typed refusal."""
    target = f"{type(body).__module__}:{type(body).__qualname__}"
    for sid, path in SCHEMAS.items():
        if path == target:
            return sid
    raise SchemaRefusal(
        f"{target} is not a contract struct. Only the structs in "
        f"cozy_eval.contract.SCHEMAS have canonical bytes and a version policy: "
        f"{sorted(SCHEMAS)}. Everything else is internal and may change shape "
        "without a version bump, so encoding one as a document would promise a "
        "stability it does not have."
    )


def resolve(sid: str) -> type:
    """The struct type behind a schema id, or a typed refusal."""
    path = SCHEMAS.get(sid)
    if path is None:
        raise SchemaRefusal(
            f"unknown schema {sid!r}: this build of cozy-eval "
            f"({registry.METRIC_SET_VERSION} metric set) knows {sorted(SCHEMAS)}. "
            "A schema id is bumped on ANY field or semantic change, so a document "
            "from a newer writer is a different contract — reading the fields this "
            "version happens to recognize would silently drop the rest. Upgrade "
            "cozy-eval, or read the document with the version that wrote it."
        )
    module, _, attr = path.partition(":")
    resolved: type = getattr(importlib.import_module(module), attr)
    return resolved


def _plain(value: Any, what: str) -> Any:
    try:
        return msgspec.to_builtins(value, str_keys=True)
    except (TypeError, msgspec.ValidationError) as exc:
        raise EncodeRefusal(f"{what} holds a value with no canonical form: {exc}") from exc


def _metric_names(body: Any, sid: str) -> set[str]:
    """The registered metrics a document carries NUMBERS for.

    Every contract struct declares this itself. The generic alternative — walking
    the encoded form for keys that happen to be metric names — was written first
    and was wrong twice over: it stamped ``lpips`` for a report whose
    ``seconds["lpips"]`` was a timing, and for one that listed lpips in
    ``unmeasured`` as REFUSED. A stamp asserts "this document holds a number
    produced by that implementation", so it has to come from the struct that
    knows, not from a name collision.
    """
    declare = getattr(body, "contract_metrics", None)
    if declare is None:
        raise SchemaRefusal(
            f"{sid} does not declare contract_metrics(): a contract struct must "
            "name the metrics it carries numbers for, because the impl stamp is "
            "what makes those numbers comparable later"
        )
    return {n for n in declare() if n in registry.BY_NAME}


def dump(
    body: Any,
    *,
    protocol: Any = None,
    protocol_absent: str = "",
    impls: dict[str, str] | None = None,
) -> bytes:
    """Canonical bytes for one contract struct, stamped and complete.

    Exactly one of ``protocol`` / ``protocol_absent`` must be given. ``impls``
    defaults to the registry's current implementation version for every metric
    the document mentions — the identity that makes two banked numbers
    subtractable (see :mod:`cozy_eval.identity`).
    """
    sid = schema_id(body)
    if (protocol is None) == (not protocol_absent):
        raise EncodeRefusal(
            f"{sid} needs either a protocol= stamp or a protocol_absent= reason, "
            "and exactly one of them. A quality number without its protocol is "
            "not a result; if this run genuinely has no comparison to stamp (a "
            "single-model reference-free scoring pass, say), record that as the "
            "reason so the gap travels with the document instead of being "
            "indistinguishable from a stamp someone forgot."
        )
    check = getattr(body, "contract_check", None)
    if check is not None:
        try:
            check()
        except ContractError as exc:
            raise EncodeRefusal(f"{sid} is not internally honest: {exc}") from exc
    plain_body = _plain(body, sid)
    named = _metric_names(body, sid)
    stamped = dict(impls) if impls is not None else {n: registry.spec(n).impl for n in named}
    missing = sorted(named - set(stamped))
    if missing:
        raise EncodeRefusal(
            f"{sid} reports {missing} but the impl stamp does not name them. A "
            "metric NAME does not identify a number — (name, impl) does — so an "
            "unstamped row cannot be compared to anything later. Pass "
            "impls=cozy_eval.identity.impls(names), or leave impls unset and let "
            "the registry stamp what the document mentions."
        )
    unknown = sorted(set(stamped) - set(registry.BY_NAME))
    if unknown:
        raise EncodeRefusal(
            f"{sid} stamps impl versions for unregistered metrics {unknown}: an "
            "impl version is the registry's fact about a metric, not a free label"
        )
    return canonical({
        "document": DOCUMENT_SCHEMA,
        "schema": sid,
        "metric_set": registry.METRIC_SET_VERSION,
        "impls": stamped,
        "protocol": _plain(protocol, "protocol") if protocol is not None else None,
        "protocol_absent": protocol_absent,
        "body": plain_body,
    })


def load(data: bytes, *, expect: type | None = None) -> Sealed:
    """Decode canonical bytes into a stamped, typed document, or refuse.

    Refuses non-canonical bytes, an unknown schema id, an unknown field anywhere
    in the envelope or the body, and a body that does not match ``expect``.
    """
    try:
        parsed = msgspec.json.decode(data)
    except msgspec.DecodeError as exc:
        raise DecodeRefusal(f"not JSON: {exc}") from exc
    recanonical = canonical(parsed)
    if recanonical != data:
        raise DecodeRefusal(
            "these bytes are not canonical, so they are not a cozy-eval document. "
            "Stored bytes ARE the canonical bytes — key order, whitespace, "
            "duplicate keys and number spelling all have exactly one legal form, "
            "because otherwise two byte strings would carry one report and the "
            f"digest would identify a spelling rather than a result. Got "
            f"{len(data)} bytes, canonical form is {len(recanonical)}."
        )
    try:
        env = msgspec.json.decode(data, type=Envelope)
    except msgspec.ValidationError as exc:
        raise DecodeRefusal(f"envelope refused: {exc}") from exc
    if env.document != DOCUMENT_SCHEMA:
        raise SchemaRefusal(
            f"unknown envelope {env.document!r}; this build writes and reads "
            f"{DOCUMENT_SCHEMA}"
        )
    body_type = resolve(env.schema)
    if expect is not None and body_type is not expect:
        raise SchemaRefusal(
            f"expected a {expect.__name__} document, got {env.schema} "
            f"({body_type.__name__})"
        )
    try:
        body: Any = msgspec.json.decode(env.body, type=body_type)
    except msgspec.ValidationError as exc:
        raise DecodeRefusal(
            f"{env.schema} body refused: {exc}. Unknown fields are a REFUSAL here, "
            "not something to skip: a field this version does not know is a "
            "semantic change the schema id should have been bumped for."
        ) from exc
    check = getattr(body, "contract_check", None)
    if check is not None:
        try:
            check()
        except ContractError as exc:
            raise DecodeRefusal(f"{env.schema} body is not internally honest: {exc}") from exc
    protocol = None
    if env.protocol is not None:
        from .protocol import Protocol

        try:
            protocol = msgspec.convert(env.protocol, type=Protocol)
        except (msgspec.ValidationError, ValueError) as exc:
            # ValueError covers ProtocolError: Protocol.__post_init__ re-validates
            # on decode, so a stamp that could not have been constructed cannot be
            # smuggled in as bytes either.
            raise DecodeRefusal(f"protocol stamp refused: {exc}") from exc
    return Sealed(
        schema=env.schema, metric_set=env.metric_set, impls=env.impls, body=body,
        protocol=protocol, protocol_absent=env.protocol_absent,
        digest=digest_bytes(data),
    )


def load_verified(path: str | Path, expected: str, *, expect: type | None = None) -> Sealed:
    """Load a document and refuse unless its digest is ``expected``.

    The helper every downstream consumer calls. A report is evidence a job binds
    a verdict to; binding to bytes nobody checked is binding to nothing.
    """
    data = Path(path).read_bytes()
    actual = digest_bytes(data)
    if actual != expected:
        raise DigestMismatch(
            f"{path} does not carry the expected report: wanted {expected}, "
            f"read {actual} over {len(data)} bytes. The file was edited, "
            "truncated, re-serialized by a non-canonical writer, or is simply a "
            "different run — in every one of those cases the verdict this report "
            "was going to justify is unsupported."
        )
    return load(data, expect=expect)


def save(path: str | Path, body: Any, **stamp: Any) -> str:
    """Write canonical bytes to ``path``; return the digest."""
    data = dump(body, **stamp)
    Path(path).write_bytes(data)
    return digest_bytes(data)


__all__ = [
    "DOCUMENT_SCHEMA",
    "SCHEMAS",
    "Envelope",
    "Sealed",
    "canonical",
    "digest_bytes",
    "dump",
    "load",
    "load_verified",
    "resolve",
    "save",
    "schema_id",
]
