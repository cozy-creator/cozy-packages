"""``cozy-eval`` command line.

Four subcommands:

* ``score``  — no-reference statistics for one or more clips/images.
* ``gate``   — run the full population gate on a paired prompt set.
* ``compare``— reference metrics for a same-trajectory change (refuses otherwise).
* ``corpus`` — ``show`` / ``lint`` / ``seal`` a corpus dataset tree.

Every run states its compute budget on the first line and stays inside it:
``--threads`` caps threads AND the worker pool, which splits that budget rather
than multiplying it. See :mod:`cozy_eval.resources`.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from . import __version__, contract, resources
from . import corpus as corpus_mod
from .errors import DataError, TrajectoryPerturbingError
from .gate import run_population_gate, run_reference_gate
from .metrics.signal import score
from .protocol import ChangeKind, Protocol


def _protocol(a: argparse.Namespace, n_prompts: int) -> Protocol:
    return Protocol(
        family=a.family,
        reference_arm=a.reference_arm,
        candidate_arm=a.candidate_arm,
        changes=tuple(ChangeKind(c) for c in a.change),
        width=a.width, height=a.height, frames=a.frames, steps=a.steps,
        seeds=tuple(a.seed) or (0,),
        prompts=tuple(a.prompt) if a.prompt else tuple(str(i) for i in range(n_prompts)),
        execution_lane=a.execution_lane,
        hardware=a.hardware,
        same_pod=not a.cross_pod,
    )


def _add_protocol_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--family", required=True)
    p.add_argument("--reference-arm", required=True)
    p.add_argument("--candidate-arm", required=True)
    p.add_argument("--change", action="append", required=True,
                   choices=[str(c) for c in ChangeKind],
                   help="what the candidate changed; repeatable. Decides the lane.")
    p.add_argument("--width", type=int, required=True)
    p.add_argument("--height", type=int, required=True)
    p.add_argument("--frames", type=int, required=True)
    p.add_argument("--steps", type=int, required=True)
    p.add_argument("--seed", type=int, action="append", default=[])
    p.add_argument("--prompt", action="append", default=[])
    p.add_argument("--execution-lane", choices=("compiled", "eager"), required=True)
    p.add_argument("--hardware", required=True)
    p.add_argument("--cross-pod", action="store_true",
                   help="declare that the arms were NOT rendered on the same pod")


_WORKERS_HELP = ("clips scored in parallel; default: half the thread budget, "
                 "each worker taking an equal share of it")


def _reexec_with_threads(threads: int | None) -> None:
    """Make ``--threads`` mean exactly what ``COZY_EVAL_THREADS`` means.

    BLAS pools are sized when their library loads — which already happened,
    importing this package, before argparse ever saw the flag. So put the value
    in the environment and start over once. The child hits neither branch.
    """
    if threads is None or str(threads) == os.environ.get(resources.THREADS_ENV):
        return
    env = {**os.environ, resources.THREADS_ENV: str(threads)}
    os.execve(sys.executable, [sys.executable, "-m", "cozy_eval", *sys.argv[1:]], env)


def _pool(workers: int | None) -> ProcessPoolExecutor:
    """A pool that SPLITS the budget: ``workers * worker_threads <= threads``."""
    budget = resources.active()
    n = resources.worker_count(workers)
    return ProcessPoolExecutor(
        max_workers=n,
        initializer=resources.pool_worker_init,
        initargs=(max(1, budget.threads // n),),
    )


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser("cozy-eval", description=__doc__)
    ap.add_argument("--version", action="version", version=__version__)
    ap.add_argument("--threads", type=int, default=None,
                    help="compute-thread budget for the whole run "
                         "(default: min(4, cpu_count))")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("score", help="no-reference statistics for clips/images")
    s.add_argument("paths", nargs="+")
    s.add_argument("--workers", type=int, default=None, help=_WORKERS_HELP)
    s.add_argument("--json", type=Path)

    g = sub.add_parser("gate", help="population gate over a paired prompt set")
    g.add_argument("--reference", action="append", required=True)
    g.add_argument("--candidate", action="append", required=True)
    g.add_argument("--workers", type=int, default=None, help=_WORKERS_HELP)
    g.add_argument("--json", type=Path)
    _add_protocol_args(g)

    cp = sub.add_parser("corpus", help="show / lint / seal a corpus dataset tree")
    cp.add_argument("action", choices=("show", "lint", "seal"))
    cp.add_argument("tree", type=Path)
    cp.add_argument("--snapshot-root", default="",
                    help="where the pinned dataset snapshot's blobs live, for the "
                         "lint checks that read media")
    cp.add_argument("--version", dest="new_version", type=int, default=None,
                    help="seal: the bumped version these rows are sealed at")

    c = sub.add_parser("compare", help="reference metrics (same-trajectory lane only)")
    c.add_argument("--reference", action="append", required=True)
    c.add_argument("--candidate", action="append", required=True)
    c.add_argument("--vmaf", action="store_true")
    c.add_argument("--lpips", action="store_true")
    c.add_argument("--json", type=Path)
    _add_protocol_args(c)

    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stderr)
    if argv is None:
        _reexec_with_threads(a.threads)
    resources.configure(a.threads, force=True)

    if a.cmd == "score":
        with _pool(a.workers) as ex:
            scores = dict(zip(a.paths, ex.map(score, a.paths), strict=True))
        out = {p: s.metrics() for p, s in scores.items()}
        for p, d in out.items():
            print(f"{p}\n  " + "  ".join(f"{k}={v:.5g}" for k, v in d.items()))
        if a.json:      # lossless: ClipScore.from_dict rebuilds these exactly
            a.json.write_text(json.dumps({p: s.to_dict() for p, s in scores.items()}, indent=1))
        return 0

    if a.cmd == "corpus":
        if a.action == "seal":
            try:
                sealed = corpus_mod.seal(a.tree, version=a.new_version)
            except DataError as exc:
                print(f"REFUSED: {exc}", file=sys.stderr)
                return 2
            print(f"sealed {sealed.corpus_id}@{sealed.version} {sealed.rows_digest}")
            return 0
        try:
            loaded = corpus_mod.load(a.tree)
        except DataError as exc:
            print(f"REFUSED: {exc}", file=sys.stderr)
            return 2
        print(corpus_mod.describe(loaded))
        if a.action == "show":
            for row in loaded.rows:
                print(f"  {row.kind:5s} {row.id:26s} {len(row.items)} items "
                      f"{'tags=' + ','.join(row.tags) if row.tags else ''}")
            return 0
        findings = corpus_mod.lint(loaded, snapshot_root=a.snapshot_root)
        for f in findings:
            print("  " + f.line())
        errors = [f for f in findings if f.level == "error"]
        print(f"  {len(findings)} findings, {len(errors)} error(s)")
        return 1 if errors else 0

    if a.cmd == "gate":
        if len(a.reference) != len(a.candidate):
            ap.error("--reference and --candidate must be given the same number of times")
        with _pool(a.workers) as ex:
            gate_scores = list(ex.map(score, a.reference + a.candidate))
        k = len(a.reference)
        proto = _protocol(a, k)
        report = run_population_gate(
            list(zip(gate_scores[:k], gate_scores[k:], strict=True)), proto)
        print(report.summary())
        if a.json:
            print("  digest " + contract.save(a.json, report, protocol=proto))
        return 0 if report.verdict == "pass" else 1

    proto = _protocol(a, len(a.reference))
    try:
        report = run_reference_gate(a.reference, a.candidate, proto,
                                    with_lpips=a.lpips, with_vmaf=a.vmaf)
    except TrajectoryPerturbingError as exc:
        print(f"REFUSED: {exc}", file=sys.stderr)
        return 2
    print(report.summary())
    if a.json:
        print("  digest " + contract.save(a.json, report, protocol=proto))
    return 0 if report.verdict == "pass" else 1


if __name__ == "__main__":                                    # pragma: no cover
    raise SystemExit(main())
