"""The WIRE judge: the four judge protocols, satisfied by an endpoint request.

STABILITY: experimental (v0.x).

:mod:`cozy_eval.judge` declares the judge protocols structurally, so eval-job code that
takes a ``Judge`` cannot tell a resident local VLM from a hosted one. This module is the
hosted half: :class:`WireJudge`, :class:`WireSoftJudge`, :class:`WireTranscriber` and
:class:`WireAudioJudge` implement those protocols by invoking the ``quality-judge``
endpoint (ev-003) as an ordinary request. Nothing else about a pass changes — the same
prompt builders build the prompts, the same tolerant parsers read the replies, and the
same report contract stamps the result.

**No network code lives here, and that is the design, not an omission.** cozy-eval is a
library, not a service (``scripts/fence.py``: no HTTP client, no gRPC, no hub client is
importable anywhere under ``src/``), so the wire client takes a :class:`Transport` —
anything with ``stage(bytes) -> ref`` and ``invoke(entrypoint, payload) -> dict``. A local
one-shot run of the endpoint, a hub client, and a stub are then the same object to this
module, and the base install stays numpy + msgspec with no extra to install.

**Media is STAGED, never inlined.** A request document is control: cozy-runtime's
supervisor/executor seam caps one frame at 64 KiB and exists to make "a caller trying to
move media through here" fail. So frames and audio go to ``transport.stage``, which
returns the opaque asset ref the endpoint's schema takes, and the request carries refs.
Where the bytes actually go — a local spool, an upload, a CAS — is the transport's
business and never this module's.

**Batching is why this is not just an HTTP wrapper.** The protocols are per-call by
construction (``ask`` answers one sample), while a resident 4.9 GiB judge wants one
request per sample BATCH. So every client here has a ``prefetch`` that sends the whole
workload as few requests as its transport allows and remembers the replies by content; the
protocol method then answers from that memory. A caller that does not prefetch still works
— it just pays one request per call.

A transport MAY declare ``max_payload_bytes``; a prefetch is then split into requests that
fit it. The number is the transport's, never this module's: cozy-runtime's local slice
publishes one because its supervisor/executor seam refuses a frame over 64 KiB, and a
hosted endpoint's limit will be something else entirely.

**A failed call is never an answer.** If the endpoint reports an error for a call, or the
transport fails, the protocol method raises :class:`~cozy_eval.errors.BackendError`. The
scoring lanes turn that into an item recorded ``unmeasured`` with the reason; they never
turn it into a "no". The one thing this module must never do is return a plausible value
for a call that did not happen.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterator
from typing import Any, Protocol, runtime_checkable

from .errors import BackendError, ConfigError

#: Entrypoint names on the ``quality-judge`` endpoint. They are the endpoint's contract,
#: so they live in one place here rather than being spelled at each call site.
JUDGE = "judge"
SOFT = "soft"
PAIRWISE = "pairwise"
TRANSCRIBE = "transcribe"

#: What an image is downscaled to before it goes on the wire. The judge's own vision tower
#: caps what it will look at anyway (401 408 px on the 8 GiB binding), so sending a full
#: 1344x768 render costs payload bytes for pixels the model never sees.
MAX_SIDE = 768
JPEG_QUALITY = 88


@runtime_checkable
class Transport(Protocol):
    """One endpoint invocation: a typed request in, the typed result out.

    Whatever satisfies this is a transport — a hub client, a local one-shot runtime slice,
    or a stub. It raises on a transport-level failure and returns the decoded result
    document otherwise; per-call failures ride INSIDE that document, because a batch of 64
    samples in which one image was undecodable is not a failed request.
    """

    #: Largest request document this transport will carry, or 0 for "no declared limit".
    max_payload_bytes: int

    def stage(self, data: bytes, media_type: str) -> str:
        """Put one blob where the endpoint can read it; return its opaque asset ref."""
        ...

    def invoke(self, entrypoint: str, payload: dict[str, Any]) -> dict[str, Any]: ...


def encode_image(image: Any, *, max_side: int = MAX_SIDE, quality: int = JPEG_QUALITY) -> bytes:
    """One image -> JPEG bytes, at the size the judge will actually look at."""
    import io

    from PIL import Image

    if not hasattr(image, "convert"):
        import numpy as np

        array = np.asarray(image)
        if array.dtype != np.uint8:
            array = np.clip(array * 255.0, 0, 255).astype(np.uint8)
        image = Image.fromarray(array)
    image = image.convert("RGB")
    longest = max(image.size)
    if max_side and longest > max_side:
        scale = max_side / longest
        image = image.resize(
            (max(1, round(image.width * scale)), max(1, round(image.height * scale))),
            Image.LANCZOS,
        )
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=quality)
    return buffer.getvalue()


def _key(*parts: str) -> str:
    """A content key over everything that decides an answer — the reply cache's identity."""
    digest = hashlib.sha256()
    for part in parts:
        digest.update(str(len(part)).encode())
        digest.update(part.encode())
    return digest.hexdigest()


class _WireClient:
    """Shared accounting and the reply cache. Every judge protocol needs both."""

    entrypoint = ""

    def __init__(
        self,
        transport: Transport,
        *,
        model_ref: str = "",
        max_side: int = MAX_SIDE,
        max_calls: int = 0,
    ):
        self.transport = transport
        self.model_ref = model_ref or "wire:quality-judge"
        self.max_side = max_side
        self.max_calls = max_calls
        """Calls per request, or 0 for "as many as the payload budget allows". The
        ENDPOINT's own admission bounds live in the endpoint, not here — a caller that
        knows them passes the number rather than making this module carry a copy that can
        drift from the schema it was copied from."""
        #: The report's cost fields read these (`cozy_eval.judge.ACCOUNTING_ATTRS`).
        self.load_seconds = 0.0
        """Always 0: the endpoint's residency is not this caller's load time."""
        self.infer_seconds = 0.0
        self.call_count = 0
        self.vram_bytes = 0
        """Always 0, and that is the honest number: a wire judge holds no VRAM in THIS
        process. What the judge costs resident is the platform's measurement, on the
        platform's side of the wire, and inventing it here would be a guess in a field a
        report reads as a measurement."""
        self.requests = 0
        self._replies: dict[str, tuple[Any, str]] = {}
        self._staged: dict[str, str] = {}

    def _refs(self, images: list[Any]) -> tuple[list[dict[str, str]], str]:
        """Stage every image once and return (refs, the content key they contribute).

        Staging is memoized on the JPEG's own digest, so the same frame shown in two
        comparisons is one blob and one upload — which is also why the reply cache can key
        on content and still be exact. Each ref is wrapped in the endpoint's one-asset
        frame struct, which is how an asset-bearing LIST is spelled in cozy-runtime.
        """
        refs: list[dict[str, str]] = []
        digests: list[str] = []
        for image in images:
            data = encode_image(image, max_side=self.max_side)
            digest = hashlib.sha256(data).hexdigest()
            digests.append(digest)
            ref = self._staged.get(digest)
            if ref is None:
                ref = self.transport.stage(data, "image/jpeg")
                self._staged[digest] = ref
            refs.append({"image": ref})
        return refs, "|".join(digests)

    def _batches(self, calls: list[dict[str, Any]]) -> Iterator[list[dict[str, Any]]]:
        """Split a workload into requests that fit what the transport says it carries."""
        budget = int(getattr(self.transport, "max_payload_bytes", 0) or 0)
        if budget <= 0 and self.max_calls <= 0:
            yield calls
            return
        batch: list[dict[str, Any]] = []
        size = 64  # the enclosing {"calls": [...], ...} document
        for call in calls:
            cost = len(json.dumps(call, separators=(",", ":"))) + 1
            full = self.max_calls > 0 and len(batch) >= self.max_calls
            over = budget > 0 and size + cost > budget
            if batch and (full or over):
                yield batch
                batch, size = [], 64
            batch.append(call)
            size += cost
        if batch:
            yield batch

    def _send(self, calls: list[dict[str, Any]], **extra: Any) -> list[dict[str, Any]]:
        if not calls:
            return []
        replies: list[dict[str, Any]] = []
        for batch in self._batches(calls):
            replies += self._send_one(batch, **extra)
        return replies

    def _send_one(self, calls: list[dict[str, Any]], **extra: Any) -> list[dict[str, Any]]:
        try:
            result = self.transport.invoke(self.entrypoint, {"calls": calls, **extra})
        except BackendError:
            raise
        except Exception as exc:
            raise BackendError(
                f"{self.entrypoint}: the judge endpoint could not be invoked — "
                f"{type(exc).__name__}: {exc}"
            ) from exc
        self.requests += 1
        self.infer_seconds += float(result.get("infer_seconds", 0.0) or 0.0)
        self.call_count += int(result.get("calls", 0) or 0)
        if result.get("model_ref"):
            self.model_ref = str(result["model_ref"])
        replies = result.get("replies")
        if not isinstance(replies, list):
            raise BackendError(
                f"{self.entrypoint}: the endpoint returned no replies list "
                f"(keys: {sorted(result)})"
            )
        return [dict(reply) for reply in replies]

    def _remember(self, keys: list[str], replies: list[dict[str, Any]], field: str) -> None:
        by_id = {str(reply.get("id", "")): reply for reply in replies}
        for key in keys:
            reply = by_id.get(key)
            if reply is None:
                self._replies[key] = (None, "the endpoint returned no reply for this call")
            else:
                self._replies[key] = (reply.get(field), str(reply.get("error", "")))

    def _answer(self, key: str) -> Any:
        value, error = self._replies[key]
        if error or value is None:
            raise BackendError(f"{self.entrypoint}: {error or 'no answer'}")
        return value

    def reset_accounting(self) -> None:
        self.infer_seconds = 0.0
        self.call_count = 0
        self.requests = 0


class WireJudge(_WireClient):
    """:class:`cozy_eval.judge.Judge` over the endpoint's ``judge`` entrypoint."""

    entrypoint = JUDGE

    def __init__(
        self,
        transport: Transport,
        *,
        model_ref: str = "",
        max_side: int = MAX_SIDE,
        max_calls: int = 0,
        max_new_tokens: int = 256,
    ):
        super().__init__(
            transport, model_ref=model_ref, max_side=max_side, max_calls=max_calls
        )
        self.max_new_tokens = max_new_tokens

    def _call(self, images: list[Any], prompt: str) -> tuple[str, dict[str, Any]]:
        refs, content = self._refs(images)
        key = _key(prompt, content)
        return key, {"id": key, "prompt": prompt, "images": refs}

    def prefetch(self, work: list[tuple[list[Any], str]]) -> None:
        """Send a whole workload as ONE request and remember every reply."""
        pairs = [self._call(images, prompt) for images, prompt in work]
        fresh = [call for key, call in pairs if key not in self._replies]
        replies = self._send(fresh, max_new_tokens=self.max_new_tokens)
        self._remember([call["id"] for call in fresh], replies, "text")

    def ask(self, images: list[Any], prompt: str) -> str:
        key, call = self._call(images, prompt)
        if key not in self._replies:
            self._remember([key], self._send([call], max_new_tokens=self.max_new_tokens), "text")
        return str(self._answer(key))


class WireSoftJudge(_WireClient):
    """:class:`cozy_eval.judge.SoftJudge` over the endpoint's ``soft`` entrypoint."""

    entrypoint = SOFT

    def _call(self, images: list[Any], question: str) -> tuple[str, dict[str, Any]]:
        refs, content = self._refs(images)
        key = _key(question, content)
        return key, {"id": key, "question": question, "images": refs}

    def prefetch(self, work: list[tuple[list[Any], str]]) -> None:
        pairs = [self._call(images, question) for images, question in work]
        fresh = [call for key, call in pairs if key not in self._replies]
        self._remember([c["id"] for c in fresh], self._send(fresh), "p_yes")

    def p_yes(self, images: list[Any], question: str) -> float:
        key, call = self._call(images, question)
        if key not in self._replies:
            self._remember([key], self._send([call]), "p_yes")
        value = float(self._answer(key))
        if not 0.0 <= value <= 1.0:
            raise BackendError(f"{SOFT}: p_yes={value} is not a probability")
        return value


class WireTranscriber(_WireClient):
    """:class:`cozy_eval.judge.Transcriber` over the endpoint's ``transcribe`` entrypoint."""

    entrypoint = TRANSCRIBE

    def __init__(
        self,
        transport: Transport,
        *,
        model_ref: str = "",
        language: str = "",
        max_calls: int = 0,
    ):
        super().__init__(transport, model_ref=model_ref, max_calls=max_calls)
        self.language = language

    def _call(self, samples: Any, sample_rate: int) -> tuple[str, dict[str, Any]]:
        import numpy as np

        array = np.asarray(samples, dtype=np.float32)
        if array.ndim == 2:  # (N, C) -> mono. The caller has the array; we have the model.
            array = array.mean(axis=1)
        elif array.ndim != 1:
            raise ConfigError(f"transcribe: expected (N,) or (N, C) audio, got {array.shape}")
        data = np.ascontiguousarray(array, dtype="<f4").tobytes()
        key = _key(str(sample_rate), self.language, hashlib.sha256(data).hexdigest())
        return key, {
            "id": key,
            "samples": self.transport.stage(data, "audio/x-f32le"),
            "sample_rate": int(sample_rate),
            "language": self.language,
        }

    def prefetch(self, work: list[tuple[Any, int]]) -> None:
        pairs = [self._call(samples, rate) for samples, rate in work]
        fresh = [call for key, call in pairs if key not in self._replies]
        self._remember([c["id"] for c in fresh], self._send(fresh), "text")

    def transcribe(self, samples: Any, sample_rate: int) -> str:
        key, call = self._call(samples, sample_rate)
        if key not in self._replies:
            self._remember([key], self._send([call]), "text")
        return str(self._answer(key))


class WireAudioJudge(_WireClient):
    """:class:`cozy_eval.judge.AudioJudge` — declared, and REFUSING on this deployment.

    The audio-event tier needs a model that answers questions about a SOUND, which
    transcription cannot do and which no licence-clean checkpoint small enough for the
    8 GiB verification card provides today (ev-003's execution record carries the search).
    A similarity model thresholded into a yes/no would produce a number with no calibration
    behind it, which is the one thing this library refuses to ship.

    So the protocol is implemented and it REFUSES, by design: every audio-event item lands
    in ``unmeasured`` with this reason. That is strictly more useful than no class at all —
    the eval job wires the same seam it will wire for a real audio judge, and the report
    says which tier was not measured and why.
    """

    entrypoint = "audio_events"
    reason = (
        "no audio-event judge is bound on this deployment: the tier needs a model that "
        "answers questions about a sound, and no licence-clean checkpoint that fits the "
        "verification card exists yet (ev-003)"
    )

    def ask(self, samples: Any, sample_rate: int, prompt: str) -> str:
        del samples, sample_rate, prompt
        raise BackendError(self.reason)


class WirePairwise(_WireClient):
    """Blinded pairwise comparison — NOT one of the five structural protocols.

    :func:`cozy_eval.detail.judge_detail_pairwise` drives a plain ``Judge`` with a
    concatenated strip, so the protocol side needs nothing new. What this class adds is the
    endpoint's position-bias control: the arms are shown in BOTH orders and both raw reads
    come back, so a caller can see whether the verdict survives the swap.
    """

    entrypoint = PAIRWISE

    def __init__(
        self,
        transport: Transport,
        *,
        model_ref: str = "",
        max_side: int = MAX_SIDE,
        max_calls: int = 0,
        max_new_tokens: int = 64,
    ):
        super().__init__(
            transport, model_ref=model_ref, max_side=max_side, max_calls=max_calls
        )
        self.max_new_tokens = max_new_tokens

    def compare(
        self, work: list[tuple[str, list[Any], list[Any], str]]
    ) -> dict[str, tuple[str, str]]:
        """``[(id, left, right, prompt)]`` -> ``{id: (forward read, swapped read)}``.

        Ids that failed are absent from the mapping, never present with an empty read.
        """
        calls = [
            {
                "id": ident,
                "prompt": prompt,
                "left": self._refs(left)[0],
                "right": self._refs(right)[0],
            }
            for ident, left, right, prompt in work
        ]
        replies = self._send(calls, max_new_tokens=self.max_new_tokens)
        return {
            str(reply["id"]): (str(reply.get("forward", "")), str(reply.get("swapped", "")))
            for reply in replies
            if not reply.get("error")
        }


__all__ = [
    "JPEG_QUALITY",
    "JUDGE",
    "MAX_SIDE",
    "PAIRWISE",
    "SOFT",
    "TRANSCRIBE",
    "Transport",
    "WireAudioJudge",
    "WireJudge",
    "WirePairwise",
    "WireSoftJudge",
    "WireTranscriber",
    "encode_image",
]
