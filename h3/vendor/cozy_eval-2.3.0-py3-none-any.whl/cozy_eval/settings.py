"""The ONE place cozy-eval reads the ambient environment.

Everything the library takes from the environment is a field here, read once
into an :class:`EvalSettings` at the entrypoints — :func:`cozy_eval.resources.
configure` (which runs as the package's first statement) and the CLI, where
``--threads`` is the user interface. Every other module asks :func:`active`;
none reads ``os.environ`` itself (``scripts/fence.py`` enforces it, with the
two documented propagation sites as the only exemptions).

``COZY_EVAL_THREADS`` is NOT a user interface: it is the internal parent->child
propagation channel (the CLI's execve re-exec, pool worker inheritance). Users
set ``--threads`` or call ``configure(threads=...)``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class EvalSettings(BaseSettings):
    """Env-sourced configuration, resolved once per process."""

    model_config = SettingsConfigDict(
        case_sensitive=True, env_ignore_empty=True, extra="ignore",
    )

    #: Compute-thread budget, from the internal propagation channel only.
    threads: int | None = Field(default=None, validation_alias="COZY_EVAL_THREADS")

    #: The ffmpeg VMAF shells out to; points a box whose system ffmpeg lacks
    #: libvmaf at a static build.
    vmaf_ffmpeg: Path = Field(default=Path("ffmpeg"), validation_alias="VMAF_FFMPEG")

    #: Where downloaded checkpoints land; point an offline pod at a pre-baked
    #: directory.
    cache_dir: Path = Field(
        default_factory=lambda: Path.home() / ".cache" / "cozy-eval",
        validation_alias="COZY_EVAL_CACHE",
    )

    @field_validator("threads", mode="before")
    @classmethod
    def _positive_or_none(cls, v: Any) -> Any:
        """The channel is written by our own parent process; ambient garbage
        must degrade to the default, never break ``import cozy_eval``."""
        try:
            n = int(str(v).strip())
        except (TypeError, ValueError):
            return None
        return n if n > 0 else None


_active: EvalSettings | None = None


def load(*, force: bool = False) -> EvalSettings:
    """Read the environment into the process-wide settings. First call wins."""
    global _active                      # noqa: PLW0603 — process-wide by nature
    if _active is None or force:
        _active = EvalSettings()
    return _active


def active() -> EvalSettings:
    """The settings in force, loading them on first ask."""
    return _active or load()


__all__ = ["EvalSettings", "active", "load"]
