"""A corpus: prompts and their authored checklists as ONE versioned unit.

STABILITY: locked core (v0.x) for the on-disk layout and the loader's refusals.

WHY ONE UNIT. v1 shipped prompts and checklists as two files cross-validated at
load (:func:`cozy_eval.promptset.checklists_for`). That catches drift, but only
because someone remembered to call the checking function; the two files can be
edited apart, shipped apart, and pinned apart. Here a row IS its checklist —
there is no representation of a prompt without its assertions — and the pair
carries one version. The frozen v1 sets stay in-package and load through this
same validator (:func:`packaged`), unchanged.

THE DATASET TREE. New corpora arrive from Cozy's corpus jobs (jobs.md §6
``generate-prompt-corpus`` / ``ingest-benchmark-corpus``) as pinned, materialized
snapshots, and the library only ever reads local files — it never fetches::

    <tree>/corpus.json     manifest: id, version, rows digest, seal history, blob digests
    <tree>/rows.jsonl      one row per line: the prompt AND its checklist items
    <tree>/blobs/...       referenced media: edit BEFORE images, rendered exemplars

AN UNVERSIONED EDIT IS REFUSED, at both ends. The manifest records the digest of
``rows.jsonl`` and the full seal history, so editing the rows without re-sealing
fails at LOAD (the bytes no longer match the version that was sealed) and
re-sealing without a version bump fails at SEAL. A score is only reproducible if
the thing scored can be named, and ``corpus_id@version`` is that name.

BLOBS ARE NOT REDISTRIBUTED. A corpus authored against billed renders records
each blob's sha256 and the path it came from inside the pinned snapshot;
:meth:`Corpus.blob` resolves it locally or, given ``snapshot_root``, out of the
snapshot, and VERIFIES the digest either way — so a substituted clip is refused
rather than silently scored. A tree whose blobs are not materialized still LOADS
and LINTS; only the checks that read media report themselves as skipped.
"""

from __future__ import annotations

import difflib
import json
import re
from pathlib import Path
from typing import Any

import msgspec

from .contract import exact_bytes_digest
from .errors import DataError
from .metrics.adherence import (
    KIND_AUDIO_EVENT,
    KIND_OCR,
    KIND_VQA,
    Checklist,
    ChecklistItem,
    ChecklistSet,
    EditChecklist,
    VideoChecklist,
)

MANIFEST = "corpus.json"
ROWS = "rows.jsonl"

KIND_T2I = "t2i"
KIND_EDIT = "edit"
KIND_T2V = "t2v"
KIND_AV = "av"
ROW_KINDS = (KIND_T2I, KIND_EDIT, KIND_T2V, KIND_AV)

#: Which item GROUPS each row kind admits, and which item kinds each group
#: admits. The duality per row kind is the shape v1 encoded as separate struct
#: fields; here it is per-item data, because a corpus row has one item list.
GROUPS: dict[str, dict[str, tuple[str, ...]]] = {
    KIND_T2I: {"": (KIND_OCR, KIND_VQA)},
    KIND_EDIT: {"change": (KIND_OCR, KIND_VQA), "preserve": (KIND_OCR, KIND_VQA)},
    KIND_T2V: {"motion": (KIND_OCR, KIND_VQA), "hold": (KIND_OCR, KIND_VQA)},
    KIND_AV: {"speech": (KIND_OCR,), "event": (KIND_AUDIO_EVENT,)},
}

#: A row tagged this way asserts that its prompt can carry an AV-sync gate.
SYNC_GATE_TAG = "sync-gate"

#: Words that name a discrete, struck, alignable event.
IMPULSIVE_WORDS = frozenset((
    "strike", "strikes", "struck", "hit", "hits", "hammer", "slam",
    "slams", "snap", "snaps", "clap", "claps", "knock", "knocks", "crack",
    "cracks", "smash", "smashes", "clash", "clashes", "thud", "thuds",
    "stomp", "stomps", "punch", "punches", "kick", "kicks", "crash",
    "crashes", "bang", "bangs", "shot", "gunshot", "beat", "beats", "drum",
    "drums", "click", "clicks", "tap", "taps", "footfall", "footfalls",
    "landing", "landings", "impact", "impacts"
))

#: ...and the words that read impulsive on paper and generate as texture. This
#: list is not a guess: every one of these was measured on a rendered exemplar
#: (see :data:`cozy_eval.metrics.avsync.IMPULSE_CREST_DB`). A steam burst and a
#: hail squall are loud and violent and have NO attack to align to.
TEXTURE_TRAP_WORDS = frozenset((
    "steam", "hiss", "hisses", "sizzle", "sizzling", "hail", "rain",
    "downpour", "wind", "gale", "roar", "roaring", "rumble", "rumbling",
    "static", "crackle", "crackling", "spray", "splash", "surf",
    "waterfall", "applause", "crowd", "murmur", "hum", "drone", "whoosh"
))

#: Two items in one row this similar are grading the same fact twice, which
#: silently doubles its weight.
OVERLAP_RATIO = 0.85

_WORD = re.compile(r"[a-z0-9']+")


class CorpusRow(msgspec.Struct, frozen=True, kw_only=True, forbid_unknown_fields=True):
    """One prompt and everything authored about it."""

    id: str
    kind: str
    seed: int = 0
    prompt: str = ""
    instruction: str = ""          # edit rows
    before_from: str = ""          # edit rows: the t2i row whose render is the BEFORE
    before_blob: str = ""          # edit rows: an external BEFORE image in blobs/
    exemplar: str = ""             # a rendered example, in blobs/ — what lint screens
    tags: tuple[str, ...] = ()
    items: tuple[ChecklistItem, ...] = ()

    def group(self, name: str) -> tuple[ChecklistItem, ...]:
        return tuple(i for i in self.items if i.group == name)


class Blob(msgspec.Struct, frozen=True, kw_only=True, forbid_unknown_fields=True):
    """One referenced media file: what it is, and where its bytes came from."""

    digest: str
    #: Path inside the pinned dataset snapshot the corpus was authored against.
    #: Empty for a blob that only ever lives in the tree.
    source: str = ""
    bytes: int = 0


class Manifest(msgspec.Struct, frozen=True, kw_only=True, forbid_unknown_fields=True):
    corpus_id: str
    version: int
    rows_digest: str
    rows: str = ROWS
    purpose: str = ""
    #: Every (version, digest) this corpus has been sealed at, oldest first.
    history: tuple[tuple[int, str], ...] = ()
    blobs: dict[str, Blob] = {}


class Finding(msgspec.Struct, frozen=True, kw_only=True):
    """One lint result. ``level`` is ``error`` (refuse) or ``warn``."""

    code: str
    level: str
    row: str
    message: str

    def line(self) -> str:
        return f"{self.level.upper():5s} {self.code:26s} {self.row or '-':22s} {self.message}"


class Corpus(msgspec.Struct, frozen=True, kw_only=True):
    """A loaded corpus. ``root`` is empty for the in-package frozen sets."""

    corpus_id: str
    version: int
    rows: tuple[CorpusRow, ...]
    rows_digest: str
    purpose: str = ""
    history: tuple[tuple[int, str], ...] = ()
    blobs: dict[str, Blob] = {}
    root: str = ""
    #: The rows exactly as written, for lint rules that must see what the AUTHOR
    #: typed rather than what the decoder defaulted (a missing weight is not the
    #: same authoring act as an explicit 1.0).
    raw: tuple[dict[str, Any], ...] = ()

    @property
    def name(self) -> str:
        return f"{self.corpus_id}@{self.version}"

    def by_kind(self, kind: str) -> tuple[CorpusRow, ...]:
        return tuple(r for r in self.rows if r.kind == kind)

    def blob(self, name: str, *, snapshot_root: str | Path = "") -> Path:
        """The digest-VERIFIED path of one blob, or a typed refusal.

        Looks in the tree first, then — for a blob the corpus declares a
        ``source`` for — inside ``snapshot_root``. Either way the bytes are
        hashed before the path is returned: a corpus that cannot prove which
        clip it measured is a corpus whose numbers name nothing.
        """
        if name not in self.blobs:
            raise DataError(f"{self.name}: blob {name!r} is not declared in the manifest")
        blob = self.blobs[name]
        candidates = [Path(self.root) / name] if self.root else []
        if blob.source and snapshot_root:
            candidates.append(Path(snapshot_root).expanduser() / blob.source)
        for path in candidates:
            if not path.exists():
                continue
            actual = exact_bytes_digest(path.read_bytes())
            if actual != blob.digest:
                raise DataError(
                    f"{self.name}: blob {name!r} at {path} is {actual}, the manifest "
                    f"sealed {blob.digest}. These are different bytes, so any number "
                    "measured on them belongs to a different corpus.")
            return path
        raise DataError(
            f"{self.name}: blob {name!r} is declared but not materialized "
            f"(looked in {[str(c) for c in candidates] or 'nowhere: no root'}). "
            "Corpus blobs are billed renders and are not redistributed with the "
            f"corpus; pass snapshot_root= pointing at {blob.source or 'the snapshot'}.")

    def audio_checklists(self) -> dict[str, Any]:
        """``{row id: AudioChecklist}`` for the ``av`` rows — what ``run_audio`` takes."""
        from .audio import AudioChecklist

        return {r.id: AudioChecklist(prompt_id=r.id, speech=r.group("speech"),
                                     events=r.group("event"))
                for r in self.by_kind(KIND_AV)}

    def checklist_set(self) -> ChecklistSet:
        """The v1 :class:`ChecklistSet` view, so every existing scorer just works."""
        t2i = {r.id: Checklist(prompt_id=r.id, items=r.items)
               for r in self.by_kind(KIND_T2I)}
        edit = {r.id: EditChecklist(
            edit_id=r.id, before_from=r.before_from, instruction=r.instruction,
            change=r.group("change"), preserve=r.group("preserve"))
            for r in self.by_kind(KIND_EDIT)}
        t2v = {r.id: VideoChecklist(
            prompt_id=r.id, motion=r.group("motion"), hold=r.group("hold"))
            for r in self.by_kind(KIND_T2V)}
        return ChecklistSet(
            checklist_set_id=self.corpus_id, version=self.version,
            prompt_set=self.corpus_id, prompt_set_version=self.version,
            t2i=t2i, edit=edit, t2v=t2v,
        )


# ---------------------------------------------------------------------------
# load / seal
# ---------------------------------------------------------------------------

def _rows_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as exc:
        raise DataError(f"{path}: cannot be read: {exc}") from exc


def _decode_rows(
    data: bytes, where: str,
) -> tuple[tuple[CorpusRow, ...], tuple[dict[str, Any], ...]]:
    rows: list[CorpusRow] = []
    raw: list[dict[str, Any]] = []
    for n, line in enumerate(data.decode("utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            plain = json.loads(line)
            rows.append(msgspec.convert(plain, CorpusRow, strict=False))
        except (json.JSONDecodeError, msgspec.ValidationError) as exc:
            raise DataError(f"{where}:{n}: not a corpus row: {exc}") from exc
        raw.append(plain)
    return tuple(rows), tuple(raw)


def validate(rows: tuple[CorpusRow, ...], where: str) -> None:
    """Structural rules a corpus cannot be loaded in violation of."""
    if not rows:
        raise DataError(f"{where}: corpus has no rows")
    seen_rows: set[str] = set()
    seen_items: set[str] = set()
    for row in rows:
        if row.id in seen_rows:
            raise DataError(f"{where}: duplicate row id {row.id!r}")
        seen_rows.add(row.id)
        if row.kind not in ROW_KINDS:
            raise DataError(
                f"{where}: row {row.id!r} has unknown kind {row.kind!r}; "
                f"known: {list(ROW_KINDS)}")
        groups = GROUPS[row.kind]
        if not row.items:
            raise DataError(
                f"{where}: row {row.id!r} has no checklist items. A prompt with no "
                "assertions is not a corpus row — it is a string, and it scores "
                "nothing.")
        for item in row.items:
            if item.group not in groups:
                raise DataError(
                    f"{where}: row {row.id!r} item {item.id!r} is in group "
                    f"{item.group!r}, which a {row.kind!r} row has no place for; "
                    f"known: {sorted(groups)}")
            if item.kind not in groups[item.group]:
                raise DataError(
                    f"{where}: row {row.id!r} item {item.id!r} is kind {item.kind!r} "
                    f"in group {item.group!r}, which takes {list(groups[item.group])}")
            if item.weight <= 0.0:
                raise DataError(
                    f"{where}: row {row.id!r} item {item.id!r} has weight "
                    f"{item.weight}; weights must be > 0")
            if item.kind == KIND_OCR and not item.text.strip():
                raise DataError(f"{where}: ocr item {item.id!r} has no 'text'")
            if item.kind in (KIND_VQA, KIND_AUDIO_EVENT) and not item.question.strip():
                raise DataError(f"{where}: {item.kind} item {item.id!r} has no 'question'")
            if item.id in seen_items:
                raise DataError(
                    f"{where}: duplicate item id {item.id!r} — a report names failed "
                    "items by id, so ids are unique across the whole corpus")
            seen_items.add(item.id)
        for kind, need in ((KIND_EDIT, ("change", "preserve")), (KIND_T2V, ("motion", "hold"))):
            if row.kind == kind:
                for g in need:
                    if not row.group(g):
                        raise DataError(
                            f"{where}: {kind} row {row.id!r} has no {g!r} items. The "
                            "duality is the point: an arm can fail either way and one "
                            "half alone cannot tell you which.")
        if row.kind == KIND_EDIT:
            if bool(row.before_from) == bool(row.before_blob):
                raise DataError(
                    f"{where}: edit row {row.id!r} must name exactly one BEFORE — "
                    "before_from (a t2i row in this corpus) or before_blob (an "
                    "external image)")
            if row.before_from and row.before_from not in seen_rows | {r.id for r in rows}:
                raise DataError(
                    f"{where}: edit row {row.id!r} before_from={row.before_from!r} "
                    "names no row in this corpus")


def load(tree: str | Path) -> Corpus:
    """Load and validate a corpus dataset tree, or refuse."""
    root = Path(tree)
    manifest_path = root / MANIFEST
    try:
        manifest = msgspec.json.decode(manifest_path.read_bytes(), type=Manifest)
    except OSError as exc:
        raise DataError(f"{manifest_path}: cannot be read: {exc}") from exc
    except msgspec.ValidationError as exc:
        raise DataError(f"{manifest_path}: not a corpus manifest: {exc}") from exc

    data = _rows_bytes(root / manifest.rows)
    actual = exact_bytes_digest(data)
    if actual != manifest.rows_digest:
        raise DataError(
            f"{root}: {manifest.rows} is {actual} but {manifest.corpus_id}@"
            f"{manifest.version} was sealed at {manifest.rows_digest}. The rows were "
            "edited without re-sealing, so this corpus no longer has a version that "
            "names its contents. Bump the version and run `cozy-eval corpus seal`."
        )
    _check_history(manifest, root)
    rows, raw = _decode_rows(data, str(root / manifest.rows))
    validate(rows, f"{manifest.corpus_id}@{manifest.version}")
    return Corpus(
        corpus_id=manifest.corpus_id, version=manifest.version, rows=rows,
        rows_digest=manifest.rows_digest, purpose=manifest.purpose,
        history=manifest.history, blobs=manifest.blobs, root=str(root), raw=raw,
    )


def _check_history(manifest: Manifest, root: Path) -> None:
    if not manifest.history:
        return
    versions = [v for v, _ in manifest.history]
    if versions != sorted(set(versions)):
        raise DataError(
            f"{root}: seal history {versions} is not strictly increasing — one "
            "version was sealed twice, so a corpus_id@version names two different "
            "sets of rows and no score taken under it is reproducible.")
    last_version, last_digest = manifest.history[-1]
    if (last_version, last_digest) != (manifest.version, manifest.rows_digest):
        raise DataError(
            f"{root}: the manifest is at {manifest.corpus_id}@{manifest.version} "
            f"({manifest.rows_digest}) but the last seal was @{last_version} "
            f"({last_digest}). The manifest was hand-edited; re-seal it.")


def seal(tree: str | Path, *, version: int | None = None) -> Manifest:
    """Record the current rows under a version, refusing an unbumped edit."""
    root = Path(tree)
    manifest = msgspec.json.decode((root / MANIFEST).read_bytes(), type=Manifest)
    data = _rows_bytes(root / manifest.rows)
    actual = exact_bytes_digest(data)
    rows, _ = _decode_rows(data, str(root / manifest.rows))
    validate(rows, f"{manifest.corpus_id}@{version or manifest.version}")

    if actual == manifest.rows_digest and version in (None, manifest.version):
        return manifest                                  # nothing moved
    if version is None or version <= manifest.version:
        raise DataError(
            f"{root}: {manifest.rows} changed ({manifest.rows_digest} -> {actual}) "
            f"but the version is still {manifest.version}. A checklist edit that "
            "keeps its version makes two incomparable runs claim the same name. "
            f"Re-seal with version={manifest.version + 1}.")
    sealed = msgspec.structs.replace(
        manifest, version=version, rows_digest=actual,
        history=(*manifest.history, (version, actual)))
    (root / MANIFEST).write_text(
        json.dumps(msgspec.to_builtins(sealed), indent=1, sort_keys=True) + "\n")
    return sealed


def write(tree: str | Path, *, corpus_id: str, version: int, rows: list[CorpusRow],
          purpose: str = "", blobs: dict[str, Blob] | None = None) -> Manifest:
    """Author a corpus: write rows.jsonl + a sealed manifest. Validates first."""
    root = Path(tree)
    root.mkdir(parents=True, exist_ok=True)
    validate(tuple(rows), f"{corpus_id}@{version}")
    body = "".join(
        json.dumps(msgspec.to_builtins(r), sort_keys=True) + "\n" for r in rows
    ).encode("utf-8")
    (root / ROWS).write_bytes(body)
    digest = exact_bytes_digest(body)
    manifest = Manifest(
        corpus_id=corpus_id, version=version, rows_digest=digest, purpose=purpose,
        history=((version, digest),), blobs=blobs or {})
    (root / MANIFEST).write_text(
        json.dumps(msgspec.to_builtins(manifest), indent=1, sort_keys=True) + "\n")
    return manifest


# ---------------------------------------------------------------------------
# authoring lint
# ---------------------------------------------------------------------------

def _text_of(item: ChecklistItem) -> str:
    return " ".join(_WORD.findall((item.text or item.question).lower()))


def _words(row: CorpusRow) -> set[str]:
    return set(_WORD.findall(f"{row.prompt} {row.instruction}".lower()))


def lint(corpus: Corpus, *, snapshot_root: str | Path = "") -> tuple[Finding, ...]:
    """Authoring rules that a corpus can technically satisfy and still be wrong."""
    out: list[Finding] = []
    raw_by_id = {r.get("id"): r for r in corpus.raw}

    for row in corpus.rows:
        # 1. two items grading the same fact — the weight silently doubles
        texts = [(i.id, _text_of(i), i.group) for i in row.items]
        for a in range(len(texts)):
            for b in range(a + 1, len(texts)):
                if texts[a][2] != texts[b][2]:
                    continue
                ratio = difflib.SequenceMatcher(None, texts[a][1], texts[b][1]).ratio()
                if ratio >= OVERLAP_RATIO:
                    out.append(Finding(
                        code="overlapping-items", level="error", row=row.id,
                        message=(f"items {texts[a][0]!r} and {texts[b][0]!r} are "
                                 f"{ratio:.0%} the same assertion; one fact graded "
                                 "twice carries twice the weight")))

        # 2. mixed explicit and defaulted weights
        raw_items = (raw_by_id.get(row.id) or {}).get("items") or []
        declared = [("weight" in i) for i in raw_items]
        if raw_items and any(declared) and not all(declared):
            out.append(Finding(
                code="mixed-weights", level="error", row=row.id,
                message=(f"{sum(declared)} of {len(declared)} items declare a weight; "
                         "the rest default to 1.0, which is usually the LARGEST weight "
                         "in the row. Declare all or none.")))

        # 3. the AV-sync authoring rule, executable
        if SYNC_GATE_TAG in row.tags:
            out.extend(_lint_sync_gate(corpus, row, snapshot_root=snapshot_root))

    return tuple(out)


def _lint_sync_gate(corpus: Corpus, row: CorpusRow,
                    *, snapshot_root: str | Path) -> list[Finding]:
    out: list[Finding] = []
    words = _words(row)
    impulsive = words & IMPULSIVE_WORDS
    texture = words & TEXTURE_TRAP_WORDS
    if not impulsive:
        out.append(Finding(
            code="sync-gate-no-impulsive-event", level="error", row=row.id,
            message=("a sync-gated prompt must NAME an impulsive event (struck, hit, "
                     "slammed, snapped). AV-sync is measured by correlating onset "
                     "envelopes; content with no attack has nothing to align and "
                     "returns UNMEASURED, which is not a gate."
                     + (f" This prompt names only sustained sources: {sorted(texture)}."
                        if texture else ""))))
    elif texture:
        out.append(Finding(
            code="sync-gate-texture-source", level="warn", row=row.id,
            message=(f"names both an impulsive event {sorted(impulsive)} and a "
                     f"sustained source {sorted(texture)}; the generator may render "
                     "the texture and drop the attack. Screen the exemplar.")))

    if not row.exemplar:
        out.append(Finding(
            code="sync-gate-no-exemplar", level="warn", row=row.id,
            message=("no rendered exemplar to screen. The prompt's wording is not "
                     "evidence: a steam burst and a hail squall read percussive on "
                     "paper and both generated as untrackable texture.")))
        return out
    try:
        path = corpus.blob(row.exemplar, snapshot_root=snapshot_root)
    except DataError as exc:
        out.append(Finding(code="sync-gate-exemplar-unavailable", level="warn",
                           row=row.id, message=str(exc)))
        return out

    from .audio import read_audio  # ffmpeg, not a base-install dep
    from .metrics.avsync import impulsiveness

    screen = impulsiveness(read_audio(path))
    level = "error" if not screen.impulsive else "warn"
    message = (f"exemplar crest {screen.crest_db:.1f} dB, {screen.onsets} prominent "
               f"onsets")
    if not screen.impulsive:
        out.append(Finding(code="sync-gate-exemplar-not-impulsive", level=level,
                           row=row.id, message=f"{message}: {screen.note}"))
    return out


# ---------------------------------------------------------------------------
# the frozen in-package sets, through the same validator
# ---------------------------------------------------------------------------

def packaged(name: str) -> Corpus:
    """Build a :class:`Corpus` from a frozen in-package prompt set + checklists.

    The v1 files are NOT rewritten — they are read as they were frozen and put
    through this module's validator, which is the only claim that matters: the
    shipped sets satisfy the rules a new corpus is held to.
    """
    from . import promptset

    ps = promptset.load(name)
    cs = promptset.checklists_for(name)
    rows: list[CorpusRow] = []
    for prompt in ps.t2i:
        rows.append(CorpusRow(
            id=prompt.id, kind=KIND_T2I, seed=prompt.seed, prompt=prompt.prompt,
            tags=prompt.tags, items=cs.t2i[prompt.id].items))
    for prompt in ps.t2v:
        cl = cs.t2v[prompt.id]
        rows.append(CorpusRow(
            id=prompt.id, kind=KIND_T2V, seed=prompt.seed, prompt=prompt.prompt,
            tags=prompt.tags,
            items=tuple(msgspec.structs.replace(i, group="motion") for i in cl.motion)
            + tuple(msgspec.structs.replace(i, group="hold") for i in cl.hold)))
    for case in ps.edit:
        ecl = cs.edit[case.id]
        rows.append(CorpusRow(
            id=case.id, kind=KIND_EDIT, seed=case.seed, instruction=case.instruction,
            before_from=case.before_from, tags=case.tags,
            items=tuple(msgspec.structs.replace(i, group="change") for i in ecl.change)
            + tuple(msgspec.structs.replace(i, group="preserve") for i in ecl.preserve)))
    validate(tuple(rows), f"{ps.set_id}@{ps.version} (in-package)")
    body = "".join(json.dumps(msgspec.to_builtins(r), sort_keys=True) + "\n"
                   for r in rows).encode("utf-8")
    return Corpus(
        corpus_id=ps.set_id, version=ps.version, rows=tuple(rows),
        rows_digest=exact_bytes_digest(body), purpose=ps.purpose,
        raw=tuple(msgspec.to_builtins(r) for r in rows),
    )


def describe(corpus: Corpus) -> str:
    counts = {k: len(corpus.by_kind(k)) for k in ROW_KINDS}
    items = sum(len(r.items) for r in corpus.rows)
    return (f"{corpus.name}  {len(corpus.rows)} rows / {items} items  "
            + " ".join(f"{k}={v}" for k, v in counts.items() if v)
            + f"  rows_digest {corpus.rows_digest}")


__all__ = [
    "GROUPS",
    "IMPULSIVE_WORDS",
    "MANIFEST",
    "OVERLAP_RATIO",
    "ROWS",
    "ROW_KINDS",
    "SYNC_GATE_TAG",
    "TEXTURE_TRAP_WORDS",
    "Blob",
    "ChecklistItem",
    "Corpus",
    "CorpusRow",
    "Finding",
    "Manifest",
    "describe",
    "lint",
    "load",
    "packaged",
    "seal",
    "validate",
    "write",
]
