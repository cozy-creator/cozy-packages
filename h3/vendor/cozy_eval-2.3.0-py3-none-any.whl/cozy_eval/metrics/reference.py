"""Reference metrics for the same-trajectory lane.

Composed, not reimplemented, wherever a maintained implementation exists:

* **VMAF** via ``ffmpeg_quality_metrics`` (MIT, actively maintained) when it is
  installed, falling back to a direct ``ffmpeg -lavfi libvmaf`` call. Netflix's
  model is the right instrument for post-decode changes and there is no reason to
  have an opinion of our own about it.
* **ColorVideoVDP** via ``cvvdp`` (MIT) when installed — a colour- and HDR-aware
  spatiotemporal full-reference video metric, strictly a better instrument than
  VMAF for this lane. Optional because it is heavier.
* **LPIPS** via the ``lpips`` package when installed.
* **PSNR / SSIM / MS-SSIM** are computed HERE, in numpy, and nowhere else — see
  below.

ONE IMPLEMENTATION PER NAME (@10). v1 shipped ``psnr`` twice — this module's
numpy version on a ``[0, 1]`` scale, and ``metrics/similarity.py``'s
torchmetrics version on a ``0..255`` scale — and ``ssim`` three times: skimage's
when scikit-image happened to be installed, a built-in 8x8 block SSIM when it
did not, and torchmetrics' gaussian SSIM from the other module. Measured on one
textured scene pair: ``psnr`` read 28.02 dB as floats and **-17.88 dB** on the
same content as uint8 (the difference wrapped), and ``ssim`` read 0.9207 with
skimage present against 0.8993 without it.

That is the clean-fid incident happening inside our own package: a metric NAME
that does not identify a number, and an environment silently choosing which
quantity you get. §2.2's answer is ``(name, impl)``, and it is worthless if the
impl cannot be read off the code. So PSNR, SSIM and MS-SSIM are now one numpy
implementation each, at ``impl`` 2.0, scale-normalized on entry so uint8 and
float inputs give the same number, with no optional dependency able to change
the math. They are what the registry always claimed they were: cheap,
deterministic, and runnable with nothing installed but numpy.

Nothing in this module may be called without passing the
:func:`~cozy_eval.protocol.require_reference_lane` guard first; the gate
does that for you.
"""

from __future__ import annotations

import functools
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import numpy as np

from ..frames import LUMA, iter_frames

#: Identical inputs give infinite PSNR; report a finite sentinel instead.
PSNR_CAP = 99.0
#: Wang et al. 2003, table 1 — the published MS-SSIM scale weights.
MS_WEIGHTS = (0.0448, 0.2856, 0.3001, 0.2363, 0.1333)


def as_unit_rgb(x: np.ndarray) -> np.ndarray:
    """RGB in float64 ``[0, 1]``, whatever scale it arrived on.

    The entry point that stops one metric name meaning two numbers. uint8 in
    particular is not merely a scale difference: ``(a - b) ** 2`` on uint8 WRAPS,
    so an unnormalized read is not just off by 20*log10(255), it is nonsense.
    """
    arr = np.asarray(x.convert("RGB") if hasattr(x, "convert") else x)
    out = arr.astype(np.float64)
    if arr.dtype == np.uint8 or out.max(initial=0.0) > 1.5:
        out = out / 255.0
    return out


def _pair(a: np.ndarray, b: np.ndarray, *, metric: str) -> tuple[np.ndarray, np.ndarray]:
    x, y = as_unit_rgb(a), as_unit_rgb(b)
    if x.shape != y.shape:
        from ..errors import ConfigError

        raise ConfigError(
            f"{metric}: the two images differ in shape, {x.shape} vs {y.shape} — a "
            "paired metric needs identically sized images; resize the candidate to "
            "the reference first"
        )
    return x, y


def psnr(a: np.ndarray, b: np.ndarray) -> float:
    """PSNR in dB. impl 2.0: scale-normalized, so uint8 and float agree."""
    x, y = _pair(a, b, metric="psnr")
    mse = float(np.mean((x - y) ** 2))
    return PSNR_CAP if mse < 1e-12 else min(PSNR_CAP, float(-10.0 * np.log10(mse)))


def _gaussian_window(size: int = 11, sigma: float = 1.5) -> np.ndarray:
    """The 1-D half of the separable 11x11 sigma-1.5 window (Wang 2004)."""
    coords = np.arange(size, dtype=np.float64) - (size - 1) / 2.0
    g = np.exp(-(coords ** 2) / (2.0 * sigma ** 2))
    return np.asarray(g / g.sum())


def _filter2(image: np.ndarray, g: np.ndarray) -> np.ndarray:
    """Valid-mode 2-D gaussian correlation, separable, numpy only.

    The window is separable, so this is two 1-D passes of k shifted adds rather
    than a full 2-D convolution over a materialized sliding-window view — which
    is why SSIM stays a milliseconds-per-frame metric with no scipy, no torch
    and no OpenCV behind it.
    """
    k = g.shape[0]
    h, w = image.shape
    acc = np.zeros((h - k + 1, w), dtype=np.float64)
    for i in range(k):
        acc += g[i] * image[i:i + h - k + 1, :]
    out = np.zeros((h - k + 1, w - k + 1), dtype=np.float64)
    for j in range(k):
        out += g[j] * acc[:, j:j + w - k + 1]
    return out


def _ssim_map(x: np.ndarray, y: np.ndarray, *, window: int = 11,
              sigma: float = 1.5) -> tuple[np.ndarray, np.ndarray]:
    """Wang 2004 SSIM over luma, gaussian-windowed. Returns (ssim map, cs map)."""
    win = _gaussian_window(window, sigma)
    lx, ly = x @ LUMA.astype(np.float64), y @ LUMA.astype(np.float64)
    c1, c2 = 0.01 ** 2, 0.03 ** 2
    mx, my = _filter2(lx, win), _filter2(ly, win)
    mxx, myy = mx * mx, my * my
    mxy = mx * my
    vx = _filter2(lx * lx, win) - mxx
    vy = _filter2(ly * ly, win) - myy
    vxy = _filter2(lx * ly, win) - mxy
    cs = (2 * vxy + c2) / (vx + vy + c2)
    s = ((2 * mxy + c1) / (mxx + myy + c1)) * cs
    return s, cs


def ssim(a: np.ndarray, b: np.ndarray) -> float:
    """Mean SSIM (Wang 2004), gaussian 11x11 window, sigma 1.5. impl 2.0.

    IMAGE ONLY — the registry declares modality ``image`` and the video runner
    has no path here. Pooled over frames, a windowed structural similarity
    rewards over-smoothing, which is the failure the suite exists to catch.
    """
    x, y = _pair(a, b, metric="ssim")
    if min(x.shape[:2]) < 11:
        from ..errors import ConfigError

        raise ConfigError(
            f"ssim: image is {x.shape[:2]}, smaller than the 11px gaussian window "
            "this metric convolves with"
        )
    s, _ = _ssim_map(x, y)
    return float(s.mean())


def _downsample(img: np.ndarray) -> np.ndarray:
    """2x2 box decimation, the standard MS-SSIM pyramid step."""
    h, w = img.shape[0] - img.shape[0] % 2, img.shape[1] - img.shape[1] % 2
    a = img[:h, :w]
    return np.asarray(
        (a[0::2, 0::2] + a[1::2, 0::2] + a[0::2, 1::2] + a[1::2, 1::2]) / 4.0)


def ms_ssim(a: np.ndarray, b: np.ndarray) -> float:
    """Multi-scale SSIM (Wang 2003). impl 2.0, numpy only, IMAGE ONLY.

    The scale count drops and the weights renormalize on an image too small for
    all five, so a small evaluation returns a real number rather than raising.
    """
    x, y = _pair(a, b, metric="ms_ssim")
    scales: list[float] = []
    weights: list[float] = []
    for level, weight in enumerate(MS_WEIGHTS):
        if min(x.shape[:2]) < 11:
            break
        s, cs = _ssim_map(x, y)
        scales.append(float(s.mean()) if level == len(MS_WEIGHTS) - 1 else float(cs.mean()))
        weights.append(weight)
        if level < len(MS_WEIGHTS) - 1:
            x, y = _downsample(x), _downsample(y)
    if not scales:
        from ..errors import ConfigError

        raise ConfigError("ms_ssim: image is smaller than the 11px SSIM window")
    total = sum(weights)
    value = 1.0
    for scale, weight in zip(scales, weights, strict=True):
        value *= max(scale, 1e-12) ** (weight / total)
    return float(value)


@functools.cache
def have_vmaf() -> bool:
    """Is the configured ffmpeg built with libvmaf?"""
    ffmpeg = _ffmpeg_bin()
    if not shutil.which(ffmpeg):
        return False
    out = subprocess.run([ffmpeg, "-hide_banner", "-filters"],
                         capture_output=True, text=True, check=False).stdout
    return " libvmaf " in out


def _harmonic_mean(vals: list[float]) -> float:
    """Harmonic mean of per-frame VMAF, the pooling Netflix recommends: it
    weights the worst frames far more than the arithmetic mean, so a clip that
    is excellent for 90% and falls apart for 10% does not read as ~90."""
    finite = [v for v in vals if v is not None and v > 0]
    if not finite:
        return 0.0
    return float(len(finite) / np.sum([1.0 / v for v in finite]))


def _ffmpeg_bin() -> str:
    """The ffmpeg to shell out to. The ``vmaf_ffmpeg`` setting (env
    ``VMAF_FFMPEG``) overrides so a box whose system ffmpeg lacks libvmaf can
    point at a static build."""
    from ..settings import active

    return str(active().vmaf_ffmpeg)


def _probe_video(path: str | Path) -> tuple[int, int, str]:
    """``(width, height, fps_expr)`` of a clip's first video stream, via ffprobe."""
    import os

    ffmpeg = _ffmpeg_bin()
    d, base = os.path.split(ffmpeg)
    ffprobe = os.path.join(d, base.replace("ffmpeg", "ffprobe")) if d else "ffprobe"
    out = subprocess.run(
        [ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
         "stream=width,height,r_frame_rate", "-of", "csv=p=0", str(path)],
        check=True, capture_output=True, text=True,
    ).stdout.strip()
    w, h, fps = out.split(",")[:3]
    return int(w), int(h), fps


def vmaf(reference: str | Path, candidate: str | Path) -> dict[str, float]:
    """Netflix VMAF, candidate vs reference, harmonic-mean pooled.

    Resolution and framerate are ALIGNED before scoring: VMAF is a full-reference
    metric defined at one geometry and clock, so the candidate is scaled to the
    reference's resolution and resampled to its framerate in the filter graph.
    An unaligned pair otherwise scores a real fidelity loss where there was only
    a preset difference. Returns ``vmaf`` (harmonic mean — THE number),
    ``vmaf_mean`` (arithmetic, for continuity with historical rows) and
    ``vmaf_min`` (the worst frame, the tail).
    """
    from ..resources import active, ffmpeg_thread_args

    ffmpeg = _ffmpeg_bin()
    rw, rh, rfps = _probe_video(reference)
    # [candidate] scaled+fps-matched to the reference, then [that][reference]libvmaf.
    # libvmaf runs its own pool (n_threads) on top of ffmpeg's decode/filter
    # threads, so ALL THREE get the budget or VMAF alone eats the box.
    align = f"scale={rw}:{rh}:flags=bicubic,fps={rfps},setsar=1"
    n = active().threads
    with tempfile.NamedTemporaryFile("r", suffix=".json") as out:
        graph = (
            f"[0:v]{align}[cand];"
            f"[1:v]setsar=1[ref];"
            f"[cand][ref]libvmaf=n_threads={n}:log_fmt=json:log_path={out.name}"
        )
        proc = subprocess.run(
            [ffmpeg, "-v", "error", *ffmpeg_thread_args(),
             "-filter_threads", str(n), "-filter_complex_threads", str(n),
             "-i", str(candidate), "-i", str(reference),
             "-lavfi", graph, "-f", "null", "-"],
            check=False, capture_output=True, text=True,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                "libvmaf ffmpeg call failed; install an ffmpeg built with "
                "--enable-libvmaf or set VMAF_FFMPEG to one. stderr:\n"
                + (proc.stderr or "")[-800:]
            )
        data = json.loads(Path(out.name).read_text())
    pooled = data["pooled_metrics"]["vmaf"]
    per_frame = [f["metrics"]["vmaf"] for f in data.get("frames", [])]
    hmean = _harmonic_mean(per_frame) if per_frame else float(pooled.get("harmonic_mean", pooled["mean"]))
    return {
        "vmaf": hmean,
        "vmaf_mean": float(pooled["mean"]),
        "vmaf_min": float(pooled["min"]),
    }


@functools.cache
def _lpips_model() -> Any:
    import lpips as _l
    return _l.LPIPS(net="alex")


def lpips_pair(a: np.ndarray, b: np.ndarray) -> float:
    """Per-frame LPIPS via the ``lpips`` package (optional dependency)."""
    import torch
    model = _lpips_model()
    def t(x: np.ndarray) -> Any:
        return torch.from_numpy(x.transpose(2, 0, 1)[None] * 2.0 - 1.0).float()
    with torch.no_grad():
        return float(model(t(a), t(b)).item())


def cvvdp(reference: str | Path, candidate: str | Path,
          display: str = "standard_4k") -> dict[str, float]:
    """ColorVideoVDP (JOD units, higher is better). Needs ``[reference]`` extra."""
    try:
        import pycvvdp
    except ImportError as exc:                                 # pragma: no cover
        raise RuntimeError(
            "cvvdp not installed: pip install 'cozy-eval[reference]'"
        ) from exc
    metric = pycvvdp.cvvdp(display_name=display)
    jod, _ = metric.predict(str(candidate), str(reference), dim_order="FHWC")
    return {"cvvdp_jod": float(jod)}


def compare(reference: Any, candidate: Any, *, with_lpips: bool = False) -> dict[str, float]:
    """Per-frame reference metrics between two frame sources of the same take."""
    ps: list[float] = []
    lp: list[float] = []
    n = 0
    for a, b in zip(iter_frames(reference), iter_frames(candidate), strict=True):
        if a.shape != b.shape:
            raise ValueError(
                f"frame shape mismatch {a.shape} vs {b.shape}: a resize is itself a "
                "change, declare ChangeKind.OUTPUT_RESIZE and compare at one size"
            )
        n += 1
        ps.append(psnr(a, b))
        if with_lpips:
            lp.append(lpips_pair(a, b))
    if not n:
        raise ValueError("no overlapping frames")
    out = {
        "frames": float(n),
        "psnr_mean": float(np.mean(ps)),
        "psnr_worst": float(np.min(ps)),
    }
    if lp:
        out["lpips_mean"] = float(np.mean(lp))
        out["lpips_worst"] = float(np.max(lp))
    return out
