"""Video: frame handling, the optical-flow temporal-fidelity family, the
output-integrity floor, and composed signal stats.

STABILITY: experimental (v0.x) for these function signatures; the metric NAMES
(``lpips_frame_worst``, ``luma_flicker``,
``jerk_ratio``, ``flow_divergence``, ``warp_error``, ``warp_error_delta``,
``adjacent_frame_corr``, ``grid_peak_ratio``) are locked by the registry.

THE OUTPUT-INTEGRITY FLOOR (``adjacent_frame_corr`` / ``frame_std_min`` /
``grid_peak_ratio``) is the cheapest instrument here and the one that must never
be skipped: numpy only, no reference, no model, and it touches only a handful of
frames. It answers "is this a render at all" — first "or is it noise", the
question nobody asked while production minimax-h3 billed settled requests for
VAE-decoded noise, and from @13 also "or is it divided into little boxes", the
question nobody asked while corr 0.988 passed four renders the owner rejected
on sight for a visible lattice. The verdict wrapper and its scope limits live in
:mod:`cozy_eval.integrity`.

``grid_peak_ratio`` is a SPATIAL statistic in a module named temporal, and
deliberately: it belongs to the output-integrity screen, whose frame sampling,
grey-plane extraction and library stamp it shares outright (``frame_std_min`` is
spatial for the same reason). Splitting it out would duplicate the sampler and
let the two halves of one screen drift.

THE TEMPORAL-FIDELITY FAMILY (``flow_divergence`` / ``warp_error`` /
``warp_error_delta``) answers a question screenshots cannot: *do the movements
match*. Every paired number beside it — LPIPS/PSNR/DISTS/ringing — is
computed per FRAME; averaging stills is blind to motion, which is the axis a
sparse-attention or step-distill lane is most likely to damage silently. This
family compares the MOTION FIELDS themselves (Farneback optical flow), so a
candidate whose objects move along different trajectories is caught even when
each frame is individually faithful. ``warp_error`` is the reference-free half
(shimmer / boiling / flicker within one clip) and it is the ONE number here that
survives a re-rolled take; ``flow_divergence`` and ``warp_error_delta`` are the
paired halves against a same-seed control, and @10 marks them ``reference_only``
so the runner refuses them on a trajectory-perturbing lane rather than printing
a confounded number.

CUT AT @10: the Δ-frame PSNR family (``dframe_psnr``, ``dframe_psnr_worst``,
``dframe_ssim``). It was pitched as the flicker channel per-frame metrics cannot
see, and the argument is sound in isolation — differencing consecutive frames
first makes alternating error first-order. But it is a reference distance taken
OF a reference distance, so it is confounded twice over by a re-rolled take,
and it was never valid in the only lane anyone wanted it for. ``warp_error``
and ``luma_flicker`` measure the same failure reference-free, on one clip, with
no lane restriction at all. The names are gone from the registry; a banked v1
report that carries them still decodes, and the numbers keep their old meaning
under @9.

FRAME CONVENTION (matches cozy_eval and the conversion video gate):
``(T, H, W, 3)`` RGB, uint8 or float in [0, 1] — the PRE-ENCODE arrays a
producer already holds. A list of PIL images or of ``(H, W, 3)`` arrays is
accepted too. Nothing here decodes video files: the encoder is a separate
change that does not belong inside a generation verdict, and this package
takes no ffmpeg dependency for it.

SINGLE-ARM temporal statistics (flicker/jerk on one clip, no reference) are
NOT implemented here: ``cozy_eval.metrics.signal`` already owns them, so
:func:`signal_stats` composes it directly.
"""

from __future__ import annotations

from typing import Any

from ..errors import ConfigError


def stacked_frames(source: Any) -> Any:
    """The clip as ONE validated ``(T, H, W, 3)`` array, in its OWN dtype.

    Validation only — no conversion and, for an ndarray input, no copy.
    Normalizing a clip costs two full float32 copies of it (~3 GB for a
    121-frame 1080p render), so a metric that touches only a few frames stacks
    here and normalizes just those, via :func:`normalize_frame`.
    """
    import numpy as np

    if isinstance(source, (list, tuple)):
        if not source:
            raise ConfigError("as_frames: empty frame list")
        stacked = np.stack([
            np.asarray(f.convert("RGB") if hasattr(f, "convert") else f)
            for f in source
        ])
    else:
        stacked = np.asarray(source)
    if stacked.ndim != 4 or stacked.shape[-1] != 3:
        raise ConfigError(
            f"as_frames: expected (T, H, W, 3) RGB frames, got shape {stacked.shape}"
        )
    if stacked.shape[0] < 2:
        raise ConfigError(
            f"as_frames: a video needs at least 2 frames, got {stacked.shape[0]}; "
            "score single frames with the image suite"
        )
    return stacked


def _is_255_scale(stacked: Any) -> bool:
    """Is this clip in 0-255 rather than [0, 1]? Decided ONCE for the whole clip
    (a per-frame decision could scale two frames of one clip differently)."""
    import numpy as np

    return bool(stacked.dtype == np.uint8 or float(np.float32(stacked.max(initial=0.0))) > 1.5)


def normalize_frame(frame: Any, *, scale_255: bool) -> Any:
    """One frame of a stacked clip -> float32 in [0, 1]."""
    import numpy as np

    f = np.asarray(frame).astype(np.float32)
    if scale_255:
        f = f / 255.0
    return np.clip(f, 0.0, 1.0)


def as_frames(source: Any) -> Any:
    """Normalize any accepted clip form to ``(T, H, W, 3)`` float32 in [0, 1].

    Accepts a ``(T, H, W, 3)`` ndarray (uint8 or float), a list/tuple of PIL
    images, or a list/tuple of ``(H, W, 3)`` arrays. A video needs at least two
    frames — a single frame is an image and belongs in the image suite.
    """
    stacked = stacked_frames(source)
    return normalize_frame(stacked, scale_255=_is_255_scale(stacked))


def frame_images(frames: Any) -> list[Any]:
    """uint8 PIL views of ``(T, H, W, 3)`` float frames, for the image metrics."""
    import numpy as np
    from PIL import Image

    return [
        Image.fromarray(np.clip(f * 255.0, 0, 255).astype(np.uint8))
        for f in frames
    ]


def sample_indices(total: int, count: int) -> list[int]:
    """``count`` frame indices spread uniformly over ``[0, total)``, always
    including the first and last frame — motion is judged by its endpoints."""
    if total <= 0:
        raise ConfigError("sample_indices: empty clip")
    if count >= total:
        return list(range(total))
    if count == 1:
        return [0]
    step = (total - 1) / (count - 1)
    return sorted({round(i * step) for i in range(count)})


def _check_pair(reference: Any, candidate: Any, *, metric: str) -> None:
    if reference.shape != candidate.shape:
        raise ConfigError(
            f"{metric}: the two clips differ in shape, {tuple(reference.shape)} vs "
            f"{tuple(candidate.shape)} — a paired temporal metric needs frame-aligned "
            "clips of the same length and size; resize/trim the candidate first"
        )


def signal_stats(frames: Any) -> dict[str, float]:
    """Single-arm temporal signal statistics, composed from cozy_eval's signal backend.

    Returns ``{"luma_flicker": ..., "jerk_ratio": ...}``.
    ``luma_flicker`` is the backend's ``flicker`` (frame-mean luma wobble, %);
    ``jerk_ratio`` keeps its name (second over first temporal difference of the
    luma frames; smooth motion sits low, flicker and judder push it up).

    Runs :func:`cozy_eval.metrics.signal.temporal_score`, the luma-only pass
    (@9). It returns these two numbers EXACTLY as the full feature pass did,
    without computing the four per-frame feature families only the population
    lane consumes — the per-clip CPU tier's biggest single line (ce#14).
    """
    from cozy_eval.metrics.signal import temporal_score

    stats = temporal_score(frames)
    return {
        "luma_flicker": float(stats["flicker"]),
        "jerk_ratio": float(stats["jerk_ratio"]),
    }


SIGNAL_LIBRARY = "cozy-eval:signal"

# ---------------------------------------------------------------------------
# the temporal-fidelity family — optical flow: do the movements match?
# ---------------------------------------------------------------------------

FLOW_LIBRARY = "cozy-eval:flow"

#: Working HEIGHT the flow is computed at. Farneback is O(pixels); a paired EPE
#: is normalized by the reference's own motion magnitude so it is robust to this
#: choice, and 384 keeps a 10 s 768p clip to a few seconds on CPU. Width follows
#: the aspect ratio, rounded even.
FLOW_TARGET_H = 384

#: How many consecutive (t, t+1) frame pairs to sample, spread uniformly over
#: the clip (endpoints included). Motion is judged from a spread of transitions,
#: not every one — 24 pairs is plenty and bounds cost on a long clip.
FLOW_PAIRS = 24

# Farneback parameters (pyr_scale, levels, winsize, iterations, poly_n,
# poly_sigma, flags). OpenCV's documented defaults for dense flow; the same
# settings the ie#636 A/B lane derived its ad-hoc numbers with, so the library
# and that report read on one scale.
_FARNEBACK = (0.5, 3, 15, 3, 5, 1.2, 0)


def _pair_starts(total: int, count: int) -> list[int]:
    """Uniformly-spread start indices ``k`` for consecutive ``(k, k+1)`` pairs."""
    if total < 2:
        raise ConfigError("optical flow needs at least 2 frames")
    last = total - 2  # k+1 must be in range
    if count >= last + 1:
        return list(range(last + 1))
    if count == 1:
        return [0]
    step = last / (count - 1)
    return sorted({round(i * step) for i in range(count)})


def _small_gray_frame(frame: Any, size: tuple[int, int]) -> Any:
    """One ``(H,W,3)`` float frame -> working-resolution uint8 grey."""
    import numpy as np

    from ..resources import opencv

    cv2 = opencv()

    u8 = np.clip(np.asarray(frame) * 255.0, 0, 255).astype(np.uint8)
    small = cv2.resize(u8, size, interpolation=cv2.INTER_AREA)
    return cv2.cvtColor(small, cv2.COLOR_RGB2GRAY)


def _work_size(h: int, w: int, target_h: int) -> tuple[int, int]:
    if h <= target_h:
        return w, h
    sw = max(2, round(w * target_h / h) & ~1)
    return sw, target_h


def flow_fields(frames: Any, *, pairs: int = FLOW_PAIRS,
                target_h: int = FLOW_TARGET_H) -> tuple[list[Any], dict[int, Any], list[int]]:
    """Farneback dense flow for a spread of consecutive frame pairs.

    Returns ``(flows, gray, starts)``: ``flows[i]`` is the ``(h, w, 2)`` flow
    from frame ``starts[i]`` to ``starts[i]+1`` at the working resolution, and
    ``gray`` is ``{index: uint8 grey frame}`` for JUST the sampled frames — a
    long clip is never fully downscaled, only the ~2*pairs frames flow needs —
    and never fully normalized either: only the sampled frames are converted to
    float, so cost and peak RAM follow ``pairs``, not clip length.
    """
    from ..resources import opencv

    cv2 = opencv()

    stacked = stacked_frames(frames)
    t, h, w = stacked.shape[:3]
    starts = _pair_starts(t, pairs)
    size = _work_size(h, w, target_h)
    scale_255 = _is_255_scale(stacked)
    needed = sorted({k for k in starts} | {k + 1 for k in starts})
    gray = {
        i: _small_gray_frame(normalize_frame(stacked[i], scale_255=scale_255), size)
        for i in needed
    }
    flows = [
        cv2.calcOpticalFlowFarneback(gray[k], gray[k + 1], None, *_FARNEBACK)
        for k in starts
    ]
    return flows, gray, starts


def _magnitude(flow: Any) -> float:
    import numpy as np

    return float(np.hypot(flow[..., 0], flow[..., 1]).mean())


def warp_error_series(gray: Any, flows: Any, starts: list[int]) -> list[float]:
    """Per-pair reference-free temporal instability.

    Warp frame ``k`` toward ``k+1`` by the estimated flow and measure the mean
    absolute residual against the ACTUAL ``k+1``, normalized by that frame's
    contrast. Coherent motion warps cleanly (low residual); shimmer, boiling and
    per-frame noise cannot be predicted by any flow and leave a large residual —
    the reference-free signature of temporal instability, valid per clip
    regardless of same-seed trajectory re-roll.
    """
    import numpy as np

    from ..resources import opencv

    cv2 = opencv()

    h, w = gray[starts[0]].shape[:2]
    gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    out: list[float] = []
    for flow, k in zip(flows, starts, strict=True):
        a = gray[k].astype(np.float32)
        b = gray[k + 1].astype(np.float32)
        warped = cv2.remap(a, gx + flow[..., 0], gy + flow[..., 1],
                           cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        out.append(float(np.abs(warped - b).mean() / max(float(b.std()), 1e-6)))
    return out


def warp_error(frames: Any, *, pairs: int = FLOW_PAIRS,
               target_h: int = FLOW_TARGET_H) -> float:
    """Reference-free mean temporal-instability (shimmer/boiling/flicker)."""
    import numpy as np

    flows, gray, starts = flow_fields(frames, pairs=pairs, target_h=target_h)
    series = warp_error_series(gray, flows, starts)
    return float(np.mean(series))


def flow_divergence(reference: Any, candidate: Any, *, pairs: int = FLOW_PAIRS,
                    target_h: int = FLOW_TARGET_H) -> dict[str, float]:
    """How far the candidate's MOTION FIELD diverges from the reference's.

    Computes flow for both arms at matched pair indices and returns the mean
    end-point error (EPE, working-resolution px) between the two flow fields,
    plus ``flow_divergence`` — that EPE normalized by the reference's own motion
    magnitude, so ``0`` is identical motion and ``1`` is a divergence the size of
    the reference's motion. The paired arms must be frame-aligned and the same
    length (:func:`as_frames` + the caller's alignment); a shape mismatch raises.

    Also reports each arm's mean motion magnitude, so a candidate that simply
    moves LESS (a smeared, under-moving lane) is distinguishable from one that
    moves DIFFERENTLY.
    """
    import numpy as np

    ref = stacked_frames(reference)
    cand = stacked_frames(candidate)
    _check_pair(ref, cand, metric="flow_divergence")
    fr, _gr, _starts = flow_fields(ref, pairs=pairs, target_h=target_h)
    fc, _, _ = flow_fields(cand, pairs=pairs, target_h=target_h)
    epe = float(np.mean([
        np.hypot(a[..., 0] - b[..., 0], a[..., 1] - b[..., 1]).mean()
        for a, b in zip(fr, fc, strict=True)
    ]))
    mag_ref = float(np.mean([_magnitude(f) for f in fr]))
    mag_cand = float(np.mean([_magnitude(f) for f in fc]))
    return {
        "flow_epe": epe,
        "flow_divergence": epe / max(mag_ref, 1e-6),
        "motion_mag_ref": mag_ref,
        "motion_mag_cand": mag_cand,
        "motion_mag_ratio": mag_cand / max(mag_ref, 1e-6),
    }


def temporal_fidelity(reference: Any, candidate: Any, *, pairs: int = FLOW_PAIRS,
                      target_h: int = FLOW_TARGET_H) -> dict[str, float]:
    """The paired temporal-fidelity block, flows computed once per arm.

    ``flow_divergence`` (motion-field EPE / reference motion), ``warp_error`` +
    ``warp_error_ref`` (each arm's reference-free instability) and
    ``warp_error_delta`` (candidate minus reference — the ADDED instability, a
    paired SIMILARITY number that cancels the shared scene the way #9's
    ``ringing_excess`` does).
    """
    import numpy as np

    ref = stacked_frames(reference)
    cand = stacked_frames(candidate)
    _check_pair(ref, cand, metric="temporal_fidelity")
    fr, gr, starts = flow_fields(ref, pairs=pairs, target_h=target_h)
    fc, gc, _ = flow_fields(cand, pairs=pairs, target_h=target_h)
    epe = float(np.mean([
        np.hypot(a[..., 0] - b[..., 0], a[..., 1] - b[..., 1]).mean()
        for a, b in zip(fr, fc, strict=True)
    ]))
    mag_ref = float(np.mean([_magnitude(f) for f in fr]))
    mag_cand = float(np.mean([_magnitude(f) for f in fc]))
    we_ref = float(np.mean(warp_error_series(gr, fr, starts)))
    we_cand = float(np.mean(warp_error_series(gc, fc, starts)))
    return {
        "flow_divergence": epe / max(mag_ref, 1e-6),
        "flow_epe": epe,
        "warp_error": we_cand,
        "warp_error_ref": we_ref,
        "warp_error_delta": we_cand - we_ref,
        "motion_mag_ref": mag_ref,
        "motion_mag_cand": mag_cand,
        "motion_mag_ratio": mag_cand / max(mag_ref, 1e-6),
    }


# ---------------------------------------------------------------------------
# output integrity — the NOISE / BLANK floor (ie#634: every production
# minimax-h3 render was VAE-decoded noise and passed every check we had)
# ---------------------------------------------------------------------------

INTEGRITY_LIBRARY = "cozy-eval:integrity"

#: Adjacent ``(t, t+1)`` pairs sampled across the clip. The MEDIAN over a spread
#: is what makes a hard CUT safe: a cut drives one pair to ~0 while the rest
#: stay high. Five is enough to have a majority, and only ~2*pairs frames are
#: ever touched, so the gate costs the same on a 3 s clip and a 3 min one.
INTEGRITY_PAIRS = 5

#: Median adjacent-frame grey correlation below this reads as NOISE. MEASURED,
#: not guessed (ie#615 / ie#634): VAE-decoded noise 0.29, real renders 0.92-0.99.
#: 0.6 sits in the empty middle, so a cut-heavy real clip clears it and noise
#: cannot. NOT a quality floor — see :mod:`cozy_eval.integrity`'s scope note.
NOISE_CORR_FLOOR = 0.6

#: Per-frame grey standard deviation below this reads as BLANK (constant fill).
BLANK_STD_FLOOR = 0.01

#: Working HEIGHT the correlation is computed at, reached by integer decimation.
#: MEASURED to cost nothing: on a 1344x768 clip panning 1 px/frame the median
#: correlation is 0.9755 at full resolution and 0.9789 decimated to 96 rows,
#: while noise stays at ~0.00 either way — and the gate goes from 246 ms to
#: 7 ms, which is what makes it affordable on the serve path. It costs nothing
#: BECAUSE the statistic is a coarse whole-frame correlation, which is the same
#: reason it can never see fine-detail damage. Cheap and blind are one fact.
INTEGRITY_TARGET_H = 96

_LUMA = (0.299, 0.587, 0.114)


def _gray_at(source: Any, indices: list[int], *,
             target_h: int | None = INTEGRITY_TARGET_H) -> list[Any]:
    """Decimated grey planes in [0, 1] for JUST ``indices``.

    Two things keep this at milliseconds regardless of clip length or
    resolution, and both matter on the serve path: only the sampled frames are
    touched (unlike :func:`as_frames`, which materializes a float copy of every
    frame), and each is decimated to ~``target_h`` rows BEFORE the float
    conversion, so the expensive pass runs on ~1/s^2 of the pixels.

    ``target_h=None`` returns FULL-resolution grey planes. The grid axis needs
    that and cannot share the decimated ones: integer decimation to 96 rows
    aliases an 8-32 px lattice away completely, which is the same fact as
    "cheap and blind are one fact" read from the other side.
    """
    import numpy as np

    if isinstance(source, (list, tuple)):
        picked = [
            np.asarray(f.convert("RGB") if hasattr(f, "convert") else f)
            for f in (source[i] for i in indices)
        ]
    else:
        arr = np.asarray(source)  # a view for an ndarray; nothing is copied
        picked = [arr[i] for i in indices]

    out = []
    luma = np.asarray(_LUMA, np.float32)
    for a in picked:
        if a.ndim != 3 or a.shape[-1] != 3:
            raise ConfigError(
                f"output integrity: expected (H, W, 3) RGB frames, got shape {a.shape}"
            )
        stride = 1 if target_h is None else max(1, a.shape[0] // max(target_h, 1))
        small = a[::stride, ::stride]  # a view: the decimation itself is free
        f = small.astype(np.float32)
        if a.dtype == np.uint8 or float(f.max(initial=0.0)) > 1.5:
            f = f / 255.0
        out.append(f @ luma)
    return out


def _clip_length(source: Any) -> int:
    import numpy as np

    if isinstance(source, (list, tuple)):
        return len(source)
    return int(np.asarray(source).shape[0])


def integrity_stats(source: Any, *, pairs: int = INTEGRITY_PAIRS,
                    target_h: int = INTEGRITY_TARGET_H) -> dict[str, Any]:
    """Both integrity numbers from ONE decoding pass over the sampled frames.

    Returns ``{"corr_series": [...], "adjacent_frame_corr": median,
    "frame_std_min": min}``. The single pass is the point: deriving the grey
    planes twice doubles the gate's cost for no new information.
    """
    import numpy as np

    starts = _pair_starts(_clip_length(source), pairs)
    needed = sorted(set(starts) | {k + 1 for k in starts})
    gray = dict(zip(needed, _gray_at(source, needed, target_h=target_h), strict=True))
    stds = {i: float(g.std()) for i, g in gray.items()}

    series: list[float] = []
    for k in starts:
        sa, sb = stds[k], stds[k + 1]
        if sa < 1e-6 or sb < 1e-6:
            series.append(0.0)  # a flat frame correlates with nothing
            continue
        a, b = gray[k].ravel(), gray[k + 1].ravel()
        series.append(float(((a - a.mean()) * (b - b.mean())).mean() / (sa * sb)))
    return {
        "corr_series": series,
        "adjacent_frame_corr": float(np.median(series)),
        "frame_std_min": min(stds.values()),
    }


# ---------------------------------------------------------------------------
# the GRID / BLOCKINESS axis — periodic spatial energy (#557: the owner rejected
# four renders the 0.6 correlation floor passed at corr 0.988, for a visible
# lattice. The gate must catch what an owner's eyes catch.)
# ---------------------------------------------------------------------------

#: Candidate grid PERIODS in pixels. The band is bounded by physics on both
#: ends: below 8 px a "period" is a two-tap edge, indistinguishable from ordinary
#: texture; above 128 px a 768-row frame holds fewer than six repeats, which is
#: scene composition rather than a lattice. Every period a diffusion video stack
#: naturally lays down is inside it — the VAE's 8 px pixel-shuffle, the DiT's 16
#: and 32 px patch lattice, and the 128 px class of decoder tile seam.
GRID_PERIOD_MIN_PX = 8
GRID_PERIOD_MAX_PX = 128

#: Bins on each side that form the LOCAL SPECTRAL NEIGHBOURHOOD a candidate line
#: is measured against, and the bins around the candidate excluded from it
#: (spectral leakage puts a real line's own energy in its immediate neighbours,
#: so including them would let a line normalise itself away). A ratio against a
#: local median, not against total energy: content is broadband and moves the
#: whole neighbourhood together, so it divides out; a lattice is ONE bin.
GRID_NEIGHBOR_BINS = 24
GRID_EXCLUDE_BINS = 2

#: An axis is scored only if the frame is at least this many pixels along it, and
#: this is the ratio's TRANSFER ENVELOPE — MEASURED, not assumed. The corpus was
#: re-scored on centre crops of itself (same pixel scale, so a lattice keeps its
#: period). :data:`GRID_PEAK_LIMIT` separates every known-good render from every
#: rejected one at 1344x768 (gap 1.88x), 1024x768 (2.29x), 768x768 (1.81x),
#: 768x512 (1.50x), 768x384 (2.15x), 640x512 (1.72x), 576x512 (1.66x) and
#: 512x512 (1.40x). Below 512 px the separation collapses and then INVERTS — with
#: the rule forced off, 384x384 reads clean 4.07 vs rejected 4.60 and 256x256
#: reads clean 5.08 vs rejected 4.07, the clean side SCORING HIGHER — because the
#: fixed +/-24-bin neighbourhood stops being local relative to the in-band range
#: and the ratio starts reading content. A frame with no axis this long is
#: UNMEASURED rather than scored against a limit that does not hold there
#: (GATE.md 4b: a threshold is only a threshold where the clean population sits
#: comfortably inside it). Honest remainder INSIDE the envelope: a short second
#: axis costs SENSITIVITY, never a false failure — at 512x288 only the 512 axis is
#: scored, the clean side stays low at 3.25 and the mildest rejected render slips
#: to 4.93, a MISS.
GRID_MIN_AXIS_PX = 512

#: ``grid_peak_ratio`` above this reads as a GRID/BLOCKINESS defect. DERIVED over
#: one real corpus in BOTH directions, no synthetic clean side. Evidence:
#: ``calibration/grid-blockiness.json`` (regenerate with ``calibration/run_grid.py``).
#:
#:   * owner-ACCEPTED bank renders, n=11 — tensorfs-bench proto-001 + job-003-floor,
#:     H3 1344x768x124, the same encoding lane: **1.975 .. 3.804**, median 2.171.
#:     This is the NULL CONTROL SET, and it is what decides a limit may exist here.
#:   * the three RED arms whose PICTURE is a known-good render degraded on another
#:     axis (frozen, clipped audio, silent audio): 3.770, 3.770, **3.896**.
#:     RED-frozen is the hardest case this statistic has by construction — pooling
#:     identical frames makes every content periodicity add perfectly coherently.
#:   * owner-REJECTED renders, n=4 — the #557 oracle set, ComfyUI's same-carrier
#:     side-by-side included: **7.320 .. 14.179**, median 10.280.
#:   * the planted RED-blocky reference: 15.972. The reversed-sampler arm
#:     ``daf50552``: 62.842 (which also fails the noise floor, at corr 0.019).
#:
#: The empty band is **3.896 .. 7.320**, a factor of 1.88. 6.0 sits inside it with
#: 1.54x of headroom over the worst known-good render — the SAME relative headroom
#: NOISE_CORR_FLOOR carries over its own clean population (0.92/0.6 = 1.53x) — and
#: 1.22x below the mildest render the owner rejected. Placed by that rule rather
#: than at the band's geometric midpoint (5.34) deliberately: on the serve path a
#: gate that fails a correct render is the more expensive error, and this axis has
#: room to spare against the failures that actually occurred.
GRID_PEAK_LIMIT = 6.0


def _axis_spectrum(profile: Any) -> Any:
    """Windowed magnitude spectrum of one mean-removed gradient profile."""
    import numpy as np

    centered = profile - profile.mean()
    return np.abs(np.fft.rfft(centered * np.hanning(profile.size).astype(np.float32)))


def _peak_over_neighborhood(spec: Any, n: int) -> tuple[float, float]:
    """``(ratio, period_px)`` for the strongest in-band periodic line, or (0, 0).

    The ratio is the candidate bin's magnitude over the MEDIAN of its local
    neighbourhood. That normalisation is what makes one number comparable across
    content: a busy frame raises every bin, a lattice raises one.
    """
    import numpy as np

    kmin = max(2, int(np.ceil(n / GRID_PERIOD_MAX_PX)))
    kmax = int(n // GRID_PERIOD_MIN_PX)
    best, best_k = 0.0, 0
    for k in range(kmin, kmax + 1):
        lo, hi = max(1, k - GRID_NEIGHBOR_BINS), min(spec.size, k + GRID_NEIGHBOR_BINS + 1)
        neigh = np.concatenate([spec[lo:max(lo, k - GRID_EXCLUDE_BINS)],
                                spec[min(hi, k + GRID_EXCLUDE_BINS + 1):hi]])
        if neigh.size < 8:
            continue
        ratio = float(spec[k]) / max(float(np.median(neigh)), 1e-9)
        if ratio > best:
            best, best_k = ratio, k
    return best, (n / best_k if best_k else 0.0)


def grid_stats(source: Any, *, frames: int = INTEGRITY_PAIRS) -> dict[str, Any]:
    """Periodic spatial energy: is this render divided into little boxes?

    THE STATISTIC. For each of ``frames`` frames spread across the clip, the
    absolute x- and y- gradients are averaged along the OTHER axis into two 1-D
    profiles. A grid — a VAE tile seam, a DiT patch lattice, a block-quantized
    decode — is a comb of ridges at fixed x (and/or fixed y) positions, so it is
    a single line in each profile's spectrum. Scene content is not: it is
    broadband, and it MOVES.

    THE POOLING IS THE DETECTOR, not an averaging convenience. The per-frame
    spectra are summed BEFORE the peak is looked for, so a frame-locked lattice
    adds coherently across the sampled frames while a content periodicity that
    drifts by a pixel spreads over bins and cancels. Measured on the corpus,
    pooling first rather than taking a per-frame peak and pooling after moves the
    worst known-good render from 4.288 down to 3.898 and the mildest rejected one
    from 10.106 only to 9.846 — it buys separation on the clean side, which is
    the side a serve-path gate can least afford to be wrong about.

    Both axes are scored and the WORSE one is reported: a decoder tiled only
    horizontally is still a gridded render.

    Returns ``{"grid_peak_ratio", "grid_period_px", "grid_axis", "grid_frames"}``.
    Raises :class:`~cozy_eval.errors.ConfigError` if no axis is long enough to
    long enough to carry the calibrated statistic (:data:`GRID_MIN_AXIS_PX`)
    — UNMEASURED, never a silent pass.

    MEASURED cost: ~20 ms for five 1344x768 frames (gradients, FFTs and the luma
    conversion), which takes the WHOLE integrity screen from 8 ms to a median of
    30 ms over the 20-clip corpus — still cheap enough that there is no render it
    is not worth doing. It runs at FULL resolution and must: decimating to the
    correlation floor's 96 rows aliases the very lattice it is looking for.
    """
    import numpy as np

    indices = _pair_starts(_clip_length(source), frames)
    gray = _gray_at(source, indices, target_h=None)

    pooled: dict[str, Any] = {}
    lengths: dict[str, int] = {}
    for plane in gray:
        h, w = plane.shape
        profiles = {
            "x": (w, np.abs(np.diff(plane, axis=1)).mean(axis=0), w - 1),
            "y": (h, np.abs(np.diff(plane, axis=0)).mean(axis=1), h - 1),
        }
        for axis, (extent, profile, n) in profiles.items():
            if extent < GRID_MIN_AXIS_PX:
                continue
            spec = _axis_spectrum(profile)
            pooled[axis] = spec if axis not in pooled else pooled[axis] + spec
            lengths[axis] = n

    # A scored axis with no periodic line at all reports 0.0 — that is a
    # measurement ("no lattice here"), not a failure to measure. Only the extent
    # rule can leave this axis UNMEASURED.
    scored = {axis: _peak_over_neighborhood(spec / len(gray), lengths[axis])
              for axis, spec in pooled.items()}
    if not scored:
        raise ConfigError(
            f"grid axis: no frame axis reaches {GRID_MIN_AXIS_PX} px, below which "
            f"the {GRID_PEAK_LIMIT} limit was MEASURED to stop separating clean "
            f"renders from gridded ones"
        )
    axis = max(scored, key=lambda a: scored[a][0])
    ratio, period = scored[axis]
    return {
        "grid_peak_ratio": float(ratio),
        "grid_period_px": float(period),
        "grid_axis": axis,
        "grid_frames": len(gray),
    }


def grid_peak_ratio(source: Any, *, frames: int = INTEGRITY_PAIRS) -> float:
    """Strongest periodic spatial line over its local spectral neighbourhood."""
    return float(grid_stats(source, frames=frames)["grid_peak_ratio"])


def adjacent_frame_corr_series(source: Any, *,
                               pairs: int = INTEGRITY_PAIRS) -> list[float]:
    """Pearson correlation of each sampled ``(t, t+1)`` grey frame pair.

    Real video is highly self-similar frame to frame, even through motion and
    cuts; independently-sampled noise is correlated with nothing. A flat frame
    has no variance to correlate, so its pair scores 0.0 — the blank case is
    caught by :func:`frame_std_min`, not by inventing a correlation.
    """
    series: list[float] = integrity_stats(source, pairs=pairs)["corr_series"]
    return series


def adjacent_frame_corr(source: Any, *, pairs: int = INTEGRITY_PAIRS) -> float:
    """MEDIAN adjacent-frame grey correlation — the noise floor's number."""
    return float(integrity_stats(source, pairs=pairs)["adjacent_frame_corr"])


def frame_std_min(source: Any, *, pairs: int = INTEGRITY_PAIRS) -> float:
    """Smallest per-frame grey standard deviation over the sampled frames.

    Zero means a constant-fill frame — blank output, which correlates with
    nothing and must not be reported as a correlation failure alone.
    """
    return float(integrity_stats(source, pairs=pairs)["frame_std_min"])


__all__ = [
    "BLANK_STD_FLOOR",
    "FLOW_LIBRARY",
    "FLOW_PAIRS",
    "FLOW_TARGET_H",
    "GRID_EXCLUDE_BINS",
    "GRID_MIN_AXIS_PX",
    "GRID_NEIGHBOR_BINS",
    "GRID_PEAK_LIMIT",
    "GRID_PERIOD_MAX_PX",
    "GRID_PERIOD_MIN_PX",
    "INTEGRITY_LIBRARY",
    "INTEGRITY_PAIRS",
    "INTEGRITY_TARGET_H",
    "NOISE_CORR_FLOOR",
    "SIGNAL_LIBRARY",
    "adjacent_frame_corr",
    "adjacent_frame_corr_series",
    "as_frames",
    "flow_divergence",
    "flow_fields",
    "frame_images",
    "frame_std_min",
    "grid_peak_ratio",
    "grid_stats",
    "integrity_stats",
    "sample_indices",
    "signal_stats",
    "temporal_fidelity",
    "warp_error",
    "warp_error_series",
]
