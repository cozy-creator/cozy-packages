"""Dimension 1: perceptual similarity to a reference render (PAIRED).

STABILITY: experimental (v0.x) for these function signatures; the metric NAMES
(``lpips``, ``ssim``, ``ms_ssim``, ``psnr``) are locked by the registry.

LPIPS is the gated headline. PSNR/SSIM/MS-SSIM are report-only — the
correlation study measured |r| 0.83-0.96 between all four on banked pairs, so
they are one signal, and gating four correlated numbers only multiplies the
chance of failing a good arm.

BUILD-vs-BUY, REVISITED AT @10. The learned metrics here — LPIPS, CLIP —
come from **torchmetrics** (Apache-2.0, v1.9.0) and there is no reason to have
an opinion of our own about them. PSNR/SSIM/MS-SSIM went the OTHER way: they
moved OUT of this module into :mod:`cozy_eval.metrics.reference`, in numpy.

That reverses v1's call, and the reason is identity, not taste. Buying SSIM from
torchmetrics while a numpy SSIM also existed in reference.py left the package
with the same metric name meaning two different numbers, and a third when
scikit-image happened to be installed — measured at 0.9207 vs 0.8993 on one
scene pair. A closed-form published method is not worth a torch dependency and
is certainly not worth an ambiguous identity: SSIM is now one implementation,
Wang 2004 gaussian 11x11 sigma 1.5, and the whole family runs on the base
install with no extra at all.

Not adopted, and why: `pyiqa`/IQA-PyTorch is PolyForm **Noncommercial** —
repo-wide, no clean subset; `piq` is stale (2023) and redundant here.
"""

from __future__ import annotations

from typing import Any

from ..device import AUTO, resolve_device

# Keyed by (metric, model, device): a cache that ignores the device silently
# returns a model placed on the wrong one.
_MODEL_CACHE: dict[str, Any] = {}



def free_models() -> None:
    _MODEL_CACHE.clear()


def _tensor(image: Any) -> Any:
    """uint8 RGB PIL/ndarray -> float32 [1,3,H,W] in 0..255."""
    import numpy as np
    import torch

    arr = np.asarray(image.convert("RGB") if hasattr(image, "convert") else image)
    t = torch.from_numpy(np.array(arr, copy=True)).float()
    return t.permute(2, 0, 1).unsqueeze(0)


# ONE IMPLEMENTATION PER NAME (@10). psnr / ssim / ms_ssim used to live here as
# well, on torchmetrics at data_range 255, while metrics/reference.py computed
# them in numpy at data_range 1 — the same three names meaning two different
# numbers inside one package, which is the clean-fid defect (§2.2) at home.
# They are now computed in ONE place, in numpy, and re-exported here so the
# existing call sites keep working. They need no torch at all, which is what
# the registry always claimed by calling them cheap-deterministic.
from .reference import ms_ssim, psnr, ssim  # noqa: E402


def lpips_model(device: str = AUTO) -> Any:
    """torchmetrics' LPIPS — a direct BSD-2 port of Zhang's original, with the
    linear-layer weights shipped in-package (only the torchvision AlexNet
    backbone is fetched, ~245 MB, and is baked into the image)."""
    device = resolve_device(device)
    key = f"lpips:alex:{device}"
    if key not in _MODEL_CACHE:
        from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity

        _MODEL_CACHE[key] = LearnedPerceptualImagePatchSimilarity(
            net_type="alex", normalize=True,
        ).to(device).eval()
    return _MODEL_CACHE[key]


def lpips_pair(model: Any, a: Any, b: Any, device: str = AUTO) -> float:
    import torch

    device = resolve_device(device)

    with torch.no_grad():
        return float(model(
            (_tensor(a) / 255.0).to(device), (_tensor(b) / 255.0).to(device),
        ))


CLIP_MODEL = "openai/clip-vit-base-patch32"


def clip_model(device: str = AUTO, *, model_ref: str = CLIP_MODEL) -> tuple[Any, Any]:
    device = resolve_device(device)
    key = f"clip:{model_ref}:{device}"
    if key not in _MODEL_CACHE:
        from transformers import CLIPModel, CLIPProcessor

        _MODEL_CACHE[key] = (
            CLIPModel.from_pretrained(model_ref).to(device).eval(),
            CLIPProcessor.from_pretrained(model_ref),
        )
    model, processor = _MODEL_CACHE[key]
    return model, processor


def clip_score(
    model: Any, proc: Any, image: Any, prompt: str, device: str = AUTO,
) -> float:
    """torchmetrics-style CLIP score: 100 * max(0, cos(image_emb, text_emb)).

    Kept on plain transformers rather than ``torchmetrics.multimodal``: the
    model is already loaded and the extra would drag timm/einops/piq for a
    cosine we compute in four lines.
    """
    import torch

    device = resolve_device(device)
    inputs = proc(
        text=[prompt[:300]], images=[image], return_tensors="pt",
        padding=True, truncation=True,
    ).to(device)
    with torch.no_grad():
        out = model(**inputs)
        img_e = out.image_embeds / out.image_embeds.norm(dim=-1, keepdim=True)
        txt_e = out.text_embeds / out.text_embeds.norm(dim=-1, keepdim=True)
        return float(max(0.0, (img_e * txt_e).sum().item()) * 100.0)


__all__ = [
    "CLIP_MODEL",
    "clip_model",
    "clip_score",
    "free_models",
    "lpips_model",
    "lpips_pair",
    "ms_ssim",
    "psnr",
    "ssim",
]
